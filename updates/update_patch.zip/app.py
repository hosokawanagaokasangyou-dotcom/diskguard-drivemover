import os
import sys
import json
import time
import uuid
import socket
import shutil
import hashlib
import ctypes
from ctypes import wintypes
import threading
import subprocess
import urllib.parse
import urllib.request
import zipfile
import tempfile
from pathlib import Path
from datetime import datetime
from http.server import HTTPServer, SimpleHTTPRequestHandler
from socketserver import ThreadingMixIn

APP_VERSION = "2.1.1"
GITHUB_REPO_OWNER = "hosokawanagaokasangyou-dotcom"
GITHUB_REPO_NAME = "diskguard-drivemover"
UPDATE_VERSION_URL = f"https://raw.githubusercontent.com/{GITHUB_REPO_OWNER}/{GITHUB_REPO_NAME}/main/updates/version.json"
UPDATE_PATCH_URL = f"https://raw.githubusercontent.com/{GITHUB_REPO_OWNER}/{GITHUB_REPO_NAME}/main/updates/update_patch.zip"

# PyInstaller EXE compatibility:
# - STATIC_DIR points to bundled _MEIPASS/static when frozen (or local static dir)
# - CONFIG_FILE and LOG_FILE are stored in a writable directory next to the executable (or LOCALAPPDATA fallback)
if getattr(sys, "frozen", False):
    BUNDLE_DIR = Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent)).resolve()
    BASE_DIR = Path(sys.executable).parent.resolve()
else:
    BUNDLE_DIR = Path(__file__).parent.resolve()
    BASE_DIR = BUNDLE_DIR


def _resolve_writable_data_dir(preferred_dir: Path) -> Path:
    try:
        preferred_dir.mkdir(parents=True, exist_ok=True)
        test_file = preferred_dir / f".write_test_{os.getpid()}"
        with open(test_file, "w", encoding="utf-8") as f:
            f.write("ok")
        test_file.unlink(missing_ok=True)
        return preferred_dir
    except Exception:
        fallback = Path(os.environ.get("LOCALAPPDATA", os.path.expanduser("~"))) / "FolderSizeManager"
        fallback.mkdir(parents=True, exist_ok=True)
        return fallback


DATA_DIR = _resolve_writable_data_dir(BASE_DIR)
CONFIG_FILE = DATA_DIR / "config.json"
LOG_FILE = DATA_DIR / "operation_log.json"
APP_UPDATE_DIR = DATA_DIR / "app_update"
STATIC_DIR = (BUNDLE_DIR / "static") if (BUNDLE_DIR / "static").exists() else (BASE_DIR / "static")


def parse_version_tuple(ver_str: str) -> tuple:
    try:
        cleaned = str(ver_str).strip().lstrip("vV")
        parts = [int(x) for x in cleaned.split(".") if x.isdigit()]
        return tuple(parts) if parts else (0, 0, 0)
    except Exception:
        return (0, 0, 0)


def get_current_version_info() -> dict:
    """現在適用されている最新バージョン情報を取得する（app_update > BASE_DIR > BUNDLE_DIR > APP_VERSION）"""
    best_ver = APP_VERSION
    best_info = {"version": APP_VERSION, "released_at": "", "notes": ""}
    candidates = [
        APP_UPDATE_DIR / "version.json",
        BASE_DIR / "version.json",
        BUNDLE_DIR / "version.json",
    ]
    for p in candidates:
        if p.exists():
            try:
                with open(p, "r", encoding="utf-8") as f:
                    data = json.load(f)
                v = data.get("version", APP_VERSION)
                if parse_version_tuple(v) >= parse_version_tuple(best_ver):
                    best_ver = v
                    best_info = data
            except Exception:
                pass
    best_info["version"] = best_ver
    return best_info


def check_for_updates(timeout: float = 8.0) -> dict:
    """GitHubリポジトリ上の公開アップデート情報 (updates/version.json) を確認する"""
    cur_info = get_current_version_info()
    cur_ver = cur_info.get("version", APP_VERSION)
    url = f"{UPDATE_VERSION_URL}?t={int(time.time())}"
    try:
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": f"DiskGuard-DriveMover-Updater/{cur_ver}",
                "Cache-Control": "no-cache",
            },
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
        remote = json.loads(raw)
        latest_ver = str(remote.get("version", cur_ver)).strip()
        has_update = parse_version_tuple(latest_ver) > parse_version_tuple(cur_ver)
        return {
            "ok": True,
            "has_update": has_update,
            "current_version": cur_ver,
            "latest_version": latest_ver,
            "released_at": remote.get("released_at", ""),
            "notes": remote.get("notes", ""),
            "patch_url": remote.get("patch_url", UPDATE_PATCH_URL),
            "sha256": remote.get("sha256", ""),
            "size": remote.get("size", 0),
        }
    except Exception as e:
        return {
            "ok": False,
            "has_update": False,
            "current_version": cur_ver,
            "latest_version": cur_ver,
            "error": str(e),
        }


def download_and_apply_update(update_info: dict | None = None) -> dict:
    """リポジトリ上の update_patch.zip をダウンロード・SHA-256検証し、app_update へ適用する"""
    if not update_info:
        update_info = check_for_updates()
    if not update_info.get("ok"):
        return {"ok": False, "error": update_info.get("error", "アップデート情報の取得に失敗しました")}

    patch_url = update_info.get("patch_url") or UPDATE_PATCH_URL
    expected_sha256 = str(update_info.get("sha256", "")).strip().lower()
    latest_ver = update_info.get("latest_version", APP_VERSION)

    try:
        req = urllib.request.Request(
            f"{patch_url}?t={int(time.time())}",
            headers={
                "User-Agent": f"DiskGuard-DriveMover-Updater/{APP_VERSION}",
                "Cache-Control": "no-cache",
            },
        )
        with urllib.request.urlopen(req, timeout=20.0) as resp:
            patch_bytes = resp.read()

        actual_sha256 = hashlib.sha256(patch_bytes).hexdigest().lower()
        if expected_sha256 and actual_sha256 != expected_sha256:
            return {
                "ok": False,
                "error": f"アップデートファイルの整合性チェック(SHA-256)に失敗しました。\n期待値: {expected_sha256[:16]}...\n実際値: {actual_sha256[:16]}...",
            }

        staging_dir = DATA_DIR / "app_update_staging"
        if staging_dir.exists():
            shutil.rmtree(staging_dir, ignore_errors=True)
        staging_dir.mkdir(parents=True, exist_ok=True)

        tmp_zip = staging_dir / "update_patch.zip"
        tmp_zip.write_bytes(patch_bytes)

        with zipfile.ZipFile(tmp_zip, "r") as zf:
            zf.extractall(staging_dir)
        tmp_zip.unlink(missing_ok=True)

        # 必須ファイルの検証
        if not (staging_dir / "app.py").exists() or not (staging_dir / "desktop_gui.py").exists():
            shutil.rmtree(staging_dir, ignore_errors=True)
            return {"ok": False, "error": "アップデートパッケージの形式が不正です。"}

        # version.json を確実に最新バージョンで書き込む
        ver_meta = {
            "version": latest_ver,
            "released_at": update_info.get("released_at", datetime.now().isoformat()),
            "notes": update_info.get("notes", ""),
            "applied_at": datetime.now().isoformat(),
        }
        with open(staging_dir / "version.json", "w", encoding="utf-8") as vf:
            json.dump(ver_meta, vf, ensure_ascii=False, indent=2)

        # 本番 app_update フォルダへ反映
        APP_UPDATE_DIR.mkdir(parents=True, exist_ok=True)
        for item in staging_dir.iterdir():
            dest_item = APP_UPDATE_DIR / item.name
            if item.is_dir():
                if dest_item.exists():
                    shutil.rmtree(dest_item, ignore_errors=True)
                shutil.copytree(item, dest_item)
            else:
                shutil.copy2(item, dest_item)

        shutil.rmtree(staging_dir, ignore_errors=True)
        return {
            "ok": True,
            "installed_version": latest_ver,
            "notes": update_info.get("notes", ""),
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}

# 1. Core OS & Manufacturer Recovery Paths (Strictly protected)
DEFAULT_SYSTEM_PROTECTED_PATHS = [
    r"C:\Windows",
    r"C:\Program Files",
    r"C:\Program Files (x86)",
    r"C:\ProgramData",
    r"C:\System Volume Information",
    r"C:\$Recycle.Bin",
    r"C:\Recovery",
    r"C:\PerfLogs",
    r"C:\Boot",
    r"C:\EFI",
    r"C:\Intel",
    r"C:\AMD",
    r"C:\NVIDIA",
    r"C:\Drivers",
    r"C:\SWSetup",
    r"C:\Fujitsu",
    r"C:\NEC",
    r"C:\Toshiba",
    r"C:\Dynabook",
    r"C:\VAIO",
    r"C:\HP",
    r"C:\Dell",
    r"C:\Lenovo",
    r"C:\ASUS",
    r"C:\Acer",
]

# Default system protected folder/file names anywhere
DEFAULT_SYSTEM_PROTECTED_NAMES = [
    "$recycle.bin",
    "system volume information",
    "pagefile.sys",
    "hiberfil.sys",
    "swapfile.sys",
    "bootmgr",
    "ntldr",
    "ntuser.dat",
    "usrclass.dat",
]

# 2. Mail / Outlook data extensions & path segments (Default protected: deleting/moving breaks Outlook)
MAIL_PROTECTED_EXTENSIONS = {
    ".pst": "Outlook個人用データファイル (.pst)",
    ".ost": "Outlookオフラインデータファイル (.ost)",
    ".nst": "Outlookグループストレージ (.nst)",
    ".pab": "Outlookアドレス帳 (.pab)",
    ".oab": "Outlookオフラインアドレス帳 (.oab)",
    ".iaf": "メールアカウント設定 (.iaf)",
    ".prf": "Outlookプロファイル (.prf)",
    ".rwz": "Outlook仕分けルール (.rwz)",
    ".mbox": "メールボックスデータ (.mbox)",
    ".dbx": "メールデータ (.dbx)",
}

MAIL_PROTECTED_PATH_SEGMENTS = [
    "\\outlook ファイル\\",
    "\\outlook files\\",
    "\\microsoft\\outlook\\",
    "\\thunderbird\\profiles\\",
    "\\windows mail\\",
]

# 3. Virtual Disk Images, OS Recovery Images & Containers (Default protected: moving/deleting breaks VM/OS/WSL/Docker)
VIRTUAL_DISK_PROTECTED_EXTENSIONS = {
    ".wim": "Windowsイメージ・リカバリデータ (.wim)",
    ".esd": "Windows回復・配信イメージ (.esd)",
    ".swm": "分割Windowsイメージ (.swm)",
    ".vhdx": "仮想ハードディスク (.vhdx / WSL・Hyper-V・Docker)",
    ".vhd": "仮想ハードディスク (.vhd)",
    ".vmdk": "VMware 仮想ディスク (.vmdk)",
    ".vdi": "VirtualBox 仮想ディスク (.vdi)",
    ".hdd": "仮想ディスク (.hdd)",
    ".qcow": "QEMU 仮想ディスク (.qcow)",
    ".qcow2": "QEMU/KVM 仮想ディスク (.qcow2)",
    ".ova": "仮想アプライアンス (.ova)",
    ".ovf": "仮想マシン定義 (.ovf)",
    ".vmx": "VMware 仮想マシン構成 (.vmx)",
    ".vmsd": "VMware スナップショット定義 (.vmsd)",
    ".vmsn": "VMware スナップショット状態 (.vmsn)",
    ".vmss": "VMware サスペンド状態 (.vmss)",
    ".nvram": "仮想マシン BIOS状態 (.nvram)",
    ".vbox": "VirtualBox 仮想マシン構成 (.vbox)",
    ".iso": "ディスクイメージ (.iso)",
    ".img": "ディスクイメージ (.img)",
}

VIRTUAL_ENV_PATH_SEGMENTS = [
    "\\rec_image\\",
    "\\recoveryimage\\",
    "\\docker\\",
    "\\wsl\\",
    "\\hyper-v\\",
    "\\virtualbox vms\\",
    "\\vmware\\",
    "\\vagrant\\",
]

# 4. Databases, Accounting, Keys, AI Models & Backups (Default protected)
CRITICAL_DATA_PROTECTED_EXTENSIONS = {
    ".mdf": "SQL Server データベース (.mdf)",
    ".ldf": "SQL Server ログ (.ldf)",
    ".ndf": "SQL Server セカンダリDB (.ndf)",
    ".accdb": "Access データベース (.accdb)",
    ".mdb": "Access データベース (.mdb)",
    ".sqlite": "SQLite データベース (.sqlite)",
    ".sqlite3": "SQLite データベース (.sqlite3)",
    ".db": "データベースファイル (.db)",
    ".gdb": "データベースファイル (.gdb)",
    ".fdb": "Firebird データベース (.fdb)",
    ".qbw": "会計データ (.qbw)",
    ".kdbx": "パスワードDB (.kdbx)",
    ".bak": "バックアップファイル (.bak)",
    ".gguf": "ローカルAIモデル (.gguf)",
    ".safetensors": "ローカルAIモデル (.safetensors)",
    ".onnx": "AI推論モデル (.onnx)",
    ".pt": "AIモデル (.pt)",
    ".pth": "AIモデル (.pth)",
    ".ckpt": "AIモデルチェックポイント (.ckpt)",
    ".tflite": "AIモデル (.tflite)",
    ".pem": "秘密鍵・証明書 (.pem)",
    ".ppk": "SSH秘密鍵 (.ppk)",
    ".key": "暗号鍵ファイル (.key)",
    ".pfx": "電子証明書 (.pfx)",
    ".p12": "電子証明書 (.p12)",
    ".cer": "電子証明書 (.cer)",
    ".crt": "電子証明書 (.crt)",
}

# 5. System Binary & Program Extensions
SYSTEM_BINARY_EXTENSIONS = {
    ".sys", ".dll", ".drv", ".ocx", ".cpl", ".scr", ".cat", ".inf",
    ".mum", ".man", ".efi", ".rom", ".bin", ".dat", ".reg", ".msc",
    ".pyd", ".so", ".lib", ".whl", ".jar",
}

# 6. Safe User Content Extensions (Whitelist for Default-Safe policy)
SAFE_USER_CONTENT_EXTENSIONS = {
    # Video
    ".mp4", ".mov", ".avi", ".mkv", ".wmv", ".flv", ".webm", ".m4v", ".ts", ".m2ts", ".mpg", ".mpeg", ".3gp",
    # Audio
    ".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a", ".wma", ".opus", ".mid", ".midi",
    # Image & Design
    ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tiff", ".tif", ".psd", ".ai", ".svg", ".raw", ".cr2", ".nef", ".heic", ".ico",
    # General Documents & Office
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".xlsm", ".ppt", ".pptx", ".csv", ".tsv", ".txt", ".md", ".rtf", ".odt", ".ods", ".odp", ".epub",
    # General Compressed Archives
    ".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz", ".tgz", ".lzh",
    # Explicitly disposable temp/cache extensions
    ".tmp", ".temp", ".crdownload", ".part", ".dmp", ".log",
}

DEFAULT_PROTECTED_EXTENSIONS_LIST = [
    ".sys", ".dll", ".pst", ".ost", ".nst", ".wim", ".esd", ".swm",
    ".vhdx", ".vhd", ".vmdk", ".vdi", ".qcow2", ".ova", ".ovf", ".iso", ".img",
    ".mdf", ".ldf", ".accdb", ".mdb", ".sqlite", ".db", ".bak", ".gguf", ".safetensors",
]

FILE_CATEGORIES = {
    "動画 (Video)": {".mp4", ".mov", ".avi", ".mkv", ".wmv", ".flv", ".webm", ".m4v", ".ts", ".m2ts"},
    "アーカイブ・圧縮 (Archive)": {".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz", ".tgz", ".lzh"},
    "ディスクイメージ・仮想環境 (Disk/VM)": {".iso", ".img", ".vhd", ".vhdx", ".vmdk", ".vdi", ".qcow2", ".ova", ".ovf", ".wim", ".esd", ".swm"},
    "メール・DB・バックアップ (Mail/DB)": {".pst", ".ost", ".nst", ".mbox", ".db", ".sqlite", ".sqlite3", ".mdf", ".ldf", ".accdb", ".mdb", ".bak"},
    "インストーラ・実行ファイル (Installer/App)": {".exe", ".msi", ".msix", ".bat", ".cmd"},
    "画像・デザイン (Image/Design)": {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tiff", ".psd", ".ai", ".svg", ".raw", ".cr2", ".nef"},
    "音声 (Audio)": {".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a", ".wma"},
    "ドキュメント・データ (Docs/Data)": {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".csv", ".txt", ".json", ".xml"},
}

PROTECTION_PRESETS = {
    "dev": [".git", "node_modules", ".venv", "venv", "src", "__pycache__", ".idea", ".vscode"],
    "office": ["確定申告", "契約書", "請求書", "重要", "決算", "見積書", "マイナンバー", "給与"],
    "photo": ["家族写真", "原本", "RAW", "アルバム", "結婚式", "旅行写真"],
}


def format_bytes_human(num_bytes: int) -> str:
    if num_bytes < 1024:
        return f"{num_bytes} B"
    for unit in ["KB", "MB", "GB", "TB"]:
        num_bytes /= 1024.0
        if num_bytes < 1024.0 or unit == "TB":
            return f"{num_bytes:.1f} {unit}"
    return f"{num_bytes:.1f} TB"


def detect_google_drive_candidates() -> list:
    """Detect all candidate Google Drive paths on Windows with free disk space info."""
    candidates = []
    seen_norms = set()

    def _add_candidate(path_obj: Path, label_hint: str = ""):
        try:
            if not path_obj.exists():
                return
            abs_str = str(path_obj.resolve())
        except Exception:
            abs_str = str(path_obj)
        norm_p = abs_str.lower().rstrip("\\/")
        if norm_p in seen_norms:
            return
        try:
            usage = shutil.disk_usage(abs_str)
            seen_norms.add(norm_p)
            candidates.append({
                "path": abs_str,
                "label": label_hint or abs_str,
                "free": usage.free,
                "total": usage.total,
                "used": usage.used,
                "percent": round(usage.used / usage.total * 100, 1) if usage.total > 0 else 0,
            })
        except Exception:
            pass

    # 1. Check drive letters for マイドライブ / My Drive or Google Drive volume labels
    bitmask = ctypes.windll.kernel32.GetLogicalDrives()
    for i in range(26):
        if bitmask & (1 << i):
            letter = chr(ord("A") + i)
            drive_root = f"{letter}:\\"
            vol_label = ""
            try:
                vol_buf = ctypes.create_unicode_buffer(261)
                ctypes.windll.kernel32.GetVolumeInformationW(
                    ctypes.c_wchar_p(drive_root),
                    vol_buf,
                    ctypes.sizeof(vol_buf),
                    None, None, None, None, 0
                )
                vol_label = vol_buf.value or ""
            except Exception:
                pass

            for sub in ["マイドライブ", "My Drive"]:
                sub_p = Path(f"{letter}:\\{sub}")
                if sub_p.exists():
                    lbl = f"{letter}:\\{sub}" + (f" ({vol_label})" if vol_label else "")
                    _add_candidate(sub_p, lbl)

            if "google" in vol_label.lower() or "drive" in vol_label.lower():
                _add_candidate(Path(drive_root), f"{drive_root} ({vol_label})")

    # 2. Check user profile Google Drive folders
    user_profile = Path(os.environ.get("USERPROFILE", "C:\\Users\\Default"))
    for name in ["Google Drive", "Google ドライブ", "My Drive", "マイドライブ"]:
        cand = user_profile / name
        if cand.exists():
            _add_candidate(cand, f"ユーザーフォルダ ({name})")

    return candidates


def detect_google_drive_default() -> str:
    """Detect Google Drive folder on Windows if available."""
    cands = detect_google_drive_candidates()
    if cands:
        return cands[0]["path"]
    # Check G:\マイドライブ, G:\My Drive, or other drive letters
    for letter in "GHIJKLMNOPQRSTUVWXYZDEF":
        for sub in ["マイドライブ", "My Drive"]:
            candidate = Path(f"{letter}:\\{sub}")
            if candidate.exists():
                return str(candidate)
    # Check user profile Google Drive folders
    user_profile = Path(os.environ.get("USERPROFILE", "C:\\Users\\Default"))
    for name in ["Google Drive", "Google ドライブ", "My Drive", "マイドライブ"]:
        candidate = user_profile / name
        if candidate.exists():
            return str(candidate)
    return r"G:\マイドライブ"


def load_config() -> dict:
    default_cfg = {
        "google_drive_path": detect_google_drive_default(),
        "google_drive_subfolder": "ローカル整理アーカイブ",
        "protect_system_folders": True,
        "protect_appdata": True,
        "protect_mail_and_db": True,
        "protect_virtual_disks": True,
        "protect_dev_and_hidden": True,
        "protect_unknown_extensions": True,
        "protected_extensions": list(DEFAULT_PROTECTED_EXTENSIONS_LIST),
        "custom_protected_paths": [
            str(BASE_DIR),  # Protect this app's own folder by default
            r"C:\システム開発",
        ],
        "custom_protected_keywords": ["backup", "バックアップ", "outlook"],
        "custom_unlocked_paths": [],
        "auto_update_check": True,
        "ui_state": {},
    }
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                saved = json.load(f)
            is_legacy_cfg = "protect_mail_and_db" not in saved
            default_cfg.update(saved)
            # Ensure essential safety extensions (.pst, .wim, .vhdx, etc.) are merged into existing configs
            merged_exts = list(default_cfg.get("protected_extensions", []))
            existing_ext_set = {e.lower() for e in merged_exts}
            for req_ext in DEFAULT_PROTECTED_EXTENSIONS_LIST:
                if req_ext.lower() not in existing_ext_set:
                    merged_exts.append(req_ext)
                    existing_ext_set.add(req_ext.lower())
            default_cfg["protected_extensions"] = merged_exts

            if is_legacy_cfg:
                # Upgrade legacy config with default safe paths and keywords
                cur_paths = list(default_cfg.get("custom_protected_paths", []))
                cur_paths_norm = {p.lower().rstrip("\\/") for p in cur_paths}
                for req_p in [str(BASE_DIR), r"C:\システム開発"]:
                    if req_p.lower().rstrip("\\/") not in cur_paths_norm:
                        cur_paths.append(req_p)
                        cur_paths_norm.add(req_p.lower().rstrip("\\/"))
                default_cfg["custom_protected_paths"] = cur_paths

                cur_kws = list(default_cfg.get("custom_protected_keywords", []))
                cur_kws_norm = {k.lower() for k in cur_kws}
                for req_k in ["backup", "バックアップ", "outlook"]:
                    if req_k.lower() not in cur_kws_norm:
                        cur_kws.append(req_k)
                        cur_kws_norm.add(req_k.lower())
                default_cfg["custom_protected_keywords"] = cur_kws
                try:
                    save_config(default_cfg)
                except Exception:
                    pass
        except Exception:
            pass
    return default_cfg


def save_config(cfg: dict):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def _normalize_log_entry(entry: dict, idx: int = 0) -> dict:
    if not entry.get("id"):
        entry["id"] = str(uuid.uuid4())
    if "can_undo" not in entry:
        action = entry.get("action", "")
        status = entry.get("status", "")
        dest = entry.get("destination", "")
        is_gdrive_op = ("Googleドライブへ移動" in action) or ("Googleドライブへコピー" in action)
        entry["can_undo"] = bool(is_gdrive_op and status == "成功" and dest and dest != "-")
    return entry


def load_operation_logs() -> list:
    if LOG_FILE.exists():
        try:
            with open(LOG_FILE, "r", encoding="utf-8") as f:
                logs = json.load(f)
            changed = False
            for idx, item in enumerate(logs):
                had_id = "id" in item
                had_undo = "can_undo" in item
                _normalize_log_entry(item, idx)
                if not (had_id and had_undo):
                    changed = True
            if changed:
                save_operation_logs(logs)
            return logs
        except Exception:
            return []
    return []


def save_operation_logs(logs: list):
    with open(LOG_FILE, "w", encoding="utf-8") as f:
        json.dump(logs[:200], f, ensure_ascii=False, indent=2)


def append_operation_log(entry: dict) -> dict:
    logs = load_operation_logs()
    entry["id"] = entry.get("id") or str(uuid.uuid4())
    entry["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    _normalize_log_entry(entry)
    logs.insert(0, entry)
    save_operation_logs(logs)
    return entry


def normalize_path(p: str) -> str:
    try:
        return os.path.normcase(os.path.normpath(os.path.abspath(p)))
    except Exception:
        return p.lower().rstrip("\\/")


def check_protection_status(target_path: str, cfg: dict = None) -> dict:
    """
    Determine whether target_path is protected or contains protected items.
    Default is strictly on the SAFE side (初期値は安全側).
    Returns:
      {
        "is_protected": bool,
        "protection_type": "system" | "user" | "contains_protected" | "extension" | None,
        "reason": str,
        "can_unlock": bool
      }
    """
    if cfg is None:
        cfg = load_config()

    norm_target = normalize_path(target_path)
    base_name = os.path.basename(norm_target)
    ext = os.path.splitext(norm_target)[1].lower()
    norm_with_slashes = norm_target + "\\"

    # 1. Root drive check (e.g., C:\) - Strictly locked
    if len(norm_target) <= 3 and norm_target.endswith(":\\"):
        return {
            "is_protected": True,
            "protection_type": "system",
            "reason": "ドライブ直下（ルートディレクトリ）は削除・移動不可",
            "can_unlock": False,
        }

    # 2. Core OS & Manufacturer Recovery folder protection - Strictly locked
    if cfg.get("protect_system_folders", True):
        if base_name in DEFAULT_SYSTEM_PROTECTED_NAMES:
            return {
                "is_protected": True,
                "protection_type": "system",
                "reason": f"システム予約項目 ({base_name})",
                "can_unlock": False,
            }
        for sys_path in DEFAULT_SYSTEM_PROTECTED_PATHS:
            norm_sys = normalize_path(sys_path)
            if norm_target == norm_sys or norm_target.startswith(norm_sys + "\\"):
                return {
                    "is_protected": True,
                    "protection_type": "system",
                    "reason": f"システム・リカバリ保護領域 ({sys_path})",
                    "can_unlock": False,
                }
            if norm_sys.startswith(norm_target + "\\"):
                return {
                    "is_protected": True,
                    "protection_type": "contains_protected",
                    "reason": f"内部にシステム保護領域 ({sys_path}) を含んでいます",
                    "can_unlock": False,
                }

    # 3. AppData protection - Strictly locked
    if cfg.get("protect_appdata", True):
        if "\\appdata\\" in norm_with_slashes:
            return {
                "is_protected": True,
                "protection_type": "system",
                "reason": "アプリケーション設定領域 (AppData)",
                "can_unlock": False,
            }

    # 4. Mail / Outlook active files (.pst, .ost, .nst) - Strictly locked against deletion/cloud move
    if cfg.get("protect_mail_and_db", True):
        if ext in MAIL_PROTECTED_EXTENSIONS:
            return {
                "is_protected": True,
                "protection_type": "system",
                "reason": f"{MAIL_PROTECTED_EXTENSIONS[ext]} [削除・移動禁止]",
                "can_unlock": False,
            }
        for seg in MAIL_PROTECTED_PATH_SEGMENTS:
            if seg in norm_with_slashes:
                return {
                    "is_protected": True,
                    "protection_type": "system",
                    "reason": "Outlook・メール保存領域 [削除・移動禁止]",
                    "can_unlock": False,
                }

    # 5. Virtual Disk Images & OS Recovery Images (.wim, .esd, .vhdx, .vhd, .vmdk, .vdi, etc.)
    if cfg.get("protect_virtual_disks", True):
        if ext in {".wim", ".esd", ".swm", ".vhdx", ".vhd", ".vmdk", ".vdi", ".qcow2", ".ova", ".ovf", ".vmx", ".vbox"}:
            return {
                "is_protected": True,
                "protection_type": "system",
                "reason": f"{VIRTUAL_DISK_PROTECTED_EXTENSIONS.get(ext, f'仮想ディスク ({ext})')} [削除・移動禁止]",
                "can_unlock": False,
            }
        for seg in VIRTUAL_ENV_PATH_SEGMENTS:
            if seg in norm_with_slashes:
                return {
                    "is_protected": True,
                    "protection_type": "system",
                    "reason": "リカバリ・仮想環境領域 [削除・移動禁止]",
                    "can_unlock": False,
                }

    # Check if user explicitly unlocked this specific path (for non-core items below)
    unlocked_norms = {normalize_path(p) for p in cfg.get("custom_unlocked_paths", []) if p}
    if norm_target in unlocked_norms:
        return {
            "is_protected": False,
            "protection_type": None,
            "reason": "",
            "can_unlock": True,
        }

    # 6. User custom protected paths (Whitelist)
    for custom_p in cfg.get("custom_protected_paths", []):
        if not custom_p:
            continue
        norm_custom = normalize_path(custom_p)
        if norm_target == norm_custom:
            return {
                "is_protected": True,
                "protection_type": "user",
                "reason": "ユーザー保護リスト登録済み",
                "can_unlock": True,
            }
        if norm_target.startswith(norm_custom + "\\"):
            return {
                "is_protected": True,
                "protection_type": "user",
                "reason": f"保護フォルダ配下 ({custom_p})",
                "can_unlock": True,
            }
        if norm_custom.startswith(norm_target + "\\"):
            return {
                "is_protected": True,
                "protection_type": "contains_protected",
                "reason": f"内部に保護指定された項目 ({custom_p}) を含んでいます",
                "can_unlock": False,
            }

    # 7. Disk images (.iso, .img), Databases, Backups (.bak), Local AI Models (.gguf), Keys
    if ext in VIRTUAL_DISK_PROTECTED_EXTENSIONS:
        return {
            "is_protected": True,
            "protection_type": "user",
            "reason": f"{VIRTUAL_DISK_PROTECTED_EXTENSIONS[ext]} [安全保護]",
            "can_unlock": True,
        }
    if ext in CRITICAL_DATA_PROTECTED_EXTENSIONS:
        return {
            "is_protected": True,
            "protection_type": "user",
            "reason": f"{CRITICAL_DATA_PROTECTED_EXTENSIONS[ext]} [安全保護]",
            "can_unlock": True,
        }
    if ext in SYSTEM_BINARY_EXTENSIONS:
        return {
            "is_protected": True,
            "protection_type": "system",
            "reason": f"システム・ライブラリファイル ({ext}) [安全保護]",
            "can_unlock": True,
        }

    # 8. Hidden Dot-Folders (.lmstudio, .vscode, .ssh, .git, etc.) & Dev Folders
    if cfg.get("protect_dev_and_hidden", True):
        if "\\." in norm_with_slashes or "\\node_modules\\" in norm_with_slashes or "\\venv\\" in norm_with_slashes:
            return {
                "is_protected": True,
                "protection_type": "user",
                "reason": "アプリ・開発環境設定領域 (.フォルダ) [安全保護]",
                "can_unlock": True,
            }

    # 9. User custom protected keywords
    for kw in cfg.get("custom_protected_keywords", []):
        kw_clean = kw.strip().lower()
        if kw_clean and kw_clean in norm_target:
            return {
                "is_protected": True,
                "protection_type": "user",
                "reason": f"保護キーワード「{kw}」に一致",
                "can_unlock": True,
            }

    # 10. Protected file extensions from config
    if ext and ext in [e.lower() if e.startswith(".") else "." + e.lower() for e in cfg.get("protected_extensions", [])]:
        return {
            "is_protected": True,
            "protection_type": "extension",
            "reason": f"保護対象の拡張子 ({ext})",
            "can_unlock": True,
        }

    # 11. Default-Safe Policy for Executables & Unknown File Extensions
    if cfg.get("protect_unknown_extensions", True) and ext:
        if ext in {".exe", ".msi", ".msix"}:
            in_downloads = ("\\downloads\\" in norm_with_slashes) or ("\\ダウンロード\\" in norm_with_slashes)
            if not in_downloads:
                return {
                    "is_protected": True,
                    "protection_type": "user",
                    "reason": f"プログラム・実行ファイル ({ext}) [安全保護]",
                    "can_unlock": True,
                }
        elif ext not in SAFE_USER_CONTENT_EXTENSIONS:
            return {
                "is_protected": True,
                "protection_type": "user",
                "reason": f"未確認形式 ({ext}) [安全側初期保護]",
                "can_unlock": True,
            }

    return {
        "is_protected": False,
        "protection_type": None,
        "reason": "",
        "can_unlock": True,
    }


def toggle_path_protection(target_path: str) -> tuple[str, dict, dict]:
    """
    Toggle protection status for target_path.
    - If currently protected and can_unlock is False (Core OS / .pst / .vhdx / .wim): returns ("locked_system", cfg, status)
    - If currently protected and can_unlock is True: unlocks it (adds to custom_unlocked_paths / removes from custom_protected_paths)
    - If currently unprotected: locks it (removes from custom_unlocked_paths / adds to custom_protected_paths)
    """
    cfg = load_config()
    abs_target = os.path.abspath(target_path)
    norm_target = normalize_path(abs_target)
    curr_status = check_protection_status(abs_target, cfg)

    custom_prot = list(cfg.get("custom_protected_paths", []))
    custom_unlk = list(cfg.get("custom_unlocked_paths", []))

    if curr_status["is_protected"]:
        if not curr_status.get("can_unlock", True):
            return "locked_system", cfg, curr_status
        # Remove from custom_protected_paths if directly listed
        custom_prot = [p for p in custom_prot if normalize_path(p) != norm_target]
        # Add to custom_unlocked_paths so built-in default-safe rules allow it
        if norm_target not in {normalize_path(p) for p in custom_unlk}:
            custom_unlk.append(abs_target)
        action_taken = "unprotected"
    else:
        # Remove from custom_unlocked_paths
        custom_unlk = [p for p in custom_unlk if normalize_path(p) != norm_target]
        cfg["custom_unlocked_paths"] = custom_unlk
        # Check if removing from custom_unlocked_paths already re-protected it via default rules
        recheck = check_protection_status(abs_target, cfg)
        if not recheck["is_protected"]:
            if norm_target not in {normalize_path(p) for p in custom_prot}:
                custom_prot.append(abs_target)
        action_taken = "protected"

    cfg["custom_protected_paths"] = custom_prot
    cfg["custom_unlocked_paths"] = custom_unlk
    save_config(cfg)
    new_status = check_protection_status(abs_target, cfg)
    return action_taken, cfg, new_status


def categorize_file(ext: str) -> str:
    ext_lower = ext.lower()
    for cat_name, exts in FILE_CATEGORIES.items():
        if ext_lower in exts:
            return cat_name
    return "その他 (Other)"


# Windows Recycle Bin via SHFileOperationW
class SHFILEOPSTRUCTW(ctypes.Structure):
    _fields_ = [
        ("hwnd", wintypes.HWND),
        ("wFunc", wintypes.UINT),
        ("pFrom", wintypes.LPCWSTR),
        ("pTo", wintypes.LPCWSTR),
        ("fFlags", wintypes.WORD),
        ("fAnyOperationsAborted", wintypes.BOOL),
        ("hNameMappings", wintypes.LPVOID),
        ("lpszProgressTitle", wintypes.LPCWSTR),
    ]


def send_to_recycle_bin(path_str: str) -> tuple[bool, str]:
    """Move a file or directory to the Windows Recycle Bin using Shell32 SHFileOperationW."""
    FO_DELETE = 0x0003
    FOF_ALLOWUNDO = 0x0040
    FOF_NOCONFIRMATION = 0x0010
    FOF_NOERRORUI = 0x0400
    FOF_SILENT = 0x0004

    abs_path = os.path.abspath(path_str)
    if not os.path.exists(abs_path):
        return False, "対象ファイルまたはフォルダが存在しません"

    # Double null-terminated string required by SHFileOperationW
    from_buffer = ctypes.create_unicode_buffer(abs_path + "\0\0")
    op = SHFILEOPSTRUCTW()
    op.hwnd = 0
    op.wFunc = FO_DELETE
    op.pFrom = ctypes.cast(from_buffer, wintypes.LPCWSTR)
    op.pTo = None
    op.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_NOERRORUI | FOF_SILENT
    op.fAnyOperationsAborted = False
    op.hNameMappings = None
    op.lpszProgressTitle = None

    res = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
    if res == 0 and not op.fAnyOperationsAborted:
        return True, "ゴミ箱へ移動しました"
    else:
        return False, f"ゴミ箱への移動に失敗しました (エラーコード: {res})"


def _compute_edge_hash(file_path: str, file_size: int, chunk_size: int = 65536) -> str | None:
    """Compute SHA-256 of first 64KB + last 64KB (or full file if <= 128KB)."""
    try:
        h = hashlib.sha256()
        with open(file_path, "rb") as f:
            if file_size <= chunk_size * 2:
                while True:
                    data = f.read(65536)
                    if not data:
                        break
                    h.update(data)
            else:
                head = f.read(chunk_size)
                h.update(head)
                f.seek(max(0, file_size - chunk_size))
                tail = f.read(chunk_size)
                h.update(tail)
        return h.hexdigest()
    except (PermissionError, OSError):
        return None


def _compute_full_sha256(file_path: str) -> str | None:
    """Compute full file SHA-256 in 1MB chunks."""
    try:
        h = hashlib.sha256()
        with open(file_path, "rb") as f:
            while True:
                chunk = f.read(1024 * 1024)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()
    except (PermissionError, OSError):
        return None


# Global Scan Manager
class ScanSession:
    def __init__(self):
        self.lock = threading.Lock()
        self.status = "idle"  # idle, scanning, completed, cancelled, error
        self.root_path = ""
        self.scanned_files = 0
        self.scanned_dirs = 0
        self.total_size = 0
        self.current_path = ""
        self.start_time = 0.0
        self.elapsed_sec = 0.0
        self.error_msg = ""
        self.cancel_flag = False
        # Data structures populated on completion
        self.dir_sizes = {}          # norm_path -> int
        self.dir_Read_meta = {}      # norm_path -> {"path": str, "name": str, "mtime": float, "file_count": int, "dir_count": int}
        self.dir_children = {}       # norm_path -> list of child item dicts
        self.large_files = []        # top large files across the scan
        self.category_Totals = {}    # category -> {"size": int, "count": int}
        self._hash_cache = {}        # (norm_path, fsize, fmtime) -> full_sha256

    def start_scan(self, target_path: str, min_large_file_mb: int = 10):
        with self.lock:
            if self.status == "scanning":
                self.cancel_flag = True
        # Wait briefly if previous scan is winding down
        time.sleep(0.1)

        with self.lock:
            self.status = "scanning"
            self.root_path = os.path.abspath(target_path)
            self.scanned_files = 0
            self.scanned_dirs = 0
            self.total_size = 0
            self.current_path = self.root_path
            self.start_time = time.time()
            self.elapsed_sec = 0.0
            self.error_msg = ""
            self.cancel_flag = False
            self.dir_sizes = {}
            self.dir_Read_meta = {}
            self.dir_children = {}
            self.large_files = []
            self.category_Totals = {cat: {"size": 0, "count": 0} for cat in list(FILE_CATEGORIES.keys()) + ["その他 (Other)"]}
            self._hash_cache = {}

        t = threading.Thread(target=self._run_scan, args=(self.root_path, min_large_file_mb), daemon=True)
        t.start()

    def _run_scan(self, root_path: str, min_large_file_mb: int):
        try:
            if not os.path.exists(root_path):
                with self.lock:
                    self.status = "error"
                    self.error_msg = f"指定されたパスが存在しません: {root_path}"
                return

            min_large_bytes = max(1, min_large_file_mb) * 1024 * 1024
            large_files_list = []
            cat_totals = {cat: {"size": 0, "count": 0} for cat in list(FILE_CATEGORIES.keys()) + ["その他 (Other)"]}
            dir_sizes = {}
            dir_meta = {}
            dir_direct_files = {}
            dir_direct_subdirs = {}

            # Iterative post-order traversal using stack so we don't hit recursion limit
            # Stack entries: (abs_path, visited_flag)
            stack = [(root_path, False)]

            while stack:
                if self.cancel_flag:
                    with self.lock:
                        self.status = "cancelled"
                    return

                curr_path, visited = stack.pop()
                norm_curr = normalize_path(curr_path)

                if not visited:
                    stack.append((curr_path, True))
                    files_here = []
                    subdirs_here = []

                    try:
                        with os.scandir(curr_path) as it:
                            for entry in it:
                                if self.cancel_flag:
                                    break
                                try:
                                    # Skip symlinks/reparse points to avoid infinite loops and double counting
                                    if entry.is_symlink():
                                        continue
                                    # On Windows, check FILE_ATTRIBUTE_REPARSE_POINT (0x400)
                                    st = entry.stat(follow_symlinks=False)
                                    if getattr(st, "st_file_attributes", 0) & 0x400:
                                        continue

                                    if entry.is_dir(follow_symlinks=False):
                                        subdirs_here.append((entry.path, entry.name, st.st_mtime))
                                        stack.append((entry.path, False))
                                    elif entry.is_file(follow_symlinks=False):
                                        fsize = st.st_size
                                        fmtime = st.st_mtime
                                        fatime = getattr(st, "st_atime", fmtime)
                                        files_here.append((entry.path, entry.name, fsize, fmtime, fatime))

                                        ext = os.path.splitext(entry.name)[1]
                                        cat = categorize_file(ext)
                                        cat_totals[cat]["size"] += fsize
                                        cat_totals[cat]["count"] += 1

                                        if fsize >= min_large_bytes:
                                            large_files_list.append({
                                                "path": entry.path,
                                                "name": entry.name,
                                                "type": "file",
                                                "size": fsize,
                                                "mtime": fmtime,
                                                "atime": fatime,
                                                "category": cat,
                                                "ext": ext.lower()
                                            })
                                except (PermissionError, OSError):
                                    continue
                    except (PermissionError, OSError):
                        pass

                    dir_direct_files[norm_curr] = files_here
                    dir_direct_subdirs[norm_curr] = subdirs_here

                    with self.lock:
                        self.scanned_dirs += 1
                        self.scanned_files += len(files_here)
                        self.total_size += sum(f[2] for f in files_here)
                        if self.scanned_dirs % 15 == 0:
                            self.current_path = curr_path
                        self.elapsed_sec = round(time.time() - self.start_time, 1)

                else:
                    # Post-order: all children of curr_path have been processed
                    files_here = dir_direct_files.get(norm_curr, [])
                    subdirs_here = dir_direct_subdirs.get(norm_curr, [])

                    own_file_size = sum(f[2] for f in files_here)
                    sub_dir_size = sum(dir_sizes.get(normalize_path(sd[0]), 0) for sd in subdirs_here)
                    total_dir_size = own_file_size + sub_dir_size
                    dir_sizes[norm_curr] = total_dir_size

                    try:
                        dmtime = os.path.getmtime(curr_path)
                    except OSError:
                        dmtime = 0

                    dir_meta[norm_curr] = {
                        "path": curr_path,
                        "name": os.path.basename(curr_path) or curr_path,
                        "size": total_dir_size,
                        "mtime": dmtime,
                        "file_count": len(files_here),
                        "dir_count": len(subdirs_here),
                    }

            # Sort large files descending by size and keep top 500
            large_files_list.sort(key=lambda x: x["size"], reverse=True)
            large_files_list = large_files_list[:500]

            with self.lock:
                self.dir_sizes = dir_sizes
                self.dir_Read_meta = dir_meta
                self.dir_children = {
                    "files": dir_direct_files,
                    "subdirs": dir_direct_subdirs
                }
                self.large_files = large_files_list
                self.category_Totals = cat_totals
                self.elapsed_sec = round(time.time() - self.start_time, 1)
                self.status = "completed"
                self.current_path = root_path

        except Exception as e:
            with self.lock:
                self.status = "error"
                self.error_msg = str(e)

    def get_directory_view(self, target_dir: str, cfg: dict) -> dict:
        """Return children of target_dir enriched with sizes and protection status."""
        norm_target = normalize_path(target_dir)
        with self.lock:
            if norm_target not in self.dir_sizes:
                return {"error": "このフォルダはまだスキャン結果に含まれていません"}

            meta = self.dir_Read_meta.get(norm_target, {})
            parent_size = self.dir_sizes.get(norm_target, 0)
            files_here = self.dir_children.get("files", {}).get(norm_target, [])
            subdirs_here = self.dir_children.get("subdirs", {}).get(norm_target, [])

        items = []
        now_ts = time.time()

        for sd_path, sd_name, sd_mtime in subdirs_here:
            if not os.path.exists(sd_path):
                continue
            sd_norm = normalize_path(sd_path)
            sd_size = self.dir_sizes.get(sd_norm, 0)
            sd_meta = self.dir_Read_meta.get(sd_norm, {})
            prot = check_protection_status(sd_path, cfg)
            days_unused = int(max(0, now_ts - sd_mtime) // 86400) if sd_mtime else 0
            items.append({
                "path": sd_path,
                "name": sd_name,
                "type": "dir",
                "size": sd_size,
                "ratio": round((sd_size / parent_size * 100), 1) if parent_size > 0 else 0.0,
                "mtime": sd_mtime,
                "days_unused": days_unused,
                "category": "フォルダ",
                "item_count": sd_meta.get("file_count", 0) + sd_meta.get("dir_count", 0),
                "protection": prot
            })

        for f_path, f_name, f_size, f_mtime, f_atime in files_here:
            if not os.path.exists(f_path):
                continue
            ext = os.path.splitext(f_name)[1]
            cat = categorize_file(ext)
            prot = check_protection_status(f_path, cfg)
            last_used = max(f_mtime, f_atime) if f_atime else f_mtime
            days_unused = int(max(0, now_ts - last_used) // 86400) if last_used else 0
            items.append({
                "path": f_path,
                "name": f_name,
                "type": "file",
                "size": f_size,
                "ratio": round((f_size / parent_size * 100), 1) if parent_size > 0 else 0.0,
                "mtime": f_mtime,
                "days_unused": days_unused,
                "category": cat,
                "item_count": 1,
                "protection": prot
            })

        items.sort(key=lambda x: x["size"], reverse=True)

        # Build breadcrumbs from root_path to target_dir
        breadcrumbs = []
        root_norm = normalize_path(self.root_path)
        curr = os.path.abspath(target_dir)
        while True:
            breadcrumbs.append({
                "name": os.path.basename(curr) or curr,
                "path": curr
            })
            if normalize_path(curr) == root_norm:
                break
            parent = os.path.dirname(curr)
            if parent == curr:
                break
            curr = parent
        breadcrumbs.reverse()

        return {
            "path": os.path.abspath(target_dir),
            "root_path": self.root_path,
            "total_size": parent_size,
            "meta": meta,
            "breadcrumbs": breadcrumbs,
            "items": items
        }

    def get_duplicates(self, cfg: dict, min_size_bytes: int = 1024 * 1024) -> dict:
        """
        Detect duplicate files across the scanned directory tree using multi-stage hashing:
        1. Group by exact file size (>= min_size_bytes)
        2. Group by edge SHA-256 (first 64KB + last 64KB)
        3. Group by full file SHA-256
        """
        with self.lock:
            all_dir_files = dict(self.dir_children.get("files", {}))

        size_groups = {}
        for files_list in all_dir_files.values():
            for f_path, f_name, f_size, f_mtime, f_atime in files_list:
                if f_size < min_size_bytes:
                    continue
                if not os.path.exists(f_path):
                    continue
                size_groups.setdefault(f_size, []).append((f_path, f_name, f_size, f_mtime, f_atime))

        now_ts = time.time()
        duplicate_groups = []
        total_wasted_size = 0

        for f_size, candidates in size_groups.items():
            if len(candidates) < 2:
                continue

            # Stage 1: Edge hash (first 64KB + last 64KB)
            edge_groups = {}
            for item in candidates:
                f_path = item[0]
                ehash = _compute_edge_hash(f_path, f_size)
                if ehash:
                    edge_groups.setdefault(ehash, []).append(item)

            # Stage 2: Full SHA-256 hash
            for ehash, edge_items in edge_groups.items():
                if len(edge_items) < 2:
                    continue

                full_groups = {}
                for item in edge_items:
                    f_path, f_name, f_sz, f_mtime, f_atime = item
                    cache_key = (normalize_path(f_path), f_sz, f_mtime)
                    if f_sz <= 131072:
                        # Edge hash already read the entire file
                        fhash = ehash
                    else:
                        with self.lock:
                            fhash = self._hash_cache.get(cache_key)
                        if not fhash:
                            fhash = _compute_full_sha256(f_path)
                            if fhash:
                                with self.lock:
                                    self._hash_cache[cache_key] = fhash
                    if fhash:
                        full_groups.setdefault(fhash, []).append(item)

                for fhash, dup_items in full_groups.items():
                    if len(dup_items) < 2:
                        continue

                    # Sort files by mtime ascending (oldest/original first)
                    dup_items.sort(key=lambda x: (x[3], x[0]))
                    enriched_files = []
                    for f_path, f_name, f_sz, f_mtime, f_atime in dup_items:
                        prot = check_protection_status(f_path, cfg)
                        days_unused = int(max(0, now_ts - f_mtime) // 86400) if f_mtime else 0
                        ext = os.path.splitext(f_name)[1]
                        enriched_files.append({
                            "path": f_path,
                            "name": f_name,
                            "type": "file",
                            "size": f_sz,
                            "mtime": f_mtime,
                            "days_unused": days_unused,
                            "category": categorize_file(ext),
                            "protection": prot
                        })

                    wasted = f_size * (len(enriched_files) - 1)
                    total_wasted_size += wasted
                    duplicate_groups.append({
                        "hash": fhash,
                        "size": f_size,
                        "wasted_size": wasted,
                        "files": enriched_files
                    })

        duplicate_groups.sort(key=lambda g: g["wasted_size"], reverse=True)
        return {
            "duplicate_groups": duplicate_groups[:200],
            "total_wasted_size": total_wasted_size,
            "group_count": len(duplicate_groups)
        }

    def get_recommendations(self, cfg: dict) -> dict:
        """
        Analyze scanned files (excluding protected files) and return smart cleanup recommendations:
        - gdrive_candidates: Large/unused media, archives, disk images, documents suitable for Google Drive archiving
        - delete_candidates: Installers in Downloads, temporary/backup/log/cache files suitable for Recycle Bin
        """
        with self.lock:
            all_dir_files = dict(self.dir_children.get("files", {}))
            root_norm = normalize_path(self.root_path)

        now_ts = time.time()
        gdrive_candidates = []
        delete_candidates = []

        temp_exts = {".tmp", ".temp", ".dmp", ".crdownload", ".part"}
        installer_exts = {".msi", ".exe", ".msix"}
        gdrive_target_cats = {
            "動画 (Video)",
            "アーカイブ・圧縮 (Archive)",
            "ドキュメント・データ (Docs/Data)",
            "画像・デザイン (Image/Design)",
            "音声 (Audio)",
        }

        for files_list in all_dir_files.values():
            for f_path, f_name, f_size, f_mtime, f_atime in files_list:
                if f_size <= 0 or not os.path.exists(f_path):
                    continue

                prot = check_protection_status(f_path, cfg)
                if prot["is_protected"]:
                    continue

                ext = os.path.splitext(f_name)[1].lower()
                cat = categorize_file(ext)
                days_unused = int(max(0, now_ts - f_mtime) // 86400) if f_mtime else 0
                norm_p = normalize_path(f_path)
                rel_norm = norm_p[len(root_norm):] if norm_p.startswith(root_norm) else norm_p
                name_lower = f_name.lower()

                # 1. Check delete candidates (strictly safe temporary/downloaded installer items)
                del_reason = None
                if ext in temp_exts:
                    del_reason = f"一時・未完了ファイル ({ext})"
                elif ext == ".log" and (f_size >= 10 * 1024 * 1024 and days_unused >= 30):
                    del_reason = "30日以上経過した肥大化ログファイル (.log)"
                elif ext in installer_exts:
                    in_downloads = ("\\downloads\\" in norm_p) or ("\\ダウンロード\\" in norm_p)
                    if in_downloads and days_unused >= 7:
                        del_reason = f"ダウンロードフォルダ内の古いインストーラー ({days_unused}日経過)"
                elif any(seg in rel_norm for seg in ("\\temp\\", "\\tmp\\", "\\cache\\", "\\caches\\", "\\crashdumps\\")):
                    if f_size >= 1024 * 1024 and days_unused >= 7:
                        del_reason = "キャッシュ・一時領域ファイル"

                if del_reason:
                    delete_candidates.append({
                        "path": f_path,
                        "name": f_name,
                        "type": "file",
                        "size": f_size,
                        "mtime": f_mtime,
                        "days_unused": days_unused,
                        "category": cat,
                        "ext": ext,
                        "reason": del_reason,
                        "recommendation_type": "delete",
                        "protection": prot
                    })
                    continue

                # 2. Check Google Drive candidates (only safe user media/docs/archives not modified recently)
                gdrive_reason = None
                short_cat = cat.split(" ")[0]
                if cat in gdrive_target_cats and days_unused >= 14:
                    if f_size >= 50 * 1024 * 1024 and days_unused >= 90:
                        gdrive_reason = f"90日以上未更新の大容量{short_cat} ({days_unused}日未更新)"
                    elif f_size >= 50 * 1024 * 1024 and days_unused >= 30:
                        gdrive_reason = f"30日以上未更新の大容量{short_cat} ({days_unused}日未更新)"
                    elif f_size >= 200 * 1024 * 1024 and days_unused >= 14:
                        gdrive_reason = f"ローカル容量を圧迫している大容量{short_cat} ({format_bytes_human(f_size)})"
                    elif f_size >= 20 * 1024 * 1024 and days_unused >= 60:
                        gdrive_reason = f"長期間未更新({days_unused}日)の{short_cat}ファイル"

                if gdrive_reason:
                    gdrive_candidates.append({
                        "path": f_path,
                        "name": f_name,
                        "type": "file",
                        "size": f_size,
                        "mtime": f_mtime,
                        "days_unused": days_unused,
                        "category": cat,
                        "ext": ext,
                        "reason": gdrive_reason,
                        "recommendation_type": "gdrive",
                        "protection": prot
                    })

        gdrive_candidates.sort(key=lambda x: x["size"], reverse=True)
        delete_candidates.sort(key=lambda x: x["size"], reverse=True)

        gdrive_total_size = sum(x["size"] for x in gdrive_candidates)
        delete_total_size = sum(x["size"] for x in delete_candidates)

        return {
            "gdrive_candidates": gdrive_candidates[:200],
            "delete_candidates": delete_candidates[:200],
            "gdrive_total_size": gdrive_total_size,
            "delete_total_size": delete_total_size,
            "gdrive_count": len(gdrive_candidates),
            "delete_count": len(delete_candidates),
        }


SCAN_SESSION = ScanSession()


def get_system_drives_and_shortcuts() -> dict:
    drives = []
    bitmask = ctypes.windll.kernel32.GetLogicalDrives()
    for i in range(26):
        if bitmask & (1 << i):
            letter = chr(ord("A") + i)
            drive_path = f"{letter}:\\"
            try:
                usage = shutil.disk_usage(drive_path)
                vol_buf = ctypes.create_unicode_buffer(261)
                ctypes.windll.kernel32.GetVolumeInformationW(
                    ctypes.c_wchar_p(drive_path),
                    vol_buf,
                    ctypes.sizeof(vol_buf),
                    None, None, None, None, 0
                )
                label = vol_buf.value or "ローカルディスク"
                drives.append({
                    "path": drive_path,
                    "label": f"{letter}: ({label})",
                    "total": usage.total,
                    "used": usage.used,
                    "free": usage.free,
                    "percent": round(usage.used / usage.total * 100, 1) if usage.total > 0 else 0
                })
            except Exception:
                continue

    user_profile = Path(os.environ.get("USERPROFILE", "C:\\Users\\Default"))
    shortcuts = [
        {"name": "ユーザーフォルダ", "path": str(user_profile), "icon": "👤"},
        {"name": "ダウンロード", "path": str(user_profile / "Downloads"), "icon": "📥"},
        {"name": "デスクトップ", "path": str(user_profile / "Desktop"), "icon": "🖥️"},
        {"name": "ドキュメント", "path": str(user_profile / "Documents"), "icon": "📄"},
        {"name": "ビデオ", "path": str(user_profile / "Videos"), "icon": "🎬"},
        {"name": "ピクチャ", "path": str(user_profile / "Pictures"), "icon": "🖼️"},
    ]
    shortcuts = [s for s in shortcuts if os.path.exists(s["path"])]
    google_drive_candidates = detect_google_drive_candidates()
    return {
        "drives": drives,
        "shortcuts": shortcuts,
        "google_drive_candidates": google_drive_candidates,
    }


def open_folder_dialog(initial_dir: str = "") -> str:
    """Open native Windows folder selection dialog via PowerShell."""
    ps_script = f"""
    Add-Type -AssemblyName System.Windows.Forms
    $f = New-Object System.Windows.Forms.FolderBrowserDialog
    $f.Description = 'フォルダを選択してください'
    $f.ShowNewFolderButton = $true
    if ('{initial_dir}' -ne '' -and (Test-Path '{initial_dir}')) {{
        $f.SelectedPath = '{initial_dir}'
    }}
    $form = New-Object System.Windows.Forms.Form
    $form.TopMost = $true
    if ($f.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {{
        Write-Output $f.SelectedPath
    }}
    """
    try:
        res = subprocess.run(
            ["powershell", "-NoProfile", "-STA", "-Command", ps_script],
            capture_output=True,
            text=True,
            timeout=120
        )
        return res.stdout.strip()
    except Exception:
        return ""


class ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = False


class RequestHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(STATIC_DIR), **kwargs)

    def log_message(self, format, *args):
        # Suppress noisy polling logs
        if "/api/scan/status" in args[0]:
            return
        sys.stderr.write("%s - - [%s] %s\n" % (self.address_string(), self.log_date_time_string(), format % args))

    def send_json(self, data: dict, status_code: int = 200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_json_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        raw = self.rfile.read(length).decode("utf-8")
        return json.loads(raw)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        route = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        if route == "/api/system/info":
            info = get_system_drives_and_shortcuts()
            info["config"] = load_config()
            return self.send_json(info)

        if route == "/api/scan/status":
            cfg = load_config()
            with SCAN_SESSION.lock:
                resp = {
                    "status": SCAN_SESSION.status,
                    "root_path": SCAN_SESSION.root_path,
                    "scanned_files": SCAN_SESSION.scanned_files,
                    "scanned_dirs": SCAN_SESSION.scanned_dirs,
                    "total_size": SCAN_SESSION.total_size,
                    "current_path": SCAN_SESSION.current_path,
                    "elapsed_sec": SCAN_SESSION.elapsed_sec,
                    "error_msg": SCAN_SESSION.error_msg,
                    "category_totals": SCAN_SESSION.category_Totals,
                }
            return self.send_json(resp)

        if route == "/api/scan/dir":
            target = query.get("path", [SCAN_SESSION.root_path])[0]
            cfg = load_config()
            view = SCAN_SESSION.get_directory_view(target, cfg)
            return self.send_json(view)

        if route == "/api/scan/large":
            cfg = load_config()
            now_ts = time.time()
            with SCAN_SESSION.lock:
                raw_large = list(SCAN_SESSION.large_files)
                # Also get top large directories (excluding root itself)
                root_norm = normalize_path(SCAN_SESSION.root_path)
                dir_list = []
                for norm_p, meta in SCAN_SESSION.dir_Read_meta.items():
                    if norm_p == root_norm:
                        continue
                    if meta["size"] >= 50 * 1024 * 1024:  # >= 50MB
                        dir_list.append(meta)

            dir_list.sort(key=lambda x: x["size"], reverse=True)
            dir_list = dir_list[:200]

            enriched_files = []
            for f in raw_large:
                if not os.path.exists(f["path"]):
                    continue
                prot = check_protection_status(f["path"], cfg)
                last_used = max(f["mtime"], f.get("atime", f["mtime"]))
                days_unused = int(max(0, now_ts - last_used) // 86400) if last_used else 0
                item = dict(f)
                item["days_unused"] = days_unused
                item["protection"] = prot
                enriched_files.append(item)

            enriched_dirs = []
            for d in dir_list:
                if not os.path.exists(d["path"]):
                    continue
                prot = check_protection_status(d["path"], cfg)
                days_unused = int(max(0, now_ts - d["mtime"]) // 86400) if d["mtime"] else 0
                enriched_dirs.append({
                    "path": d["path"],
                    "name": d["name"],
                    "type": "dir",
                    "size": d["size"],
                    "mtime": d["mtime"],
                    "days_unused": days_unused,
                    "category": "フォルダ",
                    "protection": prot
                })

            return self.send_json({
                "large_files": enriched_files,
                "large_dirs": enriched_dirs
            })

        if route == "/api/scan/duplicates":
            cfg = load_config()
            try:
                min_mb = float(query.get("min_mb", ["1"])[0])
            except (ValueError, TypeError):
                min_mb = 1.0
            min_bytes = max(1, int(min_mb * 1024 * 1024))
            result = SCAN_SESSION.get_duplicates(cfg, min_size_bytes=min_bytes)
            return self.send_json(result)

        if route == "/api/scan/recommendations":
            cfg = load_config()
            result = SCAN_SESSION.get_recommendations(cfg)
            return self.send_json(result)

        if route == "/api/logs":
            return self.send_json({"logs": load_operation_logs()})

        if route == "/favicon.ico":
            ico_candidates = [
                BUNDLE_DIR / "assets" / "app_icon.ico",
                BASE_DIR / "assets" / "app_icon.ico",
                BASE_DIR / "app_icon.ico",
            ]
            for ico_p in ico_candidates:
                if ico_p.exists():
                    data = ico_p.read_bytes()
                    self.send_response(200)
                    self.send_header("Content-Type", "image/x-icon")
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                    return

        if route == "/api/tray/ping":
            return self.send_json({"ok": True, "app": "DiskGuard_DriveMover"})

        return super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        route = parsed.path
        body = self.read_json_body()

        if route == "/api/dialog/folder":
            initial = body.get("initial_dir", "")
            selected = open_folder_dialog(initial)
            return self.send_json({"selected_path": selected})

        if route == "/api/scan/start":
            target_path = body.get("path", "").strip()
            min_mb = int(body.get("min_large_mb", 10))
            if not target_path or not os.path.exists(target_path):
                return self.send_json({"error": f"有効なフォルダパスを指定してください: {target_path}"}, 400)
            SCAN_SESSION.start_scan(target_path, min_mb)
            return self.send_json({"ok": True, "root_path": os.path.abspath(target_path)})

        if route == "/api/scan/cancel":
            with SCAN_SESSION.lock:
                SCAN_SESSION.cancel_flag = True
            return self.send_json({"ok": True})

        if route == "/api/config/save":
            cfg = load_config()
            for key in [
                "google_drive_path",
                "google_drive_subfolder",
                "protect_system_folders",
                "protect_appdata",
                "protect_mail_and_db",
                "protect_virtual_disks",
                "protect_dev_and_hidden",
                "protect_unknown_extensions",
                "protected_extensions",
                "custom_protected_paths",
                "custom_protected_keywords",
                "custom_unlocked_paths",
            ]:
                if key in body:
                    cfg[key] = body[key]
            save_config(cfg)
            return self.send_json({"ok": True, "config": cfg})

        if route == "/api/protection/preset":
            preset = str(body.get("preset", "")).strip().lower()
            if preset not in PROTECTION_PRESETS:
                return self.send_json({"error": f"不明な保護プリセットです: {preset}"}, 400)
            cfg = load_config()
            existing_kw = list(cfg.get("custom_protected_keywords", []))
            existing_lower = {k.strip().lower() for k in existing_kw if k.strip()}
            added_keywords = []
            for kw in PROTECTION_PRESETS[preset]:
                if kw.lower() not in existing_lower:
                    existing_kw.append(kw)
                    existing_lower.add(kw.lower())
                    added_keywords.append(kw)
            cfg["custom_protected_keywords"] = existing_kw
            save_config(cfg)
            return self.send_json({
                "ok": True,
                "preset": preset,
                "added_keywords": added_keywords,
                "config": cfg
            })

        if route == "/api/protection/toggle":
            target_path = body.get("path", "").strip()
            if not target_path:
                return self.send_json({"error": "パスが指定されていません"}, 400)
            action_taken, cfg, new_status = toggle_path_protection(target_path)
            if action_taken == "locked_system":
                return self.send_json({
                    "error": f"システム・重要データの安全規制によりロック解除できません: {new_status.get('reason', '')}",
                    "protection": new_status
                }, 400)
            return self.send_json({
                "ok": True,
                "action": action_taken,
                "config": cfg,
                "protection": new_status
            })

        if route == "/api/explorer/open":
            target_path = body.get("path", "").strip()
            if not target_path or not os.path.exists(target_path):
                return self.send_json({"error": "パスが存在しません"}, 400)
            abs_target = os.path.abspath(target_path)
            subprocess.Popen(["explorer", f"/select,{abs_target}"])
            return self.send_json({"ok": True})

        if route == "/api/action/delete":
            paths = body.get("paths", [])
            mode = body.get("mode", "recycle")  # "recycle" or "permanent"
            cfg = load_config()
            results = []
            freed_bytes = 0

            for p in paths:
                abs_p = os.path.abspath(p)
                prot = check_protection_status(abs_p, cfg)
                if prot["is_protected"]:
                    results.append({
                        "path": abs_p,
                        "ok": False,
                        "message": f"保護規制によりブロックされました: {prot['reason']}"
                    })
                    continue

                if not os.path.exists(abs_p):
                    results.append({"path": abs_p, "ok": False, "message": "対象が既に存在しません"})
                    continue

                # Estimate size before deletion
                item_size = SCAN_SESSION.dir_sizes.get(normalize_path(abs_p), 0)
                if item_size == 0 and os.path.isfile(abs_p):
                    try:
                        item_size = os.path.getsize(abs_p)
                    except OSError:
                        item_size = 0

                if mode == "recycle":
                    ok, msg = send_to_recycle_bin(abs_p)
                else:
                    try:
                        if os.path.isdir(abs_p):
                            shutil.rmtree(abs_p)
                        else:
                            os.remove(abs_p)
                        ok, msg = True, "完全に削除しました"
                    except Exception as e:
                        ok, msg = False, f"削除エラー: {e}"

                if ok:
                    freed_bytes += item_size
                    append_operation_log({
                        "action": "ゴミ箱へ移動" if mode == "recycle" else "完全削除",
                        "source": abs_p,
                        "destination": "ゴミ箱" if mode == "recycle" else "-",
                        "size": item_size,
                        "status": "成功",
                        "can_undo": False
                    })
                results.append({"path": abs_p, "ok": ok, "message": msg, "size": item_size})

            return self.send_json({
                "ok": True,
                "results": results,
                "freed_bytes": freed_bytes
            })

        if route == "/api/action/gdrive":
            paths = body.get("paths", [])
            gdrive_root = body.get("gdrive_path", "").strip()
            subfolder = body.get("subfolder", "").strip()
            preserve_structure = bool(body.get("preserve_structure", True))
            copy_only = bool(body.get("copy_only", False))

            cfg = load_config()
            if not gdrive_root:
                gdrive_root = cfg.get("google_drive_path", "")

            if not gdrive_root:
                return self.send_json({"error": "Googleドライブの移動先フォルダが設定されていません"}, 400)

            dest_base = Path(gdrive_root)
            if subfolder:
                dest_base = dest_base / subfolder

            try:
                dest_base.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                return self.send_json({"error": f"移動先フォルダを作成・アクセスできません ({dest_base}): {e}"}, 400)

            # Pre-flight disk free space check on destination drive
            total_required_bytes = 0
            for p in paths:
                abs_p = os.path.abspath(p)
                if not os.path.exists(abs_p):
                    continue
                prot = check_protection_status(abs_p, cfg)
                if prot["is_protected"] and not copy_only:
                    continue
                sz = SCAN_SESSION.dir_sizes.get(normalize_path(abs_p), 0)
                if sz == 0 and os.path.isfile(abs_p):
                    try:
                        sz = os.path.getsize(abs_p)
                    except OSError:
                        sz = 0
                total_required_bytes += sz

            try:
                dest_usage = shutil.disk_usage(str(dest_base))
                if total_required_bytes > dest_usage.free:
                    return self.send_json({
                        "error": (
                            f"移動先ドライブの空き容量が不足しています（対象合計: {format_bytes_human(total_required_bytes)} / "
                            f"空き容量: {format_bytes_human(dest_usage.free)}）。安全のため処理を中断しました。"
                        ),
                        "required_bytes": total_required_bytes,
                        "free_bytes": dest_usage.free,
                    }, 400)
            except Exception:
                pass

            results = []
            moved_bytes = 0

            for p in paths:
                abs_p = os.path.abspath(p)
                prot = check_protection_status(abs_p, cfg)
                if prot["is_protected"] and not copy_only:
                    results.append({
                        "path": abs_p,
                        "ok": False,
                        "message": f"保護規制により移動がブロックされました: {prot['reason']}"
                    })
                    continue

                if not os.path.exists(abs_p):
                    results.append({"path": abs_p, "ok": False, "message": "対象が存在しません"})
                    continue

                # Determine destination path
                if preserve_structure:
                    # Keep drive + parent relative structure e.g. C_Drive/Users/...
                    drive_part, tail_part = os.path.splitdrive(abs_p)
                    drive_label = drive_part.replace(":", "") + "_Drive" if drive_part else "Local"
                    rel_tail = tail_part.lstrip("\\/")
                    target_dest = dest_base / drive_label / rel_tail
                else:
                    target_dest = dest_base / os.path.basename(abs_p)

                # Avoid overwriting existing file/dir with same name when flat
                if target_dest.exists():
                    stem = target_dest.stem
                    suffix = target_dest.suffix
                    timestamp_tag = datetime.now().strftime("_%Y%m%d_%H%M%S")
                    target_dest = target_dest.with_name(f"{stem}{timestamp_tag}{suffix}")

                item_size = SCAN_SESSION.dir_sizes.get(normalize_path(abs_p), 0)
                if item_size == 0 and os.path.isfile(abs_p):
                    try:
                        item_size = os.path.getsize(abs_p)
                    except OSError:
                        item_size = 0

                try:
                    target_dest.parent.mkdir(parents=True, exist_ok=True)
                    if copy_only:
                        if os.path.isdir(abs_p):
                            shutil.copytree(abs_p, str(target_dest))
                        else:
                            shutil.copy2(abs_p, str(target_dest))
                        action_label = "Googleドライブへコピー"
                    else:
                        shutil.move(abs_p, str(target_dest))
                        action_label = "Googleドライブへ移動"

                    moved_bytes += item_size
                    log_entry = append_operation_log({
                        "action": action_label,
                        "source": abs_p,
                        "destination": str(target_dest),
                        "size": item_size,
                        "status": "成功",
                        "can_undo": True
                    })
                    results.append({
                        "path": abs_p,
                        "dest": str(target_dest),
                        "ok": True,
                        "message": f"{action_label}完了: {target_dest}",
                        "size": item_size,
                        "log_id": log_entry["id"]
                    })
                except Exception as e:
                    results.append({
                        "path": abs_p,
                        "ok": False,
                        "message": f"移動・コピー中にエラーが発生しました: {e}"
                    })

            return self.send_json({
                "ok": True,
                "results": results,
                "moved_bytes": moved_bytes
            })

        if route == "/api/action/undo":
            log_id = str(body.get("log_id", "")).strip()
            if not log_id:
                return self.send_json({"error": "log_id が指定されていません"}, 400)

            logs = load_operation_logs()
            target_entry = None
            for item in logs:
                if item.get("id") == log_id:
                    target_entry = item
                    break

            if not target_entry:
                return self.send_json({"error": "指定された操作ログが見つかりません"}, 404)

            if target_entry.get("status") == "復元済み":
                return self.send_json({"error": "この操作は既に復元済みです"}, 400)

            action = target_entry.get("action", "")
            source = target_entry.get("source", "")
            dest = target_entry.get("destination", "")

            if not target_entry.get("can_undo") and not (("Googleドライブへ移動" in action) or ("Googleドライブへコピー" in action)):
                return self.send_json({"error": "この操作は取り消し（復元）に対応していません"}, 400)

            if not dest or dest == "-" or not os.path.exists(dest):
                return self.send_json({"error": f"移動先ファイルが存在しないため復元できません: {dest}"}, 400)

            try:
                if "Googleドライブへコピー" in action:
                    if source and os.path.exists(source):
                        if os.path.isdir(dest):
                            shutil.rmtree(dest)
                        else:
                            os.remove(dest)
                        msg = f"コピー先を削除して操作を取り消しました: {dest}"
                    else:
                        Path(source).parent.mkdir(parents=True, exist_ok=True)
                        shutil.move(dest, source)
                        msg = f"元の場所へファイルを復元しました: {source}"
                else:
                    if not source:
                        return self.send_json({"error": "元のパス情報が記録されていません"}, 400)
                    if os.path.exists(source):
                        return self.send_json({"error": f"元の場所に同名ファイルが既に存在するため中止しました: {source}"}, 400)
                    Path(source).parent.mkdir(parents=True, exist_ok=True)
                    shutil.move(dest, source)
                    msg = f"元の場所へファイルを復元しました: {source}"

                target_entry["status"] = "復元済み"
                target_entry["can_undo"] = False
                save_operation_logs(logs)
                return self.send_json({
                    "ok": True,
                    "message": msg,
                    "log": target_entry,
                    "logs": logs
                })
            except Exception as e:
                return self.send_json({"error": f"復元処理中にエラーが発生しました: {e}"}, 500)

        if route == "/api/tray/open":
            TRAY_CONTROLLER.open_dashboard()
            return self.send_json({"ok": True})

        if route == "/api/tray/client_connected":
            TRAY_CONTROLLER.on_client_connected()
            return self.send_json({"ok": True})

        if route == "/api/tray/window_closed":
            TRAY_CONTROLLER.on_window_closed()
            return self.send_json({"ok": True})

        if route == "/api/tray/minimize":
            TRAY_CONTROLLER.notify_minimized()
            return self.send_json({"ok": True})

        if route == "/api/tray/quit":
            threading.Timer(0.3, TRAY_CONTROLLER.quit_app).start()
            return self.send_json({"ok": True})

        return self.send_json({"error": "Not found"}, 404)


def open_dashboard_window(url: str):
    """Open the web dashboard in standalone App Mode (--app=url) if Edge/Chrome is available, else default browser."""
    browser_candidates = [
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    ]
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    for exe_path in browser_candidates:
        if os.path.exists(exe_path):
            try:
                subprocess.Popen(
                    [exe_path, f"--app={url}"],
                    creationflags=creationflags,
                )
                return
            except Exception:
                pass
    try:
        subprocess.Popen(["cmd", "/c", "start", url], shell=False, creationflags=creationflags)
    except Exception:
        pass


class TrayController:
    def __init__(self):
        self.server: ThreadingHTTPServer | None = None
        self.url: str = "http://127.0.0.1:8765"
        self.tray_icon = None
        self.last_connect_ts: float = 0.0
        self.last_notify_ts: float = 0.0
        self.lock = threading.Lock()

    def on_client_connected(self):
        with self.lock:
            self.last_connect_ts = time.time()

    def on_window_closed(self):
        """Called via sendBeacon when user clicks ✖ on the app window."""
        close_ts = time.time()

        def _check_if_truly_closed():
            with self.lock:
                # If a page reload (F5) happened, on_client_connected will have updated last_connect_ts
                if self.last_connect_ts > close_ts:
                    return
            self.notify_minimized()

        threading.Timer(0.8, _check_if_truly_closed).start()

    def notify_minimized(self):
        now = time.time()
        with self.lock:
            if now - self.last_notify_ts < 3.0:
                return
            self.last_notify_ts = now
        if self.tray_icon:
            try:
                self.tray_icon.notify(
                    "タスクトレイに格納しました。アイコンからいつでも再表示・終了できます。",
                    "DiskGuard & DriveMover",
                )
            except Exception:
                pass

    def open_dashboard(self, *_args):
        open_dashboard_window(self.url)

    def open_google_drive(self, *_args):
        cfg = load_config()
        gpath = cfg.get("google_drive_path", "")
        if gpath and os.path.exists(gpath):
            subprocess.Popen(["explorer", os.path.abspath(gpath)])

    def quit_app(self, *_args):
        if self.tray_icon:
            try:
                self.tray_icon.stop()
            except Exception:
                pass
        if self.server:
            try:
                self.server.shutdown()
                self.server.server_close()
            except Exception:
                pass
        os._exit(0)

    def _load_tray_image(self):
        from PIL import Image, ImageDraw
        candidates = [
            BUNDLE_DIR / "assets" / "logo.png",
            BUNDLE_DIR / "assets" / "app_icon.ico",
            BASE_DIR / "assets" / "logo.png",
            BASE_DIR / "assets" / "app_icon.ico",
            BASE_DIR / "app_icon.ico",
        ]
        for p in candidates:
            if p.exists():
                try:
                    return Image.open(p)
                except Exception:
                    pass
        # Fallback generated icon
        img = Image.new("RGBA", (64, 64), (15, 23, 42, 255))
        draw = ImageDraw.Draw(img)
        draw.rounded_rectangle((6, 12, 58, 54), radius=8, fill=(59, 130, 246, 255))
        draw.ellipse((32, 28, 56, 52), fill=(16, 185, 129, 255))
        return img

    def run_tray(self):
        try:
            import pystray
            image = self._load_tray_image()
            menu = pystray.Menu(
                pystray.MenuItem("📊 ダッシュボードを開く", self.open_dashboard, default=True),
                pystray.MenuItem("📂 Googleドライブを開く", self.open_google_drive),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("❌ アプリを完全に終了", self.quit_app),
            )
            self.tray_icon = pystray.Icon(
                "DiskGuard_DriveMover",
                image,
                "DiskGuard & DriveMover (稼働中)",
                menu,
            )
            self.tray_icon.run()
        except Exception:
            # If pystray fails or is unavailable, keep main thread alive while server thread runs
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                self.quit_app()


TRAY_CONTROLLER = TrayController()


def _bind_server_with_fallback(preferred_port: int = 8765) -> tuple[ThreadingHTTPServer, int]:
    """Bind ThreadingHTTPServer to preferred_port, or automatically find an available port."""
    for candidate_port in range(preferred_port, preferred_port + 50):
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", candidate_port), RequestHandler)
            return srv, candidate_port
        except OSError:
            continue
    # Fallback to OS-assigned free port
    srv = ThreadingHTTPServer(("127.0.0.1", 0), RequestHandler)
    actual_port = srv.server_address[1]
    return srv, actual_port


def _try_reuse_existing_instance(port: int) -> bool:
    """If DiskGuard is already running in the system tray on this port, open its dashboard and return True."""
    import urllib.request
    ping_url = f"http://127.0.0.1:{port}/api/tray/ping"
    open_url = f"http://127.0.0.1:{port}/api/tray/open"
    try:
        with urllib.request.urlopen(ping_url, timeout=0.8) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            if data.get("app") == "DiskGuard_DriveMover":
                req = urllib.request.Request(open_url, data=b"{}", headers={"Content-Type": "application/json"}, method="POST")
                urllib.request.urlopen(req, timeout=1.5)
                return True
    except Exception:
        pass
    return False


def run_server(port: int = 8765):
    if "--no-browser" not in sys.argv and _try_reuse_existing_instance(port):
        return

    STATIC_DIR.mkdir(parents=True, exist_ok=True)
    server, actual_port = _bind_server_with_fallback(port)
    url = f"http://127.0.0.1:{actual_port}"
    TRAY_CONTROLLER.server = server
    TRAY_CONTROLLER.url = url

    # Start HTTP server in a background daemon thread
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()

    if "--no-browser" not in sys.argv:
        threading.Timer(0.4, lambda: open_dashboard_window(url)).start()
        TRAY_CONTROLLER.run_tray()
    else:
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            server.server_close()


if __name__ == "__main__":
    if "--web" in sys.argv:
        port_num = 8765
        for arg in sys.argv[1:]:
            if arg.isdigit():
                port_num = int(arg)
        run_server(port_num)
    else:
        from desktop_gui import run_standalone_gui
        run_standalone_gui()
