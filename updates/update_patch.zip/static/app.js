// DiskGuard & DriveMover Frontend Logic

const state = {
  config: {},
  drives: [],
  gdriveCandidates: [],
  scanStatus: "idle",
  rootPath: "",
  currentDir: "",
  explorerData: null,
  explorerSort: { key: "size", dir: "desc" }, // key: "name" | "size" | "category" | "mtime", dir: "asc" | "desc"
  largeData: { large_files: [], large_dirs: [] },
  largeMode: "files", // "files" | "dirs"
  recommendationsData: { gdrive_candidates: [], delete_candidates: [] },
  duplicatesData: { duplicate_groups: [], total_wasted_size: 0, group_count: 0 },
  selectedItems: new Map(), // path -> { path, name, size, type, protection }
  pollTimer: null,
  pendingActionItems: [],
};

const CATEGORY_COLORS = {
  "動画 (Video)": "#f43f5e",
  "アーカイブ・圧縮 (Archive)": "#f59e0b",
  "ディスクイメージ・仮想環境 (Disk/VM)": "#a855f7",
  "インストーラ・実行ファイル (Installer/App)": "#ec4899",
  "画像・デザイン (Image/Design)": "#10b981",
  "音声 (Audio)": "#06b6d4",
  "ドキュメント・データ (Docs/Data)": "#3b82f6",
  "フォルダ": "#0284c7",
  "その他 (Other)": "#64748b",
};

const TREEMAP_PALETTE = [
  "#2563eb",
  "#0284c7",
  "#059669",
  "#d97706",
  "#7c3aed",
  "#db2777",
  "#0d9488",
  "#4f46e5",
  "#e11d48",
  "#475569",
];

function formatBytes(bytes) {
  if (!bytes || bytes <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.min(units.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)));
  const val = bytes / Math.pow(1024, i);
  return `${val >= 100 ? val.toFixed(0) : val.toFixed(1)} ${units[i]}`;
}

function formatDate(ts) {
  if (!ts) return "-";
  const d = new Date(ts * 1000);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}/${m}/${day}`;
}

function escapeHtml(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function showToast(msg, type = "info") {
  const container = document.getElementById("toastContainer");
  if (!container) return;
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.textContent = msg;
  container.appendChild(el);
  setTimeout(() => {
    el.remove();
  }, 4200);
}

async function apiGet(url) {
  const res = await fetch(url);
  return await res.json();
}

async function apiPost(url, data = {}) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  return await res.json();
}

// Initialization
document.addEventListener("DOMContentLoaded", async () => {
  bindEvents();
  await loadSystemInfo();
});

async function loadSystemInfo() {
  try {
    const data = await apiGet("/api/system/info");
    state.config = data.config || {};
    state.drives = data.drives || [];
    state.gdriveCandidates = data.google_drive_candidates || [];
    renderDrives(state.drives);
    renderShortcuts(data.shortcuts || []);
    renderConfigUI();

    // Pre-fill scan path with Downloads or first shortcut if empty
    const input = document.getElementById("scanPathInput");
    if (!input.value && data.shortcuts && data.shortcuts.length > 0) {
      const dl = data.shortcuts.find((s) => s.name === "ダウンロード") || data.shortcuts[0];
      input.value = dl.path;
    }
  } catch (err) {
    showToast("システム情報の取得に失敗しました", "error");
  }
}

function renderDrives(drives) {
  const grid = document.getElementById("drivesGrid");
  grid.innerHTML = "";
  drives.forEach((d) => {
    const card = document.createElement("div");
    card.className = "drive-card";
    const highClass = d.percent >= 85 ? "high" : "";
    card.innerHTML = `
      <div class="drive-card-top">
        <span>💽 ${escapeHtml(d.label)}</span>
        <span>${d.percent}% 使用</span>
      </div>
      <div class="drive-bar-bg">
        <div class="drive-bar-fill ${highClass}" style="width: ${Math.min(100, d.percent)}%"></div>
      </div>
      <div class="drive-meta">
        <span>空き: <strong>${formatBytes(d.free)}</strong></span>
        <span>合計: ${formatBytes(d.total)}</span>
      </div>
    `;
    card.addEventListener("click", () => {
      document.querySelectorAll(".drive-card").forEach((c) => c.classList.remove("selected"));
      card.classList.add("selected");
      document.getElementById("scanPathInput").value = d.path;
    });
    grid.appendChild(card);
  });
}

function renderShortcuts(shortcuts) {
  const row = document.getElementById("shortcutsRow");
  row.innerHTML = "";
  shortcuts.forEach((s) => {
    const btn = document.createElement("button");
    btn.className = "shortcut-chip";
    btn.innerHTML = `${s.icon} ${escapeHtml(s.name)}`;
    btn.addEventListener("click", () => {
      document.getElementById("scanPathInput").value = s.path;
      startScan(s.path);
    });
    row.appendChild(btn);
  });
}

function renderConfigUI() {
  const cfg = state.config;
  document.getElementById("headerGdrivePath").textContent = cfg.google_drive_path || "未設定";
  document.getElementById("chkProtectSystem").checked = cfg.protect_system_folders !== false;
  document.getElementById("chkProtectAppData").checked = cfg.protect_appdata !== false;
  document.getElementById("inputProtectedExts").value = (cfg.protected_extensions || []).join(", ");

  // Custom protected paths
  const pathList = document.getElementById("customProtectedPathsList");
  pathList.innerHTML = "";
  (cfg.custom_protected_paths || []).forEach((p) => {
    const li = document.createElement("li");
    li.innerHTML = `
      <span>🔒 ${escapeHtml(p)}</span>
      <button class="btn btn-danger-outline btn-sm" data-remove-path="${escapeHtml(p)}">解除</button>
    `;
    li.querySelector("button").addEventListener("click", async () => {
      await toggleProtection(p);
    });
    pathList.appendChild(li);
  });

  // Custom protected keywords
  const kwContainer = document.getElementById("customProtectedKeywordsList");
  kwContainer.innerHTML = "";
  (cfg.custom_protected_keywords || []).forEach((kw) => {
    const span = document.createElement("span");
    span.className = "kw-tag";
    span.innerHTML = `🏷️ ${escapeHtml(kw)} <button title="削除">✕</button>`;
    span.querySelector("button").addEventListener("click", async () => {
      const next = (state.config.custom_protected_keywords || []).filter((k) => k !== kw);
      await saveConfigPartial({ custom_protected_keywords: next });
    });
    kwContainer.appendChild(span);
  });

  const totalRules =
    (cfg.custom_protected_paths || []).length +
    (cfg.custom_protected_keywords || []).length +
    (cfg.protect_system_folders ? 1 : 0);
  const kpiProt = document.getElementById("kpiProtectionCount");
  if (kpiProt) {
    kpiProt.textContent = `${totalRules} ルール有効`;
  }
}

async function saveConfigPartial(patch) {
  const res = await apiPost("/api/config/save", patch);
  if (res.ok) {
    state.config = res.config;
    renderConfigUI();
    await refreshCurrentViews();
    showToast("保護・整理設定を保存しました", "success");
  }
}

// Scanning Logic
async function startScan(customPath) {
  const targetPath = (customPath || document.getElementById("scanPathInput").value).trim();
  if (!targetPath) {
    showToast("スキャン対象のフォルダパスを入力してください", "warn");
    return;
  }

  state.selectedItems.clear();
  updateBulkBar();

  const res = await apiPost("/api/scan/start", { path: targetPath, min_large_mb: 10 });
  if (res.error) {
    showToast(res.error, "error");
    return;
  }

  document.getElementById("scanProgressBox").classList.remove("hidden");
  document.getElementById("scanSpinner").classList.remove("hidden");
  document.getElementById("btnCancelScan").classList.remove("hidden");
  document.getElementById("scanStatusText").textContent = "高速スキャンを実行中...";

  if (state.pollTimer) clearInterval(state.pollTimer);
  state.pollTimer = setInterval(pollScanStatus, 350);
}

async function pollScanStatus() {
  const st = await apiGet("/api/scan/status");
  state.scanStatus = st.status;
  state.rootPath = st.root_path;

  document.getElementById("statDirs").textContent = (st.scanned_dirs || 0).toLocaleString();
  document.getElementById("statFiles").textContent = (st.scanned_files || 0).toLocaleString();
  document.getElementById("statTotalSize").textContent = formatBytes(st.total_size);
  document.getElementById("statElapsed").textContent = `${st.elapsed_sec}秒`;
  document.getElementById("scanCurrentPath").textContent = st.current_path || "";

  if (st.status === "completed") {
    clearInterval(state.pollTimer);
    state.pollTimer = null;
    document.getElementById("scanSpinner").classList.add("hidden");
    document.getElementById("btnCancelScan").classList.add("hidden");
    document.getElementById("scanStatusText").textContent = "✅ スキャン完了";
    document.getElementById("dashboardSection").classList.remove("hidden");

    // Populate KPIs
    document.getElementById("kpiTotalSize").textContent = formatBytes(st.total_size);
    document.getElementById("kpiRootPath").textContent = st.root_path;
    document.getElementById("kpiItemCounts").textContent = `${(st.scanned_files || 0).toLocaleString()} ファイル / ${(st.scanned_dirs || 0).toLocaleString()} フォルダ`;

    renderCategoryBreakdown(st.category_totals, st.total_size);

    state.currentDir = st.root_path;
    await refreshCurrentViews();
  } else if (st.status === "cancelled" || st.status === "error") {
    clearInterval(state.pollTimer);
    state.pollTimer = null;
    document.getElementById("scanSpinner").classList.add("hidden");
    document.getElementById("btnCancelScan").classList.add("hidden");
    document.getElementById("scanStatusText").textContent =
      st.status === "cancelled" ? "⚠️ スキャン中断" : `❌ エラー: ${st.error_msg}`;
  }
}

async function refreshCurrentViews() {
  if (!state.rootPath) return;
  await Promise.all([
    loadDirectoryView(state.currentDir || state.rootPath),
    loadLargeItemsView(),
    loadSmartAndDuplicatesView(),
  ]);
}

function renderCategoryBreakdown(catTotals, totalSize) {
  const bar = document.getElementById("categoryStackedBar");
  const legend = document.getElementById("categoryLegend");
  bar.innerHTML = "";
  legend.innerHTML = "";

  if (!catTotals || totalSize <= 0) return;

  const entries = Object.entries(catTotals)
    .map(([cat, info]) => ({ cat, size: info.size, count: info.count }))
    .filter((e) => e.size > 0)
    .sort((a, b) => b.size - a.size);

  entries.forEach((e) => {
    const pct = Math.max(0.5, (e.size / totalSize) * 100);
    const color = CATEGORY_COLORS[e.cat] || "#64748b";

    const seg = document.createElement("div");
    seg.className = "cat-segment";
    seg.style.width = `${pct}%`;
    seg.style.backgroundColor = color;
    seg.title = `${e.cat}: ${formatBytes(e.size)} (${pct.toFixed(1)}%)`;
    bar.appendChild(seg);

    const leg = document.createElement("div");
    leg.className = "legend-item";
    leg.innerHTML = `
      <span class="legend-dot" style="background:${color}"></span>
      <span>${escapeHtml(e.cat)}: <strong>${formatBytes(e.size)}</strong> (${((e.size / totalSize) * 100).toFixed(1)}%)</span>
    `;
    legend.appendChild(leg);
  });
}

// =========================================================================
// TAB 1: Explorer View, 2D Interactive Treemap & Table Sorting
// =========================================================================
async function loadDirectoryView(dirPath) {
  const data = await apiGet(`/api/scan/dir?path=${encodeURIComponent(dirPath)}`);
  if (data.error) {
    showToast(data.error, "warn");
    return;
  }
  state.currentDir = data.path;
  state.explorerData = data;
  renderBreadcrumbs(data.breadcrumbs || []);
  renderExplorerTable();
}

function renderBreadcrumbs(crumbs) {
  const bar = document.getElementById("breadcrumbsBar");
  bar.innerHTML = "";
  crumbs.forEach((c, idx) => {
    const btn = document.createElement("button");
    btn.className = "crumb-btn";
    btn.textContent = idx === 0 ? `📂 ${c.name}` : c.name;
    btn.addEventListener("click", () => loadDirectoryView(c.path));
    bar.appendChild(btn);

    if (idx < crumbs.length - 1) {
      const sep = document.createElement("span");
      sep.className = "crumb-sep";
      sep.textContent = "›";
      bar.appendChild(sep);
    }
  });

  const upBtn = document.getElementById("btnUpDir");
  if (upBtn) {
    upBtn.disabled = crumbs.length <= 1;
  }
}

/**
 * Compute 2D binary-split treemap layout rectangles in percentages [0..100]
 */
function compute2DTreemapLayout(items, x, y, w, h) {
  if (!items || items.length === 0) return [];
  if (items.length === 1) {
    return [{ item: items[0], x, y, w, h }];
  }

  const total = items.reduce((acc, it) => acc + Math.max(1, it.size), 0);
  if (total <= 0) return [];

  let accum = 0;
  let splitIdx = 0;
  for (let i = 0; i < items.length - 1; i++) {
    accum += Math.max(1, items[i].size);
    splitIdx = i + 1;
    if (accum >= total / 2) break;
  }

  const ratio = accum / total;
  const leftItems = items.slice(0, splitIdx);
  const rightItems = items.slice(splitIdx);

  // Split horizontally if wider than tall, otherwise vertically
  if (w >= h * 1.15) {
    const w1 = w * ratio;
    return [
      ...compute2DTreemapLayout(leftItems, x, y, w1, h),
      ...compute2DTreemapLayout(rightItems, x + w1, y, w - w1, h),
    ];
  } else {
    const h1 = h * ratio;
    return [
      ...compute2DTreemapLayout(leftItems, x, y, w, h1),
      ...compute2DTreemapLayout(rightItems, x, y + h1, w, h - h1),
    ];
  }
}

function render2DTreemap(items) {
  const section = document.getElementById("explorerTreemapSection");
  const gridEl = document.getElementById("explorerVisualBlocks");
  const hoverInfo = document.getElementById("treemapHoverInfo");
  gridEl.innerHTML = "";

  const nonZero = [...items].filter((i) => i.size > 0).sort((a, b) => b.size - a.size);
  if (nonZero.length === 0) {
    section.classList.add("hidden");
    return;
  }
  section.classList.remove("hidden");

  // Take top 14 items and group the rest into "その他の項目" if needed
  let displayItems = nonZero.slice(0, 14);
  if (nonZero.length > 14) {
    const rest = nonZero.slice(14);
    const restSize = rest.reduce((acc, x) => acc + x.size, 0);
    const restRatio = rest.reduce((acc, x) => acc + (x.ratio || 0), 0);
    displayItems.push({
      path: "",
      name: `その他の項目 (${rest.length}件)`,
      type: "other",
      size: restSize,
      ratio: Number(restRatio.toFixed(1)),
      category: "その他 (Other)",
      days_unused: 0,
    });
  }

  const rects = compute2DTreemapLayout(displayItems, 0, 0, 100, 100);

  rects.forEach((r, idx) => {
    const item = r.item;
    const cell = document.createElement("div");
    cell.className = `treemap-cell ${item.type === "dir" ? "is-dir" : ""}`;
    cell.style.left = `${r.x}%`;
    cell.style.top = `${r.y}%`;
    cell.style.width = `${r.w}%`;
    cell.style.height = `${r.h}%`;

    const baseColor =
      item.type === "dir"
        ? TREEMAP_PALETTE[idx % TREEMAP_PALETTE.length]
        : CATEGORY_COLORS[item.category] || TREEMAP_PALETTE[idx % TREEMAP_PALETTE.length];
    cell.style.background = `linear-gradient(135deg, ${baseColor}, rgba(15, 23, 42, 0.75))`;

    const icon = item.type === "dir" ? "📁" : item.type === "other" ? "📦" : "📄";
    const showDetails = r.w > 9 && r.h > 18;

    cell.innerHTML = `
      <div class="treemap-cell-top">
        <span>${icon} ${escapeHtml(item.name)}</span>
      </div>
      ${
        showDetails
          ? `<div class="treemap-cell-bottom">
              <span>${formatBytes(item.size)}</span>
              <span class="treemap-cell-pct">${item.ratio}%</span>
            </div>`
          : ""
      }
    `;

    cell.addEventListener("mouseenter", () => {
      const actionHint = item.type === "dir" ? " [クリックでフォルダ内へ移動]" : "";
      hoverInfo.innerHTML = `${icon} <strong>${escapeHtml(item.name)}</strong> — <strong>${formatBytes(item.size)}</strong> (フォルダ内の ${item.ratio}%)${actionHint}`;
    });

    cell.addEventListener("mouseleave", () => {
      hoverInfo.textContent = "ブロックにマウスを合わせると詳細を表示します";
    });

    if (item.type === "dir" && item.path) {
      cell.addEventListener("click", () => loadDirectoryView(item.path));
    }

    gridEl.appendChild(cell);
  });
}

function renderExplorerTable() {
  if (!state.explorerData) return;
  const searchKw = document.getElementById("explorerSearchInput").value.trim().toLowerCase();
  const hideProt = document.getElementById("hideProtectedExplorer").checked;

  let items = [...(state.explorerData.items || [])];
  if (searchKw) {
    items = items.filter((i) => i.name.toLowerCase().includes(searchKw));
  }
  if (hideProt) {
    items = items.filter((i) => !i.protection?.is_protected);
  }

  // Render 2D Treemap before sorting table rows
  render2DTreemap(items);

  // Sort items according to state.explorerSort
  const { key, dir } = state.explorerSort;
  const mult = dir === "asc" ? 1 : -1;
  items.sort((a, b) => {
    if (key === "name") {
      return a.name.localeCompare(b.name, "ja") * mult;
    }
    if (key === "category") {
      const cCmp = (a.category || "").localeCompare(b.category || "", "ja");
      return cCmp !== 0 ? cCmp * mult : (b.size - a.size);
    }
    if (key === "mtime") {
      return ((a.mtime || 0) - (b.mtime || 0)) * mult;
    }
    // default: size
    return ((a.size || 0) - (b.size || 0)) * mult;
  });

  // Update sort header indicators
  document.querySelectorAll("#tabExplorer .sortable-th").forEach((th) => {
    const sKey = th.dataset.sort;
    const ind = document.getElementById(`sortInd_${sKey}`);
    if (sKey === key) {
      th.classList.add("active-sort");
      if (ind) ind.textContent = dir === "asc" ? "▲" : "▼";
    } else {
      th.classList.remove("active-sort");
      if (ind) ind.textContent = "";
    }
  });

  const tbody = document.getElementById("explorerTableBody");
  tbody.innerHTML = "";

  if (items.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;color:#94a3b8;padding:24px;">表示できる項目がありません</td></tr>`;
    return;
  }

  items.forEach((item) => {
    tbody.appendChild(buildItemRow(item, false));
  });
}

// =========================================================================
// TAB 2: Large Files & Folders Finder
// =========================================================================
async function loadLargeItemsView() {
  const data = await apiGet("/api/scan/large");
  state.largeData = data || { large_files: [], large_dirs: [] };

  // Update KPI card for >=100MB files
  const over100M = (state.largeData.large_files || []).filter((f) => f.size >= 100 * 1024 * 1024);
  const over100MSize = over100M.reduce((acc, f) => acc + f.size, 0);
  document.getElementById("kpiLargeCount").textContent = `${over100M.length} 件`;
  document.getElementById("kpiLargeTotalSize").textContent = `合計 ${formatBytes(over100MSize)}`;

  renderLargeTable();
}

function renderLargeTable() {
  const minMB = parseInt(document.getElementById("filterMinSize").value, 10) || 10;
  const minBytes = minMB * 1024 * 1024;
  const catFilter = document.getElementById("filterCategory").value;
  const minDays = parseInt(document.getElementById("filterUnusedDays").value, 10) || 0;
  const hideProt = document.getElementById("filterHideProtectedLarge").checked;

  const rawList =
    state.largeMode === "files" ? state.largeData.large_files || [] : state.largeData.large_dirs || [];

  const filtered = rawList.filter((item) => {
    if (item.size < minBytes) return false;
    if (state.largeMode === "files" && catFilter !== "ALL" && item.category !== catFilter) return false;
    if (minDays > 0 && (item.days_unused || 0) < minDays) return false;
    if (hideProt && item.protection?.is_protected) return false;
    return true;
  });

  const totalFilteredSize = filtered.reduce((acc, x) => acc + x.size, 0);
  document.getElementById("finderSummaryBar").innerHTML = `
    🎯 条件に一致する${state.largeMode === "files" ? "巨大ファイル" : "巨大フォルダ"}: 
    <strong>${filtered.length} 件</strong> （合計サイズ: <strong>${formatBytes(totalFilteredSize)}</strong>）
    — 不要なものをチェックして一括でGoogleドライブへ移動またはゴミ箱へ削除できます。
  `;

  const tbody = document.getElementById("largeTableBody");
  tbody.innerHTML = "";

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;color:#94a3b8;padding:24px;">条件に一致する巨大項目はありません</td></tr>`;
    return;
  }

  const maxSize = filtered[0]?.size || 1;
  filtered.forEach((item) => {
    const clone = Object.assign({}, item, {
      ratio: Math.round((item.size / maxSize) * 100),
    });
    tbody.appendChild(buildItemRow(clone, true));
  });
}

// =========================================================================
// TAB 3: Smart Recommendations & Duplicate Files Detection
// =========================================================================
async function loadSmartAndDuplicatesView() {
  try {
    const [recData, dupData] = await Promise.all([
      apiGet("/api/scan/recommendations").catch(() => ({ gdrive_candidates: [], delete_candidates: [] })),
      apiGet("/api/scan/duplicates").catch(() => ({ duplicate_groups: [], total_wasted_size: 0, group_count: 0 })),
    ]);

    state.recommendationsData = {
      gdrive_candidates: recData?.gdrive_candidates || [],
      delete_candidates: recData?.delete_candidates || [],
    };
    state.duplicatesData = {
      duplicate_groups: dupData?.duplicate_groups || [],
      total_wasted_size: dupData?.total_wasted_size || 0,
      group_count: dupData?.group_count || (dupData?.duplicate_groups || []).length,
    };

    renderSmartRecommendations();
    renderDuplicatesView();
    updateSmartSummaryKPI();
  } catch (e) {
    console.error("Failed to load smart recommendations / duplicates:", e);
  }
}

function updateSmartSummaryKPI() {
  const gCandidates = (state.recommendationsData.gdrive_candidates || []).filter(
    (i) => !i.protection?.is_protected
  );
  const dCandidates = (state.recommendationsData.delete_candidates || []).filter(
    (i) => !i.protection?.is_protected
  );
  const dupGroups = state.duplicatesData.duplicate_groups || [];

  const gSize = gCandidates.reduce((acc, x) => acc + (x.size || 0), 0);
  const dSize = dCandidates.reduce((acc, x) => acc + (x.size || 0), 0);
  const wastedSize = state.duplicatesData.total_wasted_size || 0;
  const totalSavable = gSize + dSize + wastedSize;

  const totalCount = gCandidates.length + dCandidates.length + dupGroups.length;

  const kpiVal = document.getElementById("kpiSmartSavable");
  const kpiSub = document.getElementById("kpiSmartSub");
  if (kpiVal) kpiVal.textContent = formatBytes(totalSavable);
  if (kpiSub) {
    kpiSub.textContent = `移動候補 ${gCandidates.length}件 / 削除候補 ${dCandidates.length}件 / 重複 ${dupGroups.length}組`;
  }

  const tabBadge = document.getElementById("tabSmartBadge");
  if (tabBadge) {
    if (totalCount > 0) {
      tabBadge.textContent = totalCount;
      tabBadge.classList.remove("hidden");
    } else {
      tabBadge.classList.add("hidden");
    }
  }

  document.getElementById("badgeGDriveRecCount").textContent = gCandidates.length;
  document.getElementById("badgeDeleteRecCount").textContent = dCandidates.length;
  document.getElementById("badgeDupGroupCount").textContent = dupGroups.length;
}

function renderSmartRecommendations() {
  // 1. Google Drive Move Candidates
  const gList = state.recommendationsData.gdrive_candidates || [];
  const gTotal = gList.reduce((acc, x) => acc + (x.size || 0), 0);
  document.getElementById("smartGDriveCount").textContent = `${gList.length} 件`;
  document.getElementById("smartGDriveTotalSize").textContent = formatBytes(gTotal);

  const gTbody = document.getElementById("smartGDriveTableBody");
  gTbody.innerHTML = "";
  if (gList.length === 0) {
    gTbody.innerHTML = `<tr><td colspan="7" style="text-align:center;color:#94a3b8;padding:24px;">現在、Googleドライブ移動のおすすめ候補はありません</td></tr>`;
  } else {
    const maxG = gList[0]?.size || 1;
    gList.forEach((item) => {
      const clone = Object.assign({}, item, {
        type: item.type || "file",
        ratio: Math.round(((item.size || 0) / maxG) * 100),
      });
      gTbody.appendChild(buildItemRow(clone, true, { badgeType: "gdrive" }));
    });
  }

  // 2. Delete Candidates
  const dList = state.recommendationsData.delete_candidates || [];
  const dTotal = dList.reduce((acc, x) => acc + (x.size || 0), 0);
  document.getElementById("smartDeleteCount").textContent = `${dList.length} 件`;
  document.getElementById("smartDeleteTotalSize").textContent = formatBytes(dTotal);

  const dTbody = document.getElementById("smartDeleteTableBody");
  dTbody.innerHTML = "";
  if (dList.length === 0) {
    dTbody.innerHTML = `<tr><td colspan="7" style="text-align:center;color:#94a3b8;padding:24px;">現在、不要インストーラー・一時ファイルの削除候補はありません</td></tr>`;
  } else {
    const maxD = dList[0]?.size || 1;
    dList.forEach((item) => {
      const clone = Object.assign({}, item, {
        type: item.type || "file",
        ratio: Math.round(((item.size || 0) / maxD) * 100),
      });
      dTbody.appendChild(buildItemRow(clone, true, { badgeType: "warn" }));
    });
  }
}

function renderDuplicatesView() {
  const groups = state.duplicatesData.duplicate_groups || [];
  const wasted = state.duplicatesData.total_wasted_size || 0;

  document.getElementById("dupGroupCountText").textContent = `${groups.length} グループ`;
  document.getElementById("dupTotalWastedText").textContent = formatBytes(wasted);

  const container = document.getElementById("duplicatesContainer");
  container.innerHTML = "";

  if (groups.length === 0) {
    container.innerHTML = `
      <div style="text-align:center;color:#94a3b8;padding:32px;background:var(--bg-input);border-radius:10px;border:1px solid var(--border);">
        🎉 重複している大容量ファイルは検出されませんでした。
      </div>
    `;
    return;
  }

  groups.forEach((grp, idx) => {
    // Sort files by mtime descending so index 0 is the newest file
    const sortedFiles = [...(grp.files || [])].sort((a, b) => (b.mtime || 0) - (a.mtime || 0));
    const card = document.createElement("div");
    card.className = "dup-group-card";

    const shortHash = (grp.hash || "").slice(0, 12);
    card.innerHTML = `
      <div class="dup-group-header">
        <div class="dup-group-title">
          <strong>グループ #${idx + 1} （同一ファイル ${sortedFiles.length} 件 / 1件あたり ${formatBytes(grp.size)}）</strong>
          <span class="dup-wasted-badge">無駄な重複分: ${formatBytes(grp.wasted_size)}</span>
          ${shortHash ? `<span class="dup-hash-tag" title="SHA-256: ${escapeHtml(grp.hash)}">Hash: ${escapeHtml(shortHash)}...</span>` : ""}
        </div>
        <div>
          <button class="btn btn-secondary btn-sm btn-keep-newest">✨ 一番新しい1つだけ残して残りを選択</button>
        </div>
      </div>
      <div class="table-responsive">
        <table class="data-table">
          <tbody></tbody>
        </table>
      </div>
    `;

    const tbody = card.querySelector("tbody");
    sortedFiles.forEach((f, fIdx) => {
      const itemObj = {
        path: f.path,
        name: f.name,
        size: grp.size,
        mtime: f.mtime,
        days_unused: f.days_unused || 0,
        type: "file",
        category: "重複ファイル",
        protection: f.protection || { is_protected: false },
        ratio: 100,
      };
      const row = buildItemRow(itemObj, true, {
        extraTagHtml:
          fIdx === 0
            ? `<span class="dup-keep-newest-tag">★ 最新ファイル（残す推奨）</span>`
            : `<span class="reason-badge warn">重複コピー #${fIdx}</span>`,
      });
      tbody.appendChild(row);
    });

    card.querySelector(".btn-keep-newest").addEventListener("click", () => {
      selectDuplicatesKeepNewest(sortedFiles, grp.size, tbody);
      showToast(`グループ #${idx + 1}: 最新の1件を除き、重複ファイルをチェックしました`, "info");
    });

    container.appendChild(card);
  });
}

function selectDuplicatesKeepNewest(sortedFiles, fileSize, scopeEl = document) {
  if (!sortedFiles || sortedFiles.length <= 1) return;
  const newestPath = sortedFiles[0].path;
  state.selectedItems.delete(newestPath);

  for (let i = 1; i < sortedFiles.length; i++) {
    const f = sortedFiles[i];
    if (!f.protection?.is_protected) {
      state.selectedItems.set(f.path, {
        path: f.path,
        name: f.name,
        size: fileSize,
        mtime: f.mtime,
        type: "file",
        protection: f.protection || { is_protected: false },
      });
    }
  }

  // Sync checkbox states inside scopeEl
  scopeEl.querySelectorAll("tr").forEach((tr) => {
    const p = tr.dataset.itemPath;
    const chk = tr.querySelector(".row-check");
    if (p && chk && !chk.disabled) {
      chk.checked = state.selectedItems.has(p);
    }
  });
  updateBulkBar();
}

// =========================================================================
// Shared Row Builder for Explorer, Large Finder, Smart Recs, and Duplicates
// =========================================================================
function buildItemRow(item, showFullPath, options = {}) {
  const tr = document.createElement("tr");
  tr.dataset.itemPath = item.path;
  const isProt = item.protection && item.protection.is_protected;
  if (isProt) tr.classList.add("row-protected");

  const isChecked = state.selectedItems.has(item.path);
  const isGiant = item.size >= 500 * 1024 * 1024; // >= 500MB highlight

  // Protection Badge HTML
  let protBadgeHtml = `<span class="prot-badge free">✓ 整理・移動可</span>`;
  if (isProt) {
    const bClass = item.protection.protection_type === "system" ? "system" : "user";
    const icon = item.protection.protection_type === "system" ? "🛑" : "🛡️";
    protBadgeHtml = `<span class="prot-badge ${bClass}" title="${escapeHtml(item.protection.reason)}">${icon} ${escapeHtml(item.protection.reason)}</span>`;
  }

  const unusedClass = item.days_unused >= 90 ? "old" : "";
  const unusedText = item.days_unused > 0 ? `${item.days_unused}日前` : "今日";

  let reasonHtml = "";
  if (item.reason) {
    const rClass = options.badgeType === "warn" ? "warn" : "";
    reasonHtml = `<div><span class="reason-badge ${rClass}">💡 ${escapeHtml(item.reason)}</span></div>`;
  }
  const extraTagHtml = options.extraTagHtml || "";

  tr.innerHTML = `
    <td class="col-check">
      <input type="checkbox" class="row-check" ${isChecked ? "checked" : ""} ${isProt ? "disabled" : ""} />
    </td>
    <td>
      <div class="item-name-cell">
        <span>${item.type === "dir" ? "📁" : "📄"}</span>
        <div>
          <span class="${item.type === "dir" ? "item-link" : ""}">${escapeHtml(item.name)}</span>
          ${extraTagHtml}
          ${showFullPath ? `<span class="item-subpath">${escapeHtml(item.path)}</span>` : ""}
          ${reasonHtml}
        </div>
      </div>
    </td>
    <td class="col-size">
      <div class="size-cell-wrap">
        <span class="size-val">${formatBytes(item.size)}</span>
        <div class="size-bar-track">
          <div class="size-bar-fill ${isGiant ? "giant" : ""}" style="width: ${Math.min(100, Math.max(2, item.ratio || 0))}%"></div>
        </div>
      </div>
    </td>
    <td class="col-cat">
      <div>${escapeHtml(item.category || "")}</div>
      ${item.type === "dir" && item.item_count !== undefined ? `<small style="color:#94a3b8">${item.item_count} 項目</small>` : ""}
    </td>
    <td class="col-date">
      <div>${formatDate(item.mtime)}</div>
      <span class="unused-badge ${unusedClass}">${unusedText}</span>
    </td>
    <td class="col-prot">${protBadgeHtml}</td>
    <td class="col-actions">
      <div class="action-btns">
        <button class="btn btn-shield btn-sm btn-prot-toggle" ${isProt && item.protection?.can_unlock === false ? "disabled" : ""} title="削除禁止ロックの登録または個別解除">
          ${isProt ? (item.protection?.can_unlock === false ? "🔒 固定" : "🔓 解除") : "🛡️ 保護"}
        </button>
        <button class="btn btn-gdrive btn-sm btn-row-gdrive" ${isProt ? "disabled" : ""} title="Googleドライブへ移動">
          ☁️ 移動
        </button>
        <button class="btn btn-danger-outline btn-sm btn-row-del" ${isProt ? "disabled" : ""} title="ゴミ箱へ削除">
          🗑️
        </button>
        <button class="btn btn-outline btn-sm btn-row-open" title="エクスプローラーで場所を開く">
          📂
        </button>
      </div>
    </td>
  `;

  // Drill down on folder click
  if (item.type === "dir") {
    const linkEl = tr.querySelector(".item-link");
    linkEl.addEventListener("click", () => {
      switchTab("tabExplorer");
      loadDirectoryView(item.path);
    });
  }

  // Checkbox selection
  const chk = tr.querySelector(".row-check");
  chk.addEventListener("change", () => {
    if (chk.checked) {
      state.selectedItems.set(item.path, item);
    } else {
      state.selectedItems.delete(item.path);
    }
    updateBulkBar();
  });

  // Protect toggle
  tr.querySelector(".btn-prot-toggle").addEventListener("click", () => {
    toggleProtection(item.path);
  });

  // Single item Google Drive move
  tr.querySelector(".btn-row-gdrive").addEventListener("click", () => {
    openGDriveModal([item]);
  });

  // Single item Delete
  tr.querySelector(".btn-row-del").addEventListener("click", () => {
    openDeleteModal([item]);
  });

  // Open in Windows Explorer
  tr.querySelector(".btn-row-open").addEventListener("click", async () => {
    await apiPost("/api/explorer/open", { path: item.path });
  });

  return tr;
}

async function toggleProtection(targetPath) {
  const res = await apiPost("/api/protection/toggle", { path: targetPath });
  if (res.error) {
    showToast(res.error, "warn");
    return;
  }
  if (res.ok) {
    state.config = res.config;
    state.selectedItems.delete(targetPath);
    updateBulkBar();
    renderConfigUI();
    await refreshCurrentViews();
    const msg =
      res.action === "protected"
        ? `🛡️ 削除禁止にロックしました: ${targetPath}`
        : `🔓 保護ロックを個別解除しました: ${targetPath}`;
    showToast(msg, res.action === "protected" ? "warn" : "info");
  }
}

function updateBulkBar() {
  const bar = document.getElementById("bulkActionBar");
  const count = state.selectedItems.size;
  if (count === 0) {
    bar.classList.add("hidden");
    return;
  }
  bar.classList.remove("hidden");
  let totalBytes = 0;
  state.selectedItems.forEach((item) => {
    totalBytes += item.size || 0;
  });
  document.getElementById("bulkCountBadge").textContent = `${count} 件選択中`;
  document.getElementById("bulkTotalSize").textContent = formatBytes(totalBytes);
}

// =========================================================================
// Modals: Google Drive (with Multi-Drive Switcher & Space Meter) & Delete
// =========================================================================
function getDriveInfoForPath(targetPath) {
  if (!targetPath) return null;
  const norm = targetPath.trim().toUpperCase();
  // Match against gdriveCandidates first
  for (const cand of state.gdriveCandidates || []) {
    if (norm.startsWith(cand.path.toUpperCase()) || norm.slice(0, 2) === cand.path.toUpperCase().slice(0, 2)) {
      return cand;
    }
  }
  // Fallback to general drives list
  for (const drv of state.drives || []) {
    if (norm.slice(0, 2) === drv.path.toUpperCase().slice(0, 2)) {
      return drv;
    }
  }
  return null;
}

function renderGDriveModalCandidates(currentPath, movingBytes) {
  const listEl = document.getElementById("gdriveCandidatesList");
  listEl.innerHTML = "";

  // Build candidate list from google_drive_candidates, or fallback to drives
  const candidates =
    state.gdriveCandidates && state.gdriveCandidates.length > 0
      ? state.gdriveCandidates
      : state.drives.map((d) => ({
          path: d.path.endsWith("\\") ? `${d.path}マイドライブ` : `${d.path}\\マイドライブ`,
          label: d.label,
          free: d.free,
          total: d.total,
        }));

  candidates.forEach((cand) => {
    const btn = document.createElement("button");
    btn.type = "button";
    const isSelected =
      currentPath.trim().toLowerCase() === cand.path.trim().toLowerCase() ||
      currentPath.trim().toUpperCase().slice(0, 2) === cand.path.trim().toUpperCase().slice(0, 2);
    btn.className = `gdrive-candidate-btn ${isSelected ? "active" : ""}`;
    btn.innerHTML = `
      <span class="gdrive-cand-top">☁️ ${escapeHtml(cand.label || cand.path)}</span>
      <span class="gdrive-cand-sub">空き容量: <strong>${formatBytes(cand.free)}</strong> / ${formatBytes(cand.total)}</span>
    `;
    btn.addEventListener("click", () => {
      document.getElementById("modalGDriveRoot").value = cand.path;
      renderGDriveModalCandidates(cand.path, movingBytes);
    });
    listEl.appendChild(btn);
  });

  // Update space meter
  const drv = getDriveInfoForPath(currentPath);
  const freeBeforeEl = document.getElementById("gdriveFreeBefore");
  const freeAfterEl = document.getElementById("gdriveFreeAfter");
  const barFillEl = document.getElementById("gdriveSpaceBarFill");

  if (drv && drv.total > 0) {
    const afterFree = Math.max(0, drv.free - movingBytes);
    const usedAfter = drv.total - afterFree;
    const usedPct = Math.min(100, Math.max(2, (usedAfter / drv.total) * 100));

    freeBeforeEl.textContent = `${formatBytes(drv.free)} (全体 ${formatBytes(drv.total)})`;
    if (drv.free < movingBytes) {
      freeAfterEl.innerHTML = `<span class="text-danger">⚠️ 容量不足 (${formatBytes(movingBytes - drv.free)} 超過)</span>`;
      barFillEl.classList.add("danger");
    } else {
      freeAfterEl.innerHTML = `<span class="text-gdrive">${formatBytes(afterFree)}</span>`;
      barFillEl.classList.remove("danger");
    }
    barFillEl.style.width = `${usedPct}%`;
  } else {
    freeBeforeEl.textContent = "自動取得対象外";
    freeAfterEl.textContent = "-";
    barFillEl.style.width = "0%";
  }
}

function openGDriveModal(items) {
  const validItems = items.filter((i) => !i.protection?.is_protected);
  if (validItems.length === 0) {
    showToast("選択された項目はすべて保護ロックされているか、項目が選択されていません", "warn");
    return;
  }
  state.pendingActionItems = validItems;

  const initialGDrivePath = state.config.google_drive_path || "G:\\マイドライブ";
  document.getElementById("modalGDriveRoot").value = initialGDrivePath;
  document.getElementById("modalGDriveSubfolder").value =
    state.config.google_drive_subfolder || "ローカル整理アーカイブ";

  const totalSize = validItems.reduce((acc, i) => acc + (i.size || 0), 0);
  document.getElementById("modalGDriveCount").textContent = validItems.length;
  document.getElementById("modalGDriveSize").textContent = formatBytes(totalSize);

  renderGDriveModalCandidates(initialGDrivePath, totalSize);

  const ul = document.getElementById("modalGDriveList");
  ul.innerHTML = "";
  validItems.forEach((i) => {
    const li = document.createElement("li");
    li.innerHTML = `<span>${i.type === "dir" ? "📁" : "📄"} ${escapeHtml(i.path)}</span><strong>${formatBytes(i.size)}</strong>`;
    ul.appendChild(li);
  });

  document.getElementById("modalGDrive").classList.remove("hidden");
}

function openDeleteModal(items) {
  const validItems = items.filter((i) => !i.protection?.is_protected);
  if (validItems.length === 0) {
    showToast("選択された項目は保護規制により削除できないか、選択されていません", "warn");
    return;
  }
  state.pendingActionItems = validItems;

  const totalSize = validItems.reduce((acc, i) => acc + (i.size || 0), 0);
  document.getElementById("modalDeleteCount").textContent = validItems.length;
  document.getElementById("modalDeleteSize").textContent = formatBytes(totalSize);

  const ul = document.getElementById("modalDeleteList");
  ul.innerHTML = "";
  validItems.forEach((i) => {
    const li = document.createElement("li");
    li.innerHTML = `<span>${i.type === "dir" ? "📁" : "📄"} ${escapeHtml(i.path)}</span><strong>${formatBytes(i.size)}</strong>`;
    ul.appendChild(li);
  });

  document.getElementById("modalDelete").classList.remove("hidden");
}

// =========================================================================
// Operation Logs Modal & Undo Action
// =========================================================================
async function loadAndRenderLogsModal() {
  const data = await apiGet("/api/logs");
  const tbody = document.getElementById("logsTableBody");
  tbody.innerHTML = "";
  const logs = data.logs || [];

  if (logs.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:#94a3b8;padding:24px;">まだ操作履歴はありません</td></tr>`;
  } else {
    logs.forEach((l) => {
      const tr = document.createElement("tr");
      const isUndone = l.status === "復元済み";
      const canUndo = Boolean(l.can_undo) && !isUndone;

      let statusCellHtml = `<span class="log-status-badge ${isUndone ? "undone" : ""}">${escapeHtml(l.status || "完了")}</span>`;
      if (canUndo && l.id) {
        statusCellHtml += `
          <button class="btn btn-secondary btn-sm btn-undo-log" style="margin-left:8px;" data-log-id="${escapeHtml(l.id)}">
            ↩️ 元に戻す
          </button>
        `;
      }

      tr.innerHTML = `
        <td style="white-space:nowrap;">${escapeHtml(l.timestamp)}</td>
        <td><strong>${escapeHtml(l.action)}</strong></td>
        <td style="word-break:break-all;">${escapeHtml(l.source)}</td>
        <td style="word-break:break-all;">${escapeHtml(l.destination)}</td>
        <td style="white-space:nowrap;">${formatBytes(l.size)}</td>
        <td style="white-space:nowrap;">${statusCellHtml}</td>
      `;

      const undoBtn = tr.querySelector(".btn-undo-log");
      if (undoBtn) {
        undoBtn.addEventListener("click", async () => {
          undoBtn.disabled = true;
          undoBtn.textContent = "⏳ 復元中...";
          const res = await apiPost("/api/action/undo", { log_id: l.id });
          if (res.ok) {
            showToast(res.message || "↩️ ファイルを元の場所へ復元しました", "success");
            await loadAndRenderLogsModal();
            await refreshCurrentViews();
          } else {
            showToast(res.error || "復元に失敗しました", "error");
            undoBtn.disabled = false;
            undoBtn.textContent = "↩️ 元に戻す";
          }
        });
      }

      tbody.appendChild(tr);
    });
  }
  document.getElementById("modalLogs").classList.remove("hidden");
}

function switchTab(tabId) {
  document.querySelectorAll(".tab-btn").forEach((b) => {
    b.classList.toggle("active", b.dataset.tab === tabId);
  });
  document.querySelectorAll(".tab-content").forEach((c) => {
    c.classList.toggle("active", c.id === tabId);
  });
}

function switchSmartSubtab(subtabId) {
  document.querySelectorAll(".smart-subtab-btn").forEach((b) => {
    b.classList.toggle("active", b.dataset.subtab === subtabId);
  });
  document.querySelectorAll(".smart-subpanel").forEach((p) => {
    p.classList.toggle("active", p.id === subtabId);
  });
}

// =========================================================================
// Event Listeners
// =========================================================================
function bindEvents() {
  // Main Tabs
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => switchTab(btn.dataset.tab));
  });

  // Smart Subtabs
  document.querySelectorAll(".smart-subtab-btn").forEach((btn) => {
    btn.addEventListener("click", () => switchSmartSubtab(btn.dataset.subtab));
  });

  document.getElementById("btnGoProtectionTab").addEventListener("click", () => {
    document.getElementById("dashboardSection").classList.remove("hidden");
    switchTab("tabProtection");
  });

  document.getElementById("headerGdriveBadge").addEventListener("click", () => {
    const items = Array.from(state.selectedItems.values());
    if (items.length === 0) {
      document.getElementById("dashboardSection").classList.remove("hidden");
      switchTab("tabSmart");
      showToast("移動したいファイルを選択するか、「スマート整理提案」からおすすめ候補を移動できます", "info");
      return;
    }
    openGDriveModal(items);
  });

  // Parent folder Up button
  document.getElementById("btnUpDir").addEventListener("click", () => {
    const crumbs = state.explorerData?.breadcrumbs || [];
    if (crumbs.length >= 2) {
      loadDirectoryView(crumbs[crumbs.length - 2].path);
    }
  });

  // Sortable table column headers in Explorer Tab
  document.querySelectorAll("#tabExplorer .sortable-th").forEach((th) => {
    th.addEventListener("click", () => {
      const clickedKey = th.dataset.sort;
      if (state.explorerSort.key === clickedKey) {
        state.explorerSort.dir = state.explorerSort.dir === "asc" ? "desc" : "asc";
      } else {
        state.explorerSort.key = clickedKey;
        state.explorerSort.dir = clickedKey === "name" || clickedKey === "category" ? "asc" : "desc";
      }
      renderExplorerTable();
    });
  });

  // Browse folder buttons
  document.getElementById("btnBrowseScanFolder").addEventListener("click", async () => {
    const curr = document.getElementById("scanPathInput").value;
    const res = await apiPost("/api/dialog/folder", { initial_dir: curr });
    if (res.selected_path) {
      document.getElementById("scanPathInput").value = res.selected_path;
    }
  });

  document.getElementById("btnBrowseProtectFolder").addEventListener("click", async () => {
    const res = await apiPost("/api/dialog/folder", {});
    if (res.selected_path) {
      document.getElementById("inputAddProtectedPath").value = res.selected_path;
    }
  });

  document.getElementById("btnBrowseGDriveRoot").addEventListener("click", async () => {
    const curr = document.getElementById("modalGDriveRoot").value;
    const res = await apiPost("/api/dialog/folder", { initial_dir: curr });
    if (res.selected_path) {
      document.getElementById("modalGDriveRoot").value = res.selected_path;
      const totalSize = state.pendingActionItems.reduce((acc, i) => acc + (i.size || 0), 0);
      renderGDriveModalCandidates(res.selected_path, totalSize);
    }
  });

  document.getElementById("modalGDriveRoot").addEventListener("input", (e) => {
    const totalSize = state.pendingActionItems.reduce((acc, i) => acc + (i.size || 0), 0);
    renderGDriveModalCandidates(e.target.value, totalSize);
  });

  // Start / Cancel Scan
  document.getElementById("btnStartScan").addEventListener("click", () => startScan());
  document.getElementById("scanPathInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter") startScan();
  });
  document.getElementById("btnCancelScan").addEventListener("click", async () => {
    await apiPost("/api/scan/cancel");
  });

  // Explorer filters
  document.getElementById("explorerSearchInput").addEventListener("input", renderExplorerTable);
  document.getElementById("hideProtectedExplorer").addEventListener("change", renderExplorerTable);

  document.getElementById("checkAllExplorer").addEventListener("change", (e) => {
    const checked = e.target.checked;
    document.querySelectorAll("#explorerTableBody .row-check:not(:disabled)").forEach((chk) => {
      chk.checked = checked;
      chk.dispatchEvent(new Event("change"));
    });
  });

  // Large Finder Controls
  document.getElementById("btnModeLargeFiles").addEventListener("click", () => {
    state.largeMode = "files";
    document.getElementById("btnModeLargeFiles").classList.add("active");
    document.getElementById("btnModeLargeDirs").classList.remove("active");
    document.getElementById("filterCategory").disabled = false;
    renderLargeTable();
  });

  document.getElementById("btnModeLargeDirs").addEventListener("click", () => {
    state.largeMode = "dirs";
    document.getElementById("btnModeLargeDirs").classList.add("active");
    document.getElementById("btnModeLargeFiles").classList.remove("active");
    document.getElementById("filterCategory").disabled = true;
    renderLargeTable();
  });

  ["filterMinSize", "filterCategory", "filterUnusedDays", "filterHideProtectedLarge"].forEach((id) => {
    document.getElementById(id).addEventListener("change", renderLargeTable);
  });

  document.getElementById("checkAllLarge").addEventListener("change", (e) => {
    const checked = e.target.checked;
    document.querySelectorAll("#largeTableBody .row-check:not(:disabled)").forEach((chk) => {
      chk.checked = checked;
      chk.dispatchEvent(new Event("change"));
    });
  });

  // Smart Tab Actions
  document.getElementById("btnRefreshSmart").addEventListener("click", async () => {
    await loadSmartAndDuplicatesView();
    showToast("スマート整理提案と重複ファイル検出を更新しました", "info");
  });

  document.getElementById("checkAllGDriveRec").addEventListener("change", (e) => {
    const checked = e.target.checked;
    document.querySelectorAll("#smartGDriveTableBody .row-check:not(:disabled)").forEach((chk) => {
      chk.checked = checked;
      chk.dispatchEvent(new Event("change"));
    });
  });

  document.getElementById("btnSelectAllGDriveRec").addEventListener("click", () => {
    document.querySelectorAll("#smartGDriveTableBody .row-check:not(:disabled)").forEach((chk) => {
      chk.checked = true;
      chk.dispatchEvent(new Event("change"));
    });
  });

  document.getElementById("btnOneClickMoveGDriveRec").addEventListener("click", () => {
    const candidates = (state.recommendationsData.gdrive_candidates || []).filter(
      (i) => !i.protection?.is_protected
    );
    openGDriveModal(candidates);
  });

  document.getElementById("checkAllDeleteRec").addEventListener("change", (e) => {
    const checked = e.target.checked;
    document.querySelectorAll("#smartDeleteTableBody .row-check:not(:disabled)").forEach((chk) => {
      chk.checked = checked;
      chk.dispatchEvent(new Event("change"));
    });
  });

  document.getElementById("btnSelectAllDeleteRec").addEventListener("click", () => {
    document.querySelectorAll("#smartDeleteTableBody .row-check:not(:disabled)").forEach((chk) => {
      chk.checked = true;
      chk.dispatchEvent(new Event("change"));
    });
  });

  document.getElementById("btnOneClickTrashDeleteRec").addEventListener("click", () => {
    const candidates = (state.recommendationsData.delete_candidates || []).filter(
      (i) => !i.protection?.is_protected
    );
    openDeleteModal(candidates);
  });

  document.getElementById("btnSelectAllDupOldest").addEventListener("click", () => {
    const groups = state.duplicatesData.duplicate_groups || [];
    if (groups.length === 0) {
      showToast("重複ファイルグループがありません", "info");
      return;
    }
    groups.forEach((grp) => {
      const sorted = [...(grp.files || [])].sort((a, b) => (b.mtime || 0) - (a.mtime || 0));
      selectDuplicatesKeepNewest(sorted, grp.size, document.getElementById("duplicatesContainer"));
    });
    showToast(`全 ${groups.length} グループの最新ファイル1つを残し、重複コピーを一括選択しました`, "success");
  });

  document.getElementById("btnDeleteSelectedDups").addEventListener("click", () => {
    const selected = Array.from(state.selectedItems.values());
    if (selected.length === 0) {
      showToast("削除する重複ファイルを選択してください", "warn");
      return;
    }
    openDeleteModal(selected);
  });

  // One-Click Protection Presets
  document.querySelectorAll(".preset-card-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const preset = btn.dataset.preset;
      const res = await apiPost("/api/protection/preset", { preset });
      if (res.ok) {
        state.config = res.config;
        renderConfigUI();
        await refreshCurrentViews();
        const labelMap = {
          dev: "💻 開発・ソースコード保護プリセット",
          office: "🏢 重要業務書類保護プリセット",
          photo: "📷 写真・原本データ保護プリセット",
        };
        showToast(`${labelMap[preset] || "保護プリセット"} を登録しました`, "success");
      } else {
        showToast(res.error || "プリセットの追加に失敗しました", "error");
      }
    });
  });

  // Protection Settings Tab
  document.getElementById("btnSaveSystemProt").addEventListener("click", async () => {
    const exts = document
      .getElementById("inputProtectedExts")
      .value.split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    await saveConfigPartial({
      protect_system_folders: document.getElementById("chkProtectSystem").checked,
      protect_appdata: document.getElementById("chkProtectAppData").checked,
      protected_extensions: exts,
    });
  });

  document.getElementById("chkProtectSystem").addEventListener("change", () => {
    document.getElementById("btnSaveSystemProt").click();
  });
  document.getElementById("chkProtectAppData").addEventListener("change", () => {
    document.getElementById("btnSaveSystemProt").click();
  });

  document.getElementById("btnAddProtectedPath").addEventListener("click", async () => {
    const val = document.getElementById("inputAddProtectedPath").value.trim();
    if (!val) return;
    await toggleProtection(val);
    document.getElementById("inputAddProtectedPath").value = "";
  });

  document.getElementById("btnAddProtectedKeyword").addEventListener("click", async () => {
    const kw = document.getElementById("inputAddProtectedKeyword").value.trim();
    if (!kw) return;
    const list = Array.from(new Set([...(state.config.custom_protected_keywords || []), kw]));
    await saveConfigPartial({ custom_protected_keywords: list });
    document.getElementById("inputAddProtectedKeyword").value = "";
  });

  // Bulk Action Bar
  document.getElementById("btnBulkClear").addEventListener("click", () => {
    state.selectedItems.clear();
    document.querySelectorAll(".row-check").forEach((c) => (c.checked = false));
    updateBulkBar();
  });

  document.getElementById("btnBulkProtect").addEventListener("click", async () => {
    const paths = Array.from(state.selectedItems.keys());
    const merged = Array.from(new Set([...(state.config.custom_protected_paths || []), ...paths]));
    await saveConfigPartial({ custom_protected_paths: merged });
    state.selectedItems.clear();
    updateBulkBar();
  });

  document.getElementById("btnBulkMoveGDrive").addEventListener("click", () => {
    openGDriveModal(Array.from(state.selectedItems.values()));
  });

  document.getElementById("btnBulkDelete").addEventListener("click", () => {
    openDeleteModal(Array.from(state.selectedItems.values()));
  });

  // Google Drive Modal Execution
  const closeGDrive = () => document.getElementById("modalGDrive").classList.add("hidden");
  document.getElementById("btnCloseGDriveModal").addEventListener("click", closeGDrive);
  document.getElementById("btnCancelGDriveModal").addEventListener("click", closeGDrive);

  document.getElementById("btnExecuteGDrive").addEventListener("click", async () => {
    const gdrivePath = document.getElementById("modalGDriveRoot").value.trim();
    const subfolder = document.getElementById("modalGDriveSubfolder").value.trim();
    const preserve = document.getElementById("modalGDrivePreserve").checked;
    const copyOnly = document.getElementById("modalGDriveCopyOnly").checked;
    const paths = state.pendingActionItems.map((i) => i.path);

    const btn = document.getElementById("btnExecuteGDrive");
    btn.disabled = true;
    btn.textContent = "⏳ 移動処理中...";

    await saveConfigPartial({
      google_drive_path: gdrivePath,
      google_drive_subfolder: subfolder,
    });

    const res = await apiPost("/api/action/gdrive", {
      paths,
      gdrive_path: gdrivePath,
      subfolder,
      preserve_structure: preserve,
      copy_only: copyOnly,
    });

    btn.disabled = false;
    btn.textContent = "☁️ Googleドライブへ実行する";
    closeGDrive();

    if (res.error) {
      showToast(res.error, "error");
      return;
    }

    const okCount = (res.results || []).filter((r) => r.ok).length;
    const failCount = (res.results || []).length - okCount;
    state.selectedItems.clear();
    updateBulkBar();
    await loadSystemInfo();
    await refreshCurrentViews();

    if (okCount > 0) {
      showToast(
        `☁️ ${okCount}件 (${formatBytes(res.moved_bytes)}) をGoogleドライブへ${copyOnly ? "コピー" : "移動"}しました`,
        "success"
      );
    }
    if (failCount > 0) {
      const firstErr = res.results.find((r) => !r.ok)?.message || "";
      showToast(`⚠️ ${failCount}件がスキップまたは失敗しました: ${firstErr}`, "warn");
    }
  });

  // Delete Modal Execution
  const closeDel = () => document.getElementById("modalDelete").classList.add("hidden");
  document.getElementById("btnCloseDeleteModal").addEventListener("click", closeDel);
  document.getElementById("btnCancelDeleteModal").addEventListener("click", closeDel);

  document.querySelectorAll('input[name="deleteMode"]').forEach((r) => {
    r.addEventListener("change", () => {
      document.getElementById("radioCardRecycle").classList.toggle("active", r.value === "recycle" && r.checked);
      document.getElementById("radioCardPermanent").classList.toggle("active", r.value === "permanent" && r.checked);
    });
  });

  document.getElementById("btnExecuteDelete").addEventListener("click", async () => {
    const mode = document.querySelector('input[name="deleteMode"]:checked').value;
    const paths = state.pendingActionItems.map((i) => i.path);

    const btn = document.getElementById("btnExecuteDelete");
    btn.disabled = true;
    btn.textContent = "⏳ 削除処理中...";

    const res = await apiPost("/api/action/delete", { paths, mode });

    btn.disabled = false;
    btn.textContent = "🗑️ 削除を実行する";
    closeDel();

    const okCount = (res.results || []).filter((r) => r.ok).length;
    const failCount = (res.results || []).length - okCount;
    state.selectedItems.clear();
    updateBulkBar();
    await loadSystemInfo();
    await refreshCurrentViews();

    if (okCount > 0) {
      showToast(`🗑️ ${okCount}件 (${formatBytes(res.freed_bytes)}) を削除しました`, "success");
    }
    if (failCount > 0) {
      const firstErr = res.results.find((r) => !r.ok)?.message || "";
      showToast(`⚠️ ${failCount}件がブロックまたは失敗しました: ${firstErr}`, "warn");
    }
  });

  // Operation Logs Modal
  const closeLogs = () => document.getElementById("modalLogs").classList.add("hidden");
  document.getElementById("btnCloseLogsModal").addEventListener("click", closeLogs);
  document.getElementById("btnOpenLogs").addEventListener("click", loadAndRenderLogsModal);

  // Task Tray & App Lifecycle Controls
  apiPost("/api/tray/client_connected").catch(() => {});

  window.addEventListener("pagehide", () => {
    try {
      navigator.sendBeacon("/api/tray/window_closed", JSON.stringify({ ts: Date.now() }));
    } catch (e) {}
  });

  const btnMinTray = document.getElementById("btnMinimizeToTray");
  if (btnMinTray) {
    btnMinTray.addEventListener("click", async () => {
      await apiPost("/api/tray/minimize");
      window.close();
      setTimeout(() => {
        showToast("📥 タスクトレイに常駐しています。ウィンドウ右上の「✖」で閉じてもタスクトレイから再表示できます。", "info");
      }, 200);
    });
  }

  const btnQuit = document.getElementById("btnQuitApp");
  if (btnQuit) {
    btnQuit.addEventListener("click", async () => {
      if (!confirm("DiskGuard & DriveMover を完全に終了しますか？\n（タスクトレイへ格納する場合は右上の「✖」または「📥 トレイへ格納」を使用してください）")) {
        return;
      }
      await apiPost("/api/tray/quit");
      document.body.innerHTML = `
        <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;background:#0f172a;color:#f8fafc;font-family:sans-serif;">
          <h2>✅ DiskGuard &amp; DriveMover を終了しました</h2>
          <p style="color:#94a3b8;margin-top:8px;">このウィンドウを閉じてください。</p>
        </div>
      `;
      window.close();
    });
  }
}
