"""
DiskGuard & DriveMover - Windows スタンドアロン ネイティブGUIアプリケーション (PySide6 / Qt6)
1366x768 ディスプレイに最適化した高密度・高視認性レイアウト。
ブラウザ不要で単体動作し、✖ボタンで閉じた際はWindowsタスクトレイ（通知領域）へ格納されます。
"""

import os
import sys
import time
import json
import shutil
import threading
import subprocess
import importlib.util
from pathlib import Path
from datetime import datetime

from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtCore import Qt, QTimer, QRectF, Signal
from PySide6.QtGui import QIcon, QColor, QPainter, QFont, QPen, QAction
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from PySide6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QLineEdit,
    QComboBox,
    QCheckBox,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QAbstractItemView,
    QFileDialog,
    QMessageBox,
    QDialog,
    QListWidget,
    QFrame,
    QSystemTrayIcon,
    QMenu,
    QRadioButton,
    QSplitter,
    QToolTip,
)

import app as backend

SINGLE_INSTANCE_KEY = "DiskGuard_DriveMover_Standalone_v2"

DEFAULT_ITEM_COL_WIDTHS = [42, 490, 105, 170, 125, 175, 208]
DEFAULT_LOGS_COL_WIDTHS = [135, 145, 220, 220, 85, 105]
DEFAULT_SPLITTER_SIZES = [76, 440]

CATEGORY_COLORS = {
    "動画 (Video)": "#f43f5e",
    "アーカイブ・圧縮 (Archive)": "#f59e0b",
    "ディスクイメージ・仮想環境 (Disk/VM)": "#a855f7",
    "インストーラ・実行ファイル (Installer/App)": "#ec4899",
    "画像・デザイン (Image/Design)": "#10b981",
    "音声 (Audio)": "#06b6d4",
    "ドキュメント・データ (Docs/Data)": "#3b82f6",
    "フォルダ": "#0ea5e9",
    "その他 (Other)": "#64748b",
}

DARK_STYLESHEET = """
QMainWindow, QDialog {
    background-color: #0f172a;
    color: #f1f5f9;
    font-family: "Yu Gothic UI", "Meiryo", "Segoe UI", sans-serif;
}
QWidget {
    color: #f1f5f9;
    font-family: "Yu Gothic UI", "Meiryo", "Segoe UI", sans-serif;
    font-size: 12px;
}
QFrame#Card {
    background-color: #1e293b;
    border: 1px solid #334155;
    border-radius: 6px;
}
QFrame#HeaderBar {
    background-color: #111827;
    border-bottom: 1px solid #334155;
}
QFrame#BulkBar {
    background-color: #111827;
    border: 2px solid #3b82f6;
    border-radius: 8px;
}
QFrame#SubCard {
    background-color: #0b1120;
    border: 1px solid #334155;
    border-radius: 6px;
}
QLineEdit, QComboBox {
    background-color: #0b1120;
    border: 1px solid #334155;
    border-radius: 5px;
    padding: 3px 8px;
    min-height: 20px;
    color: #f8fafc;
}
QLineEdit:focus, QComboBox:focus {
    border: 1px solid #3b82f6;
}
QComboBox::drop-down {
    border: none;
    width: 20px;
}
QComboBox QAbstractItemView {
    background-color: #1e293b;
    border: 1px solid #334155;
    selection-background-color: #3b82f6;
    color: #f8fafc;
}
QPushButton {
    background-color: #334155;
    border: 1px solid #475569;
    border-radius: 5px;
    padding: 3px 10px;
    min-height: 20px;
    color: #f8fafc;
    font-weight: bold;
}
QPushButton:hover {
    background-color: #475569;
}
QPushButton:disabled {
    background-color: #1e293b;
    color: #64748b;
    border-color: #334155;
}
QPushButton#PrimaryBtn {
    background-color: #2563eb;
    border-color: #3b82f6;
    color: #ffffff;
}
QPushButton#PrimaryBtn:hover {
    background-color: #1d4ed8;
}
QPushButton#GDriveBtn {
    background-color: #059669;
    border-color: #10b981;
    color: #ffffff;
}
QPushButton#GDriveBtn:hover {
    background-color: #047857;
}
QPushButton#ShieldBtn {
    background-color: #78350f;
    border: 1px solid #f59e0b;
    color: #fde68a;
}
QPushButton#ShieldBtn:hover {
    background-color: #92400e;
}
QPushButton#DangerBtn {
    background-color: #dc2626;
    border-color: #ef4444;
    color: #ffffff;
}
QPushButton#DangerBtn:hover {
    background-color: #b91c1c;
}
QPushButton#ChipBtn {
    background-color: #0b1120;
    border: 1px solid #334155;
    border-radius: 11px;
    padding: 2px 9px;
    min-height: 18px;
    font-size: 11px;
    font-weight: normal;
}
QPushButton#ChipBtn:hover {
    border-color: #3b82f6;
    background-color: #1e293b;
}
QPushButton#DriveBtn {
    background-color: #0f172a;
    border: 1px solid #334155;
    border-radius: 5px;
    padding: 2px 8px;
    min-height: 18px;
    font-size: 11px;
}
QPushButton#DriveBtn:hover {
    border-color: #3b82f6;
    background-color: #1e293b;
}
QTabWidget::pane {
    border: 1px solid #334155;
    background-color: #1e293b;
    border-radius: 6px;
}
QTabBar::tab {
    background-color: #0b1120;
    border: 1px solid #334155;
    border-bottom: none;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
    padding: 5px 14px;
    margin-right: 3px;
    color: #94a3b8;
    font-weight: bold;
    font-size: 12px;
}
QTabBar::tab:selected {
    background-color: #2563eb;
    border-color: #3b82f6;
    color: #ffffff;
}
QTabBar::tab:hover:!selected {
    background-color: #1e293b;
    color: #f8fafc;
}
QTableWidget {
    background-color: #0b1120;
    alternate-background-color: #111827;
    gridline-color: #1e293b;
    border: 1px solid #334155;
    border-radius: 5px;
    selection-background-color: rgba(59, 130, 246, 0.25);
    selection-color: #f8fafc;
    font-size: 12px;
}
QHeaderView::section {
    background-color: #111827;
    color: #94a3b8;
    font-weight: bold;
    font-size: 11px;
    padding: 4px 6px;
    border: none;
    border-bottom: 1px solid #334155;
    border-right: 1px solid #334155;
}
QHeaderView::section:hover {
    background-color: #1e293b;
    color: #f8fafc;
}
QScrollBar:vertical {
    background: #0b1120;
    width: 10px;
    margin: 0px;
}
QScrollBar::handle:vertical {
    background: #334155;
    min-height: 24px;
    border-radius: 5px;
}
QScrollBar::handle:vertical:hover {
    background: #475569;
}
QScrollBar:horizontal {
    background: #0b1120;
    height: 10px;
    margin: 0px;
}
QScrollBar::handle:horizontal {
    background: #334155;
    min-width: 24px;
    border-radius: 5px;
}
QListWidget {
    background-color: #0b1120;
    border: 1px solid #334155;
    border-radius: 5px;
    padding: 3px;
}
QCheckBox {
    spacing: 5px;
}
QSplitter::handle {
    background-color: #334155;
    height: 3px;
}
"""


def format_bytes(num_bytes: int | float) -> str:
    if not num_bytes or num_bytes <= 0:
        return "0 B"
    units = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    val = float(num_bytes)
    while val >= 1024 and i < len(units) - 1:
        val /= 1024.0
        i += 1
    return f"{val:.0f} {units[i]}" if val >= 100 else f"{val:.1f} {units[i]}"


def format_date(ts: float) -> str:
    if not ts:
        return "-"
    try:
        return datetime.fromtimestamp(ts).strftime("%Y/%m/%d")
    except Exception:
        return "-"


def resolve_app_icon() -> QIcon:
    candidates = [
        backend.BUNDLE_DIR / "assets" / "app_icon.ico",
        backend.BASE_DIR / "assets" / "app_icon.ico",
        backend.BASE_DIR / "app_icon.ico",
        backend.BUNDLE_DIR / "assets" / "logo.png",
        backend.BASE_DIR / "assets" / "logo.png",
    ]
    for p in candidates:
        if p.exists():
            return QIcon(str(p))
    return QIcon()


class NumericTableWidgetItem(QTableWidgetItem):
    """Table item that sorts numerically by UserRole value instead of string."""

    def __lt__(self, other: QTableWidgetItem) -> bool:
        v1 = self.data(Qt.UserRole)
        v2 = other.data(Qt.UserRole)
        if v1 is not None and v2 is not None:
            try:
                return float(v1) < float(v2)
            except Exception:
                pass
        return super().__lt__(other)


class CategoryBarWidget(QWidget):
    """Compact custom painted stacked category breakdown bar with hover tooltip."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(14)
        self.setMinimumWidth(140)
        self.setMouseTracking(True)
        self.segments = []  # list of (cat_name, size, pct, color_hex)

    def set_data(self, cat_totals: dict, total_size: int):
        self.segments = []
        if cat_totals and total_size > 0:
            entries = [
                (cat, info.get("size", 0))
                for cat, info in cat_totals.items()
                if info.get("size", 0) > 0
            ]
            entries.sort(key=lambda x: x[1], reverse=True)
            for cat, sz in entries:
                pct = sz / total_size
                color = CATEGORY_COLORS.get(cat, "#64748b")
                self.segments.append((cat, sz, pct, color))

        if self.segments:
            lines = [f"📊 カテゴリ別容量内訳:"]
            for cat, sz, pct, _ in self.segments:
                lines.append(f"  • {cat}: {format_bytes(sz)} ({pct * 100:.1f}%)")
            self.setToolTip("\n".join(lines))
        else:
            self.setToolTip("スキャンを実行するとカテゴリ別の容量内訳が表示されます")
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        rect = self.rect()
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor("#0b1120"))
        painter.drawRoundedRect(rect, 4, 4)

        if not self.segments:
            return

        x = 0.0
        w = float(rect.width())
        h = float(rect.height())
        for _cat, _sz, pct, color in self.segments:
            seg_w = max(2.5, w * pct)
            if x + seg_w > w:
                seg_w = max(0.0, w - x)
            painter.setBrush(QColor(color))
            painter.drawRect(QRectF(x, 0, seg_w, h))
            x += seg_w
            if x >= w:
                break


class TreemapWidget(QWidget):
    """Compact interactive 2D Treemap visualization widget optimized for 1366x768."""

    folderClicked = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(64)
        self.setMaximumHeight(180)
        self.setMouseTracking(True)
        self.items = []
        self.rects = []  # list of (QRectF, item_dict, color_hex)

    def set_items(self, items: list):
        valid = [i for i in items if i.get("size", 0) > 0][:14]
        self.items = valid
        self._recompute_layout()
        self.update()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._recompute_layout()

    def _recompute_layout(self):
        self.rects = []
        if not self.items:
            return
        w = float(self.width())
        h = float(self.height())
        if w <= 10 or h <= 10:
            return

        palette = [
            "#2563eb", "#0284c7", "#059669", "#d97706",
            "#7c3aed", "#db2777", "#0d9488", "#4f46e5",
            "#e11d48", "#475569",
        ]

        def split_layout(entries, x, y, bw, bh):
            if not entries or bw <= 2 or bh <= 2:
                return
            if len(entries) == 1:
                idx, item = entries[0]
                color = "#b45309" if item.get("protection", {}).get("is_protected") else palette[idx % len(palette)]
                self.rects.append((QRectF(x + 1, y + 1, max(2.0, bw - 2), max(2.0, bh - 2)), item, color))
                return

            total = sum(e[1]["size"] for e in entries)
            if total <= 0:
                return

            half = total / 2.0
            acc = 0
            split_idx = 1
            for i, (_, it) in enumerate(entries):
                acc += it["size"]
                if acc >= half:
                    split_idx = i + 1
                    break
            if split_idx >= len(entries):
                split_idx = len(entries) - 1

            left = entries[:split_idx]
            right = entries[split_idx:]
            left_sum = sum(e[1]["size"] for e in left)
            ratio = left_sum / total if total > 0 else 0.5

            if bw >= bh:
                lw = bw * ratio
                split_layout(left, x, y, lw, bh)
                split_layout(right, x + lw, y, bw - lw, bh)
            else:
                lh = bh * ratio
                split_layout(left, x, y, bw, lh)
                split_layout(right, x, y + lh, bw, bh - lh)

        indexed = list(enumerate(self.items))
        split_layout(indexed, 0.0, 0.0, w, h)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor("#0b1120"))
        painter.drawRoundedRect(self.rect(), 5, 5)

        if not self.rects:
            painter.setPen(QColor("#64748b"))
            painter.drawText(self.rect(), Qt.AlignCenter, "スキャンするとフォルダ・ファイルの面積マップが表示されます（クリックで階層移動）")
            return

        font_bold = QFont("Yu Gothic UI", 8, QFont.Bold)
        font_sub = QFont("Yu Gothic UI", 8)

        for r, item, color in self.rects:
            painter.setPen(QPen(QColor("#0f172a"), 1))
            painter.setBrush(QColor(color))
            painter.drawRoundedRect(r, 3, 3)

            if r.width() > 48 and r.height() > 20:
                painter.setPen(QColor("#ffffff"))
                painter.setFont(font_bold)
                icon = "📁" if item.get("type") == "dir" else "📄"
                text_rect = r.adjusted(4, 2, -4, -2)
                label_str = f"{icon} {item.get('name', '')}"
                if r.height() <= 34 and r.width() > 110:
                    label_str += f" ({format_bytes(item.get('size', 0))})"
                elided = painter.fontMetrics().elidedText(
                    label_str, Qt.ElideRight, int(text_rect.width())
                )
                painter.drawText(text_rect, Qt.AlignLeft | Qt.AlignTop, elided)

                if r.height() > 34:
                    painter.setFont(font_sub)
                    painter.setPen(QColor("#e2e8f0"))
                    sz_str = f"{format_bytes(item.get('size', 0))} ({item.get('ratio', 0)}%)"
                    painter.drawText(text_rect.adjusted(0, 15, 0, 0), Qt.AlignLeft | Qt.AlignTop, sz_str)

    def mouseMoveEvent(self, event):
        pos = event.position()
        for r, item, _ in self.rects:
            if r.contains(pos):
                self.setCursor(Qt.PointingHandCursor if item.get("type") == "dir" else Qt.ArrowCursor)
                tip = (
                    f"{'📁 フォルダ' if item.get('type') == 'dir' else '📄 ファイル'}: {item.get('name')}\n"
                    f"サイズ: {format_bytes(item.get('size', 0))} (占有率 {item.get('ratio', 0)}%)\n"
                    f"{'クリックでこのフォルダ内へ移動' if item.get('type') == 'dir' else ''}"
                ).strip()
                QToolTip.showText(event.globalPosition().toPoint(), tip, self)
                return
        self.setCursor(Qt.ArrowCursor)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            pos = event.position()
            for r, item, _ in self.rects:
                if r.contains(pos) and item.get("type") == "dir":
                    self.folderClicked.emit(item["path"])
                    return


class GDriveMoveDialog(QDialog):
    """Native dialog for moving or copying selected items to Google Drive (sized for 1366x768)."""

    def __init__(self, parent, items: list, config: dict, gdrive_candidates: list):
        super().__init__(parent)
        self.setWindowTitle("☁️ Googleドライブへ移動・整理")
        self.resize(620, 460)
        self.items = items
        self.config = config
        self.candidates = gdrive_candidates
        self.total_size = sum(i.get("size", 0) for i in items)
        self._build_ui()
        self._update_space_meter()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(8)
        layout.setContentsMargins(16, 14, 16, 14)

        lead = QLabel(
            "ローカルPCの空き容量を増やすため、選択したファイル・フォルダをGoogleドライブへ移動またはコピーします。"
        )
        lead.setWordWrap(True)
        lead.setStyleSheet("color: #94a3b8;")
        layout.addWidget(lead)

        if self.candidates:
            cand_row = QHBoxLayout()
            cand_row.addWidget(QLabel("📌 検出ドライブ:"))
            for c in self.candidates[:4]:
                btn = QPushButton(f"☁️ {c['label']} (空 {format_bytes(c.get('free', 0))})")
                btn.setObjectName("ChipBtn")
                btn.clicked.connect(lambda _=False, p=c["path"]: self._select_candidate(p))
                cand_row.addWidget(btn)
            cand_row.addStretch()
            layout.addLayout(cand_row)

        path_grid = QVBoxLayout()
        path_grid.setSpacing(6)
        r1 = QHBoxLayout()
        r1.addWidget(QLabel("📂 移動先ベース:"))
        self.root_edit = QLineEdit(self.config.get("google_drive_path", r"G:\マイドライブ"))
        self.root_edit.textChanged.connect(self._update_space_meter)
        browse_btn = QPushButton("参照...")
        browse_btn.clicked.connect(self._browse_root)
        r1.addWidget(self.root_edit, 1)
        r1.addWidget(browse_btn)
        path_grid.addLayout(r1)

        r2 = QHBoxLayout()
        r2.addWidget(QLabel("📁 サブフォルダ:"))
        self.sub_edit = QLineEdit(self.config.get("google_drive_subfolder", "ローカル整理アーカイブ"))
        r2.addWidget(self.sub_edit, 1)
        path_grid.addLayout(r2)
        layout.addLayout(path_grid)

        self.space_frame = QFrame()
        self.space_frame.setObjectName("SubCard")
        sf_layout = QVBoxLayout(self.space_frame)
        sf_layout.setContentsMargins(10, 6, 10, 6)
        self.space_label = QLabel("移動先ドライブの空き容量を確認中...")
        sf_layout.addWidget(self.space_label)
        layout.addWidget(self.space_frame)

        opts_frame = QFrame()
        opts_frame.setObjectName("SubCard")
        opts_layout = QVBoxLayout(opts_frame)
        opts_layout.setContentsMargins(10, 6, 10, 6)
        opts_layout.setSpacing(4)
        self.chk_preserve = QCheckBox("元のフォルダ階層構造を維持して保存する（推奨：元の場所が後から分かります）")
        self.chk_preserve.setChecked(True)
        self.chk_copy = QCheckBox("ローカルから消さずに「コピー」にする（※外すと「移動」になりローカル容量が空きます）")
        self.chk_copy.setChecked(False)
        opts_layout.addWidget(self.chk_preserve)
        opts_layout.addWidget(self.chk_copy)
        layout.addWidget(opts_frame)

        layout.addWidget(QLabel(f"📋 対象アイテム ({len(self.items)} 件 / 合計 {format_bytes(self.total_size)}):"))
        list_w = QListWidget()
        for it in self.items:
            icon = "📁" if it.get("type") == "dir" else "📄"
            list_w.addItem(f"{icon} {it['path']}  ({format_bytes(it.get('size', 0))})")
        layout.addWidget(list_w, 1)

        footer = QHBoxLayout()
        footer.addStretch()
        cancel_btn = QPushButton("キャンセル")
        cancel_btn.clicked.connect(self.reject)
        self.exec_btn = QPushButton("☁️ Googleドライブへ実行する")
        self.exec_btn.setObjectName("GDriveBtn")
        self.exec_btn.setMinimumHeight(32)
        self.exec_btn.clicked.connect(self.accept)
        footer.addWidget(cancel_btn)
        footer.addWidget(self.exec_btn)
        layout.addLayout(footer)

    def _select_candidate(self, path_str: str):
        self.root_edit.setText(path_str)
        self._update_space_meter()

    def _browse_root(self):
        d = QFileDialog.getExistingDirectory(self, "Googleドライブのフォルダを選択", self.root_edit.text())
        if d:
            self.root_edit.setText(os.path.normpath(d))

    def _update_space_meter(self):
        target = self.root_edit.text().strip()
        drive, _ = os.path.splitdrive(target)
        check_p = drive + "\\" if drive else target
        try:
            usage = shutil.disk_usage(check_p)
            after_free = usage.free - self.total_size
            if after_free < 0:
                self.space_label.setText(
                    f"⚠️ 容量不足警告: 移動先空き容量 {format_bytes(usage.free)} < 移動サイズ {format_bytes(self.total_size)}"
                )
                self.space_label.setStyleSheet("color: #f87171; font-weight: bold;")
            else:
                self.space_label.setText(
                    f"💾 移動先ドライブ空き容量: 現在 {format_bytes(usage.free)}  ➔  移動後残り {format_bytes(after_free)}"
                )
                self.space_label.setStyleSheet("color: #34d399; font-weight: bold;")
        except Exception:
            self.space_label.setText("💾 移動先パスを入力してください")
            self.space_label.setStyleSheet("color: #94a3b8;")

    def get_params(self) -> dict:
        return {
            "gdrive_path": self.root_edit.text().strip(),
            "subfolder": self.sub_edit.text().strip(),
            "preserve_structure": self.chk_preserve.isChecked(),
            "copy_only": self.chk_copy.isChecked(),
        }


class DeleteConfirmDialog(QDialog):
    """Native dialog for confirming Recycle Bin or Permanent deletion."""

    def __init__(self, parent, items: list):
        super().__init__(parent)
        self.setWindowTitle("🗑️ ファイル・フォルダの削除確認")
        self.resize(580, 380)
        self.items = items
        self.total_size = sum(i.get("size", 0) for i in items)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(16, 14, 16, 14)

        mode_frame = QFrame()
        mode_frame.setObjectName("SubCard")
        m_layout = QVBoxLayout(mode_frame)
        m_layout.setContentsMargins(10, 8, 10, 8)
        self.rb_recycle = QRadioButton("♻️ Windowsのゴミ箱へ移動（推奨・安全：後から元の場所へ復元可能）")
        self.rb_recycle.setChecked(True)
        self.rb_recycle.setStyleSheet("font-weight: bold; color: #60a5fa;")
        self.rb_perm = QRadioButton("⚠️ 完全に削除する（復元不可：巨大すぎてゴミ箱に入らない場合のみ使用）")
        self.rb_perm.setStyleSheet("font-weight: bold; color: #f87171;")
        m_layout.addWidget(self.rb_recycle)
        m_layout.addWidget(self.rb_perm)
        layout.addWidget(mode_frame)

        layout.addWidget(
            QLabel(f"📋 削除対象 ({len(self.items)} 件 / 開放される容量: {format_bytes(self.total_size)}):")
        )
        list_w = QListWidget()
        for it in self.items:
            icon = "📁" if it.get("type") == "dir" else "📄"
            list_w.addItem(f"{icon} {it['path']}  ({format_bytes(it.get('size', 0))})")
        layout.addWidget(list_w, 1)

        footer = QHBoxLayout()
        footer.addStretch()
        cancel_btn = QPushButton("キャンセル")
        cancel_btn.clicked.connect(self.reject)
        exec_btn = QPushButton("🗑️ 削除を実行する")
        exec_btn.setObjectName("DangerBtn")
        exec_btn.setMinimumHeight(32)
        exec_btn.clicked.connect(self.accept)
        footer.addWidget(cancel_btn)
        footer.addWidget(exec_btn)
        layout.addLayout(footer)

    def get_mode(self) -> str:
        return "recycle" if self.rb_recycle.isChecked() else "permanent"


class LogsUndoDialog(QDialog):
    """Operation history viewer with one-click Undo restoration and draggable column widths."""

    def __init__(self, parent: "DiskGuardMainWindow", on_restored_callback):
        super().__init__(parent)
        self.main_win = parent
        self.setWindowTitle("📋 操作履歴 & ワンクリック復元 (Undo)")
        self.resize(860, 450)
        self.on_restored_callback = on_restored_callback
        self._restoring = False
        self._build_ui()
        self._load_logs()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(8)

        top_row = QHBoxLayout()
        hint = QLabel("Googleドライブへ移動・コピーしたファイルは「↩️ 元に戻す」ボタンで元のローカルフォルダへ復元できます。")
        hint.setStyleSheet("color: #94a3b8;")
        top_row.addWidget(hint, 1)

        reset_col_btn = QPushButton("🔄 列幅を初期値に戻す")
        reset_col_btn.setToolTip("履歴テーブルの列幅を初期状態に戻します")
        reset_col_btn.clicked.connect(self._reset_columns)
        top_row.addWidget(reset_col_btn)
        layout.addLayout(top_row)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["日時", "操作内容", "元のパス", "移動先", "サイズ", "状態 / 復元"])
        header = self.table.horizontalHeader()
        header.setMinimumSectionSize(40)
        header.setStretchLastSection(False)
        header.setToolTip("列の境界線をマウスでドラッグして幅を変更できます（自動保存）")
        saved_widths = (
            self.main_win.config.get("ui_state", {}).get("logs_col_widths")
            if self.main_win and hasattr(self.main_win, "config")
            else None
        )
        widths = saved_widths if (isinstance(saved_widths, list) and len(saved_widths) == 6) else DEFAULT_LOGS_COL_WIDTHS
        self._restoring = True
        for i, w in enumerate(widths):
            header.setSectionResizeMode(i, QHeaderView.Interactive)
            self.table.setColumnWidth(i, max(40, int(w)))
        self._restoring = False
        header.sectionResized.connect(self._on_col_resized)

        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        layout.addWidget(self.table, 1)

        close_btn = QPushButton("閉じる")
        close_btn.clicked.connect(self.accept)
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        btn_row.addWidget(close_btn)
        layout.addLayout(btn_row)

    def _on_col_resized(self, _col: int, _old_w: int, _new_w: int):
        if self._restoring or not self.main_win:
            return
        ui_state = self.main_win.config.setdefault("ui_state", {})
        ui_state["logs_col_widths"] = [self.table.columnWidth(c) for c in range(self.table.columnCount())]
        self.main_win._schedule_save_ui_state()

    def _reset_columns(self):
        self._restoring = True
        for i, w in enumerate(DEFAULT_LOGS_COL_WIDTHS):
            self.table.setColumnWidth(i, w)
        self._restoring = False
        if self.main_win:
            ui_state = self.main_win.config.setdefault("ui_state", {})
            ui_state.pop("logs_col_widths", None)
            self.main_win._schedule_save_ui_state()

    def _load_logs(self):
        logs = backend.load_operation_logs()
        self.table.setRowCount(len(logs))
        for row, entry in enumerate(logs):
            self.table.setItem(row, 0, QTableWidgetItem(entry.get("timestamp", "")))
            self.table.setItem(row, 1, QTableWidgetItem(entry.get("action", "")))
            self.table.setItem(row, 2, QTableWidgetItem(entry.get("source", "")))
            self.table.setItem(row, 3, QTableWidgetItem(entry.get("destination", "")))
            self.table.setItem(row, 4, QTableWidgetItem(format_bytes(entry.get("size", 0))))

            status = entry.get("status", "成功")
            can_undo = entry.get("can_undo", False) and status != "復元済み"
            if can_undo and entry.get("id"):
                cell_w = QWidget()
                h = QHBoxLayout(cell_w)
                h.setContentsMargins(4, 1, 4, 1)
                undo_btn = QPushButton("↩️ 元に戻す")
                undo_btn.setObjectName("PrimaryBtn")
                undo_btn.clicked.connect(lambda _=False, lid=entry["id"]: self._undo_entry(lid))
                h.addWidget(undo_btn)
                self.table.setCellWidget(row, 5, cell_w)
            else:
                self.table.setItem(row, 5, QTableWidgetItem(status))
            self.table.setRowHeight(row, 28)

    def _undo_entry(self, log_id: str):
        logs = backend.load_operation_logs()
        target_entry = next((x for x in logs if x.get("id") == log_id), None)
        if not target_entry:
            return
        action = target_entry.get("action", "")
        source = target_entry.get("source", "")
        dest = target_entry.get("destination", "")
        if not dest or not os.path.exists(dest):
            QMessageBox.warning(self, "復元エラー", f"移動先ファイルが見つかりません:\n{dest}")
            return

        try:
            if "Googleドライブへコピー" in action and source and os.path.exists(source):
                if os.path.isdir(dest):
                    shutil.rmtree(dest)
                else:
                    os.remove(dest)
                msg = f"コピー先を削除して操作を取り消しました:\n{dest}"
            else:
                if os.path.exists(source):
                    QMessageBox.warning(self, "復元中止", f"元の場所に同名ファイルが既に存在します:\n{source}")
                    return
                Path(source).parent.mkdir(parents=True, exist_ok=True)
                shutil.move(dest, source)
                msg = f"元の場所へファイルを復元しました:\n{source}"

            target_entry["status"] = "復元済み"
            target_entry["can_undo"] = False
            backend.save_operation_logs(logs)
            QMessageBox.information(self, "復元完了", msg)
            self._load_logs()
            if self.on_restored_callback:
                self.on_restored_callback()
        except Exception as e:
            QMessageBox.critical(self, "エラー", f"復元中にエラーが発生しました:\n{e}")


class DiskGuardMainWindow(QMainWindow):
    updateCheckFinished = Signal(dict, bool)
    updateApplyFinished = Signal(dict)

    def __init__(self, local_server: QLocalServer | None = None):
        super().__init__()
        self.local_server = local_server
        self.app_icon = resolve_app_icon()
        self.setWindowIcon(self.app_icon)
        cur_ver = backend.get_current_version_info().get("version", backend.APP_VERSION)
        self.setWindowTitle(f"DiskGuard & DriveMover v{cur_ver} - フォルダサイズ解析・誤削除防止・Googleドライブ整理")
        self.setMinimumSize(1000, 600)

        self.config = backend.load_config()
        self._restoring_ui_state = False
        self._is_checking_update = False
        self._latest_update_info: dict | None = None
        self.item_tables: dict[str, QTableWidget] = {}

        self.ui_save_timer = QTimer(self)
        self.ui_save_timer.setSingleShot(True)
        self.ui_save_timer.setInterval(250)
        self.ui_save_timer.timeout.connect(self._save_ui_state_now)

        self._apply_initial_or_saved_geometry()

        self.gdrive_candidates = []
        self.current_dir = ""
        self.root_path = ""
        self.explorer_items = []
        self.large_files = []
        self.large_dirs = []
        self.large_mode = "files"
        self.recommendations = {"gdrive_candidates": [], "delete_candidates": []}
        self.duplicate_data = {"duplicate_groups": [], "total_wasted_size": 0, "group_count": 0}
        self.selected_items: dict[str, dict] = {}
        self.force_quit = False

        self.updateCheckFinished.connect(self._on_update_check_finished)
        self.updateApplyFinished.connect(self._on_update_apply_finished)

        self._setup_tray_icon()
        self._build_ui()
        self._restore_ui_state()
        self._load_system_info()

        self.scan_timer = QTimer(self)
        self.scan_timer.setInterval(300)
        self.scan_timer.timeout.connect(self._poll_scan_status)

        # 起動直後（またはプリブート自動更新後）の状態反映と定期自動アップデートチェック
        auto_updated_ver = os.environ.pop("DISKGUARD_AUTO_UPDATED_TO", "")
        if auto_updated_ver:
            self.scan_status_lbl.setText(f"✨ 起動時に最新バージョン (v{auto_updated_ver}) へ自動アップデートしました")
            QTimer.singleShot(
                800,
                lambda v=auto_updated_ver: self.tray_icon.showMessage(
                    "DiskGuard & DriveMover 自動アップデート完了",
                    f"最新バージョン (v{v}) が自動適用されました。",
                    QSystemTrayIcon.Information,
                    4000,
                ),
            )

        self.periodic_update_timer = QTimer(self)
        self.periodic_update_timer.setInterval(6 * 3600 * 1000)
        self.periodic_update_timer.timeout.connect(lambda: self._start_update_check(silent_if_latest=True))
        self.periodic_update_timer.start()
        if self.config.get("auto_update_check", True) and not auto_updated_ver:
            QTimer.singleShot(1200, lambda: self._start_update_check(silent_if_latest=True))

        if self.local_server:
            self.local_server.newConnection.connect(self._on_second_instance_connected)

    def _apply_1366x768_geometry(self):
        """1366x768 ディスプレイ（タスクバーを除いた有効領域 約1366x720）にジャストフィットさせる"""
        self._restoring_ui_state = True
        try:
            self.showNormal()
            screen = QApplication.primaryScreen()
            if screen:
                avail = screen.availableGeometry()
                target_w = min(1350, avail.width() - 8)
                target_h = min(712, avail.height() - 8)
                self.resize(target_w, target_h)
                x = avail.x() + max(0, (avail.width() - target_w) // 2)
                y = avail.y() + max(0, (avail.height() - target_h) // 2)
                self.move(x, y)
            else:
                self.resize(1340, 700)
        finally:
            self._restoring_ui_state = False

    def _apply_initial_or_saved_geometry(self):
        ui_state = self.config.get("ui_state", {})
        geom = ui_state.get("window_geometry")
        if isinstance(geom, list) and len(geom) >= 4:
            self._restoring_ui_state = True
            try:
                x, y, w, h = int(geom[0]), int(geom[1]), int(geom[2]), int(geom[3])
                screen = QApplication.primaryScreen()
                if screen:
                    avail = screen.availableGeometry()
                    w = max(1000, min(w, avail.width()))
                    h = max(600, min(h, avail.height()))
                    x = max(avail.left(), min(x, avail.right() - 120))
                    y = max(avail.top(), min(y, avail.bottom() - 80))
                self.resize(w, h)
                self.move(x, y)
                if len(geom) >= 5 and bool(geom[4]):
                    self.setWindowState(Qt.WindowMaximized)
                return
            except Exception:
                pass
            finally:
                self._restoring_ui_state = False
        self._apply_1366x768_geometry()

    def resizeEvent(self, event: QtGui.QResizeEvent):
        super().resizeEvent(event)
        if not self._restoring_ui_state and self.isVisible():
            self._schedule_save_ui_state()

    def moveEvent(self, event: QtGui.QMoveEvent):
        super().moveEvent(event)
        if not self._restoring_ui_state and self.isVisible():
            self._schedule_save_ui_state()

    def _schedule_save_ui_state(self):
        if self._restoring_ui_state:
            return
        self.ui_save_timer.start()

    def _save_ui_state_now(self):
        if self._restoring_ui_state:
            return
        ui_state = self.config.setdefault("ui_state", {})
        is_max = self.isMaximized()
        if not is_max:
            g = self.geometry()
            ui_state["window_geometry"] = [g.x(), g.y(), g.width(), g.height(), False]
        else:
            prev = ui_state.get("window_geometry", [10, 10, 1340, 700, True])
            if len(prev) >= 4:
                ui_state["window_geometry"] = [prev[0], prev[1], prev[2], prev[3], True]

        if hasattr(self, "exp_splitter"):
            ui_state["exp_splitter_sizes"] = self.exp_splitter.sizes()
        if hasattr(self, "treemap"):
            ui_state["treemap_visible"] = self.treemap.isVisible()

        col_map = ui_state.setdefault("table_col_widths", {})
        for tk, tbl in self.item_tables.items():
            col_map[tk] = [tbl.columnWidth(c) for c in range(tbl.columnCount())]

        try:
            backend.save_config(self.config)
        except Exception:
            pass

    def _restore_ui_state(self):
        self._restoring_ui_state = True
        try:
            ui_state = self.config.get("ui_state", {})
            map_vis = ui_state.get("treemap_visible", True)
            self.treemap.setVisible(bool(map_vis))
            self.btn_toggle_map.setChecked(bool(map_vis))
            self.btn_toggle_map.setText("🗺️ マップ表示: ON" if map_vis else "🗺️ マップ表示: OFF")

            sp_sizes = ui_state.get("exp_splitter_sizes")
            if isinstance(sp_sizes, list) and len(sp_sizes) == 2 and sum(sp_sizes) > 0:
                self.exp_splitter.setSizes([max(44, int(sp_sizes[0])), max(180, int(sp_sizes[1]))])
            else:
                self.exp_splitter.setSizes(list(DEFAULT_SPLITTER_SIZES))

            col_map = ui_state.get("table_col_widths", {})
            shared_cols = ui_state.get("shared_col_widths")
            for tk, tbl in self.item_tables.items():
                saved = col_map.get(tk) or shared_cols or DEFAULT_ITEM_COL_WIDTHS
                if isinstance(saved, list) and len(saved) == tbl.columnCount():
                    for c_idx, w in enumerate(saved):
                        tbl.setColumnWidth(c_idx, max(32, int(w)))
                else:
                    for c_idx, w in enumerate(DEFAULT_ITEM_COL_WIDTHS):
                        tbl.setColumnWidth(c_idx, w)
        finally:
            self._restoring_ui_state = False

    def _reset_ui_to_default(self):
        """列幅・ツリーマップ高さ・ウィンドウサイズ等のUI状態を初期状態（1366x768最適値）へ戻して保存する"""
        self._restoring_ui_state = True
        try:
            self.config["ui_state"] = {}
            for _tk, tbl in self.item_tables.items():
                for c_idx, w in enumerate(DEFAULT_ITEM_COL_WIDTHS):
                    tbl.setColumnWidth(c_idx, w)

            self.treemap.setVisible(True)
            self.btn_toggle_map.setChecked(True)
            self.btn_toggle_map.setText("🗺️ マップ表示: ON")
            self.exp_splitter.setSizes(list(DEFAULT_SPLITTER_SIZES))
            self._apply_1366x768_geometry()
            backend.save_config(self.config)
            self.scan_status_lbl.setText("✅ 表の列幅・UIレイアウトを初期状態（1366x768最適値）に戻しました")
        finally:
            self._restoring_ui_state = False

    # =====================================================================
    # System Tray & Window Close (✖ -> Task Tray)
    # =====================================================================
    def _setup_tray_icon(self):
        self.tray_icon = QSystemTrayIcon(self.app_icon, self)
        self.tray_icon.setToolTip("DiskGuard & DriveMover (常駐稼働中)")

        tray_menu = QMenu(self)
        tray_menu.setStyleSheet(
            "QMenu { background-color: #1e293b; color: #f8fafc; border: 1px solid #334155; padding: 6px; }"
            "QMenu::item { padding: 6px 20px; border-radius: 4px; }"
            "QMenu::item:selected { background-color: #2563eb; }"
        )

        act_show = QAction("📊 メイン画面を表示", self)
        act_show.triggered.connect(self.restore_from_tray)
        tray_menu.addAction(act_show)

        cur_ver = backend.get_current_version_info().get("version", backend.APP_VERSION)
        act_update = QAction(f"🔄 アップデートを確認 (現在 v{cur_ver})", self)
        act_update.triggered.connect(lambda: self._start_update_check(silent_if_latest=False))
        tray_menu.addAction(act_update)

        act_reset_ui = QAction("🔄 UI・表の列幅を初期状態に戻す", self)
        act_reset_ui.triggered.connect(self._reset_ui_to_default)
        tray_menu.addAction(act_reset_ui)

        act_gdrive = QAction("📂 Googleドライブフォルダを開く", self)
        act_gdrive.triggered.connect(self._open_gdrive_in_explorer)
        tray_menu.addAction(act_gdrive)

        tray_menu.addSeparator()

        act_quit = QAction("❌ アプリを完全に終了", self)
        act_quit.triggered.connect(self.quit_application)
        tray_menu.addAction(act_quit)

        self.tray_icon.setContextMenu(tray_menu)
        self.tray_icon.activated.connect(self._on_tray_activated)
        self.tray_icon.show()

    def _on_tray_activated(self, reason):
        if reason in (QSystemTrayIcon.Trigger, QSystemTrayIcon.DoubleClick):
            self.restore_from_tray()

    def restore_from_tray(self):
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def _on_second_instance_connected(self):
        if self.local_server:
            conn = self.local_server.nextPendingConnection()
            if conn:
                conn.close()
        self.restore_from_tray()

    def closeEvent(self, event: QtGui.QCloseEvent):
        """✖ボタンで閉じた時はUI状態を保存し、アプリを終了せずタスクトレイへ格納する"""
        self._save_ui_state_now()
        if self.force_quit:
            self.tray_icon.hide()
            event.accept()
            return

        event.ignore()
        self.hide()
        self.tray_icon.showMessage(
            "DiskGuard & DriveMover",
            "タスクトレイに格納しました。トレイアイコンをクリックすると再表示できます。",
            QSystemTrayIcon.Information,
            3000,
        )

    def quit_application(self):
        self._save_ui_state_now()
        self.force_quit = True
        self.tray_icon.hide()
        QApplication.quit()

    def _open_gdrive_in_explorer(self):
        gpath = self.config.get("google_drive_path", "")
        if gpath and os.path.exists(gpath):
            subprocess.Popen(["explorer", os.path.abspath(gpath)])
        else:
            QMessageBox.information(self, "Googleドライブ", f"フォルダが見つかりません: {gpath}")

    # =====================================================================
    # UI Construction (Optimized for 1366x768)
    # =====================================================================
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root_layout = QVBoxLayout(central)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        # 1. Slim Single-Line Top Header Bar (40px height)
        header = QFrame()
        header.setObjectName("HeaderBar")
        header.setFixedHeight(40)
        h_layout = QHBoxLayout(header)
        h_layout.setContentsMargins(12, 4, 12, 4)
        h_layout.setSpacing(6)

        cur_ver = backend.get_current_version_info().get("version", backend.APP_VERSION)
        title_lbl = QLabel(f"📊 DiskGuard & DriveMover v{cur_ver}")
        title_lbl.setStyleSheet("font-size: 13px; font-weight: bold; color: #f8fafc;")
        h_layout.addWidget(title_lbl)

        # Inline scan status inside the header bar so it uses 0 extra vertical space
        self.scan_status_lbl = QLabel("待機中 — スキャン対象を選択してください")
        self.scan_status_lbl.setStyleSheet("color: #60a5fa; font-weight: bold; font-size: 11px;")
        h_layout.addWidget(self.scan_status_lbl, 1)

        self.scan_stats_lbl = QLabel("")
        self.scan_stats_lbl.setStyleSheet("color: #94a3b8; font-size: 11px;")
        h_layout.addWidget(self.scan_stats_lbl)

        self.gdrive_badge_btn = QPushButton("☁️ 移動先: G:\\マイドライブ")
        self.gdrive_badge_btn.setObjectName("GDriveBtn")
        self.gdrive_badge_btn.clicked.connect(lambda: self.tabs.setCurrentIndex(3))
        h_layout.addWidget(self.gdrive_badge_btn)

        btn_logs = QPushButton("📋 履歴/復元")
        btn_logs.clicked.connect(self._open_logs_dialog)
        h_layout.addWidget(btn_logs)

        btn_prot = QPushButton("🛡️ 保護設定")
        btn_prot.setObjectName("ShieldBtn")
        btn_prot.clicked.connect(lambda: self.tabs.setCurrentIndex(3))
        h_layout.addWidget(btn_prot)

        self.btn_update_check = QPushButton("🔄 更新確認")
        self.btn_update_check.setToolTip(f"現在バージョン: v{cur_ver}\nクリックしてGitHubリポジトリ上の最新アップデートを確認・適用します")
        self.btn_update_check.clicked.connect(lambda: self._start_update_check(silent_if_latest=False))
        h_layout.addWidget(self.btn_update_check)

        btn_reset_ui = QPushButton("🔄 UI初期化")
        btn_reset_ui.setToolTip("表の列幅・ツリーマップ高さ・ウィンドウサイズを初期状態（1366x768最適値）に戻します")
        btn_reset_ui.clicked.connect(self._reset_ui_to_default)
        h_layout.addWidget(btn_reset_ui)

        btn_tray = QPushButton("📥 トレイ格納")
        btn_tray.setToolTip("ウィンドウを非表示にしてタスクトレイへ格納します（✖ボタンと同じ）")
        btn_tray.clicked.connect(self.close)
        h_layout.addWidget(btn_tray)

        btn_exit = QPushButton("⏹️ 終了")
        btn_exit.setObjectName("DangerBtn")
        btn_exit.clicked.connect(self.quit_application)
        h_layout.addWidget(btn_exit)

        root_layout.addWidget(header)

        # Main Body Area (tight margins for 1366x768)
        body = QWidget()
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(8, 6, 8, 6)
        body_layout.setSpacing(6)

        # 2. Unified Scan & KPI Dashboard Card (2 compact rows, ~68px total height)
        top_card = QFrame()
        top_card.setObjectName("Card")
        tc_layout = QVBoxLayout(top_card)
        tc_layout.setContentsMargins(10, 6, 10, 6)
        tc_layout.setSpacing(5)

        # Row A: Drives + Quick Folder Shortcuts + Path Input + Scan Button
        row_a = QHBoxLayout()
        row_a.setSpacing(5)

        self.drives_layout = QHBoxLayout()
        self.drives_layout.setSpacing(4)
        row_a.addLayout(self.drives_layout)

        self.shortcuts_layout = QHBoxLayout()
        self.shortcuts_layout.setSpacing(4)
        row_a.addLayout(self.shortcuts_layout)

        self.scan_path_edit = QLineEdit()
        self.scan_path_edit.setPlaceholderText("スキャン対象のフォルダパス（例: C:\\Users\\名前\\Downloads）")
        self.scan_path_edit.returnPressed.connect(self._start_scan)
        row_a.addWidget(self.scan_path_edit, 1)

        btn_browse = QPushButton("📂 参照")
        btn_browse.clicked.connect(self._browse_scan_dir)
        row_a.addWidget(btn_browse)

        self.btn_start_scan = QPushButton("🔍 解析スキャン開始")
        self.btn_start_scan.setObjectName("PrimaryBtn")
        self.btn_start_scan.clicked.connect(self._start_scan)
        row_a.addWidget(self.btn_start_scan)

        self.btn_cancel_scan = QPushButton("⏹️ 中断")
        self.btn_cancel_scan.setObjectName("DangerBtn")
        self.btn_cancel_scan.hide()
        self.btn_cancel_scan.clicked.connect(self._cancel_scan)
        row_a.addWidget(self.btn_cancel_scan)

        tc_layout.addLayout(row_a)

        # Row B: KPI Badges + Visual Category Bar + Top Categories Legend (single line)
        row_b = QHBoxLayout()
        row_b.setSpacing(10)

        self.kpi_total_lbl = QLabel("合計: -")
        self.kpi_total_lbl.setStyleSheet("font-size: 13px; font-weight: bold; color: #f8fafc;")
        self.kpi_counts_lbl = QLabel("📄 - / 📁 -")
        self.kpi_counts_lbl.setStyleSheet("color: #cbd5e1; font-size: 11px;")
        self.kpi_large_lbl = QLabel("🐘 100MB+: 0件")
        self.kpi_large_lbl.setStyleSheet("font-weight: bold; color: #fbbf24; font-size: 11px;")
        self.kpi_smart_lbl = QLabel("💡 整理可能: 0 B")
        self.kpi_smart_lbl.setStyleSheet("font-weight: bold; color: #38bdf8; font-size: 11px;")
        self.kpi_prot_lbl = QLabel("🛡️ 保護: 有効")
        self.kpi_prot_lbl.setStyleSheet("font-weight: bold; color: #34d399; font-size: 11px;")

        row_b.addWidget(self.kpi_total_lbl)
        row_b.addWidget(self.kpi_counts_lbl)
        row_b.addWidget(self.kpi_large_lbl)
        row_b.addWidget(self.kpi_smart_lbl)
        row_b.addWidget(self.kpi_prot_lbl)

        self.cat_bar = CategoryBarWidget()
        row_b.addWidget(self.cat_bar, 1)

        self.cat_legend_lbl = QLabel("内訳: スキャン待機中")
        self.cat_legend_lbl.setStyleSheet("font-size: 11px; color: #94a3b8;")
        row_b.addWidget(self.cat_legend_lbl)

        tc_layout.addLayout(row_b)
        body_layout.addWidget(top_card)

        # 3. Main Tabs (Stretches to take maximum vertical height on 1366x768)
        self.tabs = QTabWidget()
        self._build_tab_explorer()
        self._build_tab_large_finder()
        self._build_tab_smart_and_duplicates()
        self._build_tab_protection()
        self.tabs.currentChanged.connect(self._on_tab_changed)
        body_layout.addWidget(self.tabs, 1)

        # 4. Compact Bottom Bulk Action Bar (38px height)
        self.bulk_bar = QFrame()
        self.bulk_bar.setObjectName("BulkBar")
        self.bulk_bar.setFixedHeight(38)
        b_layout = QHBoxLayout(self.bulk_bar)
        b_layout.setContentsMargins(12, 3, 12, 3)
        b_layout.setSpacing(8)

        self.bulk_info_lbl = QLabel("0 件選択中 (合計 0 B)")
        self.bulk_info_lbl.setStyleSheet("font-size: 12px; font-weight: bold; color: #60a5fa;")
        b_layout.addWidget(self.bulk_info_lbl)
        b_layout.addStretch()

        btn_clear_sel = QPushButton("選択解除")
        btn_clear_sel.clicked.connect(self._clear_selection)
        b_layout.addWidget(btn_clear_sel)

        btn_bulk_prot = QPushButton("🛡️ 選択項目を保護ロック")
        btn_bulk_prot.setObjectName("ShieldBtn")
        btn_bulk_prot.clicked.connect(self._bulk_protect)
        b_layout.addWidget(btn_bulk_prot)

        btn_bulk_gdrive = QPushButton("☁️ Googleドライブへ移動・整理")
        btn_bulk_gdrive.setObjectName("GDriveBtn")
        btn_bulk_gdrive.clicked.connect(self._bulk_move_gdrive)
        b_layout.addWidget(btn_bulk_gdrive)

        btn_bulk_del = QPushButton("🗑️ ゴミ箱へ削除")
        btn_bulk_del.setObjectName("DangerBtn")
        btn_bulk_del.clicked.connect(self._bulk_delete)
        b_layout.addWidget(btn_bulk_del)

        self.bulk_bar.hide()
        body_layout.addWidget(self.bulk_bar)

        root_layout.addWidget(body, 1)

    # ---------------------------------------------------------------------
    # Tab 1: Folder Explorer & Resizable/Collapsible 2D Treemap
    # ---------------------------------------------------------------------
    def _build_tab_explorer(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(5)

        top_bar = QHBoxLayout()
        top_bar.setSpacing(6)
        self.btn_up_dir = QPushButton("⬆️ 上へ")
        self.btn_up_dir.clicked.connect(self._go_up_directory)
        top_bar.addWidget(self.btn_up_dir)

        self.breadcrumbs_layout = QHBoxLayout()
        self.breadcrumbs_layout.setSpacing(3)
        top_bar.addLayout(self.breadcrumbs_layout, 1)

        self.btn_toggle_map = QPushButton("🗺️ マップ表示: ON")
        self.btn_toggle_map.setCheckable(True)
        self.btn_toggle_map.setChecked(True)
        self.btn_toggle_map.clicked.connect(self._toggle_treemap_visibility)
        top_bar.addWidget(self.btn_toggle_map)

        btn_reset_cols_exp = QPushButton("🔄 列幅リセット")
        btn_reset_cols_exp.setToolTip("表の列幅とマップ高さを初期状態に戻します")
        btn_reset_cols_exp.clicked.connect(self._reset_ui_to_default)
        top_bar.addWidget(btn_reset_cols_exp)

        self.exp_search_edit = QLineEdit()
        self.exp_search_edit.setPlaceholderText("🔎 名前で絞り込み...")
        self.exp_search_edit.setFixedWidth(165)
        self.exp_search_edit.textChanged.connect(self._render_explorer_table)
        top_bar.addWidget(self.exp_search_edit)

        self.chk_hide_prot_exp = QCheckBox("🔒 保護済みを隠す")
        self.chk_hide_prot_exp.stateChanged.connect(self._render_explorer_table)
        top_bar.addWidget(self.chk_hide_prot_exp)

        layout.addLayout(top_bar)

        # Splitter between compact 2D Treemap and Folder Table (draggable & persisted)
        self.exp_splitter = QSplitter(Qt.Vertical)
        self.treemap = TreemapWidget()
        self.treemap.folderClicked.connect(self._load_directory_view)
        self.exp_splitter.addWidget(self.treemap)

        self.exp_table = self._create_items_table("exp")
        self.exp_splitter.addWidget(self.exp_table)
        self.exp_splitter.setStretchFactor(0, 0)
        self.exp_splitter.setStretchFactor(1, 1)
        self.exp_splitter.setSizes(list(DEFAULT_SPLITTER_SIZES))
        self.exp_splitter.splitterMoved.connect(self._on_splitter_moved)

        layout.addWidget(self.exp_splitter, 1)
        self.tabs.addTab(tab, "📁 フォルダ階層・サイズ内訳")

    def _toggle_treemap_visibility(self, checked: bool):
        self.treemap.setVisible(checked)
        self.btn_toggle_map.setText("🗺️ マップ表示: ON" if checked else "🗺️ マップ表示: OFF")
        self._schedule_save_ui_state()

    def _on_splitter_moved(self, _pos: int, _index: int):
        self._schedule_save_ui_state()

    # ---------------------------------------------------------------------
    # Tab 2: Giant Files & Folders Finder (Single-Toolbar Layout for 1366x768)
    # ---------------------------------------------------------------------
    def _build_tab_large_finder(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(5)

        ctrl_row = QHBoxLayout()
        ctrl_row.setSpacing(6)
        self.btn_mode_files = QPushButton("📄 巨大ファイル TOP")
        self.btn_mode_files.setObjectName("PrimaryBtn")
        self.btn_mode_files.clicked.connect(lambda: self._switch_large_mode("files"))
        self.btn_mode_dirs = QPushButton("📁 巨大フォルダ TOP")
        self.btn_mode_dirs.clicked.connect(lambda: self._switch_large_mode("dirs"))
        ctrl_row.addWidget(self.btn_mode_files)
        ctrl_row.addWidget(self.btn_mode_dirs)

        ctrl_row.addWidget(QLabel("サイズ:"))
        self.cmb_min_size = QComboBox()
        for label, mb in [("10MB以上", 10), ("50MB以上", 50), ("100MB以上", 100), ("500MB以上", 500), ("1GB以上", 1024)]:
            self.cmb_min_size.addItem(label, mb)
        self.cmb_min_size.setCurrentIndex(2)
        self.cmb_min_size.currentIndexChanged.connect(self._render_large_table)
        ctrl_row.addWidget(self.cmb_min_size)

        ctrl_row.addWidget(QLabel("種類:"))
        self.cmb_category = QComboBox()
        self.cmb_category.setMaximumWidth(175)
        self.cmb_category.addItem("すべての種類", "ALL")
        for cat in list(backend.FILE_CATEGORIES.keys()) + ["その他 (Other)"]:
            self.cmb_category.addItem(cat, cat)
        self.cmb_category.currentIndexChanged.connect(self._render_large_table)
        ctrl_row.addWidget(self.cmb_category)

        ctrl_row.addWidget(QLabel("放置:"))
        self.cmb_unused = QComboBox()
        for label, days in [("すべて", 0), ("30日以上", 30), ("90日以上", 90), ("180日以上", 180), ("1年以上", 365)]:
            self.cmb_unused.addItem(label, days)
        self.cmb_unused.currentIndexChanged.connect(self._render_large_table)
        ctrl_row.addWidget(self.cmb_unused)

        self.chk_hide_prot_large = QCheckBox("🔒 保護中を除外（整理可能のみ）")
        self.chk_hide_prot_large.setChecked(False)
        self.chk_hide_prot_large.stateChanged.connect(self._render_large_table)
        ctrl_row.addWidget(self.chk_hide_prot_large)

        ctrl_row.addStretch()

        self.large_summary_lbl = QLabel("スキャン待機中")
        self.large_summary_lbl.setStyleSheet("color: #60a5fa; font-weight: bold;")
        ctrl_row.addWidget(self.large_summary_lbl)

        btn_reset_cols_lg = QPushButton("🔄 列幅リセット")
        btn_reset_cols_lg.setToolTip("表の列幅を初期状態に戻します")
        btn_reset_cols_lg.clicked.connect(self._reset_ui_to_default)
        ctrl_row.addWidget(btn_reset_cols_lg)

        layout.addLayout(ctrl_row)

        self.large_table = self._create_items_table("large")
        layout.addWidget(self.large_table, 1)

        self.tabs.addTab(tab, "🐘 巨大ファイル・フォルダ発見器")

    # ---------------------------------------------------------------------
    # Tab 3: Smart Cleanup Advisor & Duplicate File Finder
    # ---------------------------------------------------------------------
    def _build_tab_smart_and_duplicates(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(4)

        sub_tabs = QTabWidget()

        # Subtab A: Google Drive Recommendations
        sub_gd = QWidget()
        gd_l = QVBoxLayout(sub_gd)
        gd_l.setContentsMargins(6, 6, 6, 6)
        gd_l.setSpacing(4)
        gd_top = QHBoxLayout()
        self.lbl_rec_gdrive = QLabel("☁️ 長期間開いていない大容量の動画・アーカイブ・ドキュメント等をGoogleドライブ移動候補として提案します。")
        self.lbl_rec_gdrive.setStyleSheet("color: #34d399; font-weight: bold;")
        btn_sel_all_gd = QPushButton("☁️ おすすめ候補を一括でGoogleドライブへ移動")
        btn_sel_all_gd.setObjectName("GDriveBtn")
        btn_sel_all_gd.clicked.connect(self._action_all_gdrive_recommendations)
        gd_top.addWidget(self.lbl_rec_gdrive, 1)
        gd_top.addWidget(btn_sel_all_gd)
        gd_l.addLayout(gd_top)
        self.rec_gdrive_table = self._create_items_table("rec_gdrive", third_col_title="おすすめ理由")
        gd_l.addWidget(self.rec_gdrive_table, 1)
        sub_tabs.addTab(sub_gd, "☁️ Googleドライブ移動おすすめ")

        # Subtab B: Delete Recommendations
        sub_del = QWidget()
        del_l = QVBoxLayout(sub_del)
        del_l.setContentsMargins(6, 6, 6, 6)
        del_l.setSpacing(4)
        del_top = QHBoxLayout()
        self.lbl_rec_del = QLabel("🧹 ダウンロード済みのインストーラー（.exe/.msi）や一時ファイル（.tmp/.log等）の削除候補を提案します。")
        self.lbl_rec_del.setStyleSheet("color: #fbbf24; font-weight: bold;")
        btn_sel_all_del = QPushButton("🗑️ 削除おすすめ候補を一括でゴミ箱へ")
        btn_sel_all_del.setObjectName("DangerBtn")
        btn_sel_all_del.clicked.connect(self._action_all_delete_recommendations)
        del_top.addWidget(self.lbl_rec_del, 1)
        del_top.addWidget(btn_sel_all_del)
        del_l.addLayout(del_top)
        self.rec_del_table = self._create_items_table("rec_del", third_col_title="おすすめ理由")
        del_l.addWidget(self.rec_del_table, 1)
        sub_tabs.addTab(sub_del, "🧹 不要・一時ファイル削除おすすめ")

        # Subtab C: Duplicate Files Finder
        sub_dup = QWidget()
        dup_l = QVBoxLayout(sub_dup)
        dup_l.setContentsMargins(6, 6, 6, 6)
        dup_l.setSpacing(4)
        dup_top = QHBoxLayout()
        self.lbl_dup_summary = QLabel("👯 同一内容（SHA-256完全一致）の重複ファイルを検出し、無駄な容量を特定します。")
        self.lbl_dup_summary.setStyleSheet("color: #c084fc; font-weight: bold;")
        btn_auto_sel_dup = QPushButton("✨ 各グループの最新1つだけ残して残りを一括選択")
        btn_auto_sel_dup.setObjectName("PrimaryBtn")
        btn_auto_sel_dup.clicked.connect(self._auto_select_older_duplicates)
        dup_top.addWidget(self.lbl_dup_summary, 1)
        dup_top.addWidget(btn_auto_sel_dup)
        dup_l.addLayout(dup_top)
        self.dup_table = self._create_items_table("dup", third_col_title="重複グループ / 推奨判定")
        dup_l.addWidget(self.dup_table, 1)
        sub_tabs.addTab(sub_dup, "👯 重複ファイル検出")

        layout.addWidget(sub_tabs, 1)
        self.tabs.addTab(tab, "💡 スマート整理提案 & 重複検出")

    # ---------------------------------------------------------------------
    # Tab 4: Protection & Safety Rules (Compact 2-Column Layout for 1366x768)
    # ---------------------------------------------------------------------
    def _build_tab_protection(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(6)

        # Preset Banner
        preset_frame = QFrame()
        preset_frame.setObjectName("SubCard")
        p_layout = QHBoxLayout(preset_frame)
        p_layout.setContentsMargins(10, 4, 10, 4)
        p_layout.setSpacing(6)
        p_layout.addWidget(QLabel("⚡ ワンクリック保護プリセット追加:"))
        for label, key in [
            ("💻 開発・ソースコード (.git/node_modules/src等)", "dev"),
            ("🏢 重要業務書類 (確定申告/契約書/請求書等)", "office"),
            ("📷 写真・原本データ (家族写真/原本/RAW等)", "photo"),
        ]:
            b = QPushButton(label)
            b.setObjectName("ShieldBtn")
            b.clicked.connect(lambda _=False, k=key: self._apply_protection_preset(k))
            p_layout.addWidget(b)
        p_layout.addStretch()
        layout.addWidget(preset_frame)

        grid = QHBoxLayout()
        grid.setSpacing(10)

        # Left column: System Protection & Google Drive Default Path
        left_box = QFrame()
        left_box.setObjectName("SubCard")
        l_col = QVBoxLayout(left_box)
        l_col.setContentsMargins(10, 8, 10, 8)
        l_col.setSpacing(6)

        lbl_s1 = QLabel("🛡️ 1. 重要領域・危険ファイルの自動保護（初期値＝安全側設計）")
        lbl_s1.setStyleSheet("font-weight: bold; color: #fde68a;")
        l_col.addWidget(lbl_s1)

        self.chk_prot_sys = QCheckBox("Windowsシステム・リカバリ領域（C:\\Windows, Program Files, C:\\Fujitsu等）")
        self.chk_prot_sys.stateChanged.connect(self._save_protection_settings)
        self.chk_prot_appdata = QCheckBox("AppData（アプリ設定・ブラウザデータ等）を自動保護")
        self.chk_prot_appdata.stateChanged.connect(self._save_protection_settings)
        self.chk_prot_mail = QCheckBox("Outlookメールデータ（.pst, .ost, Outlook ファイル等）とデータベースを保護")
        self.chk_prot_mail.stateChanged.connect(self._save_protection_settings)
        self.chk_prot_vm = QCheckBox("仮想ディスク・OSイメージ（.vhdx, .vhd, .vmdk, .wim, .esd等）を保護")
        self.chk_prot_vm.stateChanged.connect(self._save_protection_settings)
        self.chk_prot_dev = QCheckBox("開発環境・隠し設定フォルダ（.lmstudio, .git, node_modules, システム開発等）を保護")
        self.chk_prot_dev.stateChanged.connect(self._save_protection_settings)
        self.chk_prot_unknown = QCheckBox("プログラム実行ファイル（.exe等）および未確認拡張子を安全側（保護）にする")
        self.chk_prot_unknown.stateChanged.connect(self._save_protection_settings)
        l_col.addWidget(self.chk_prot_sys)
        l_col.addWidget(self.chk_prot_appdata)
        l_col.addWidget(self.chk_prot_mail)
        l_col.addWidget(self.chk_prot_vm)
        l_col.addWidget(self.chk_prot_dev)
        l_col.addWidget(self.chk_prot_unknown)

        l_col.addWidget(QLabel("保護する拡張子（カンマ区切り）:"))
        ext_row = QHBoxLayout()
        self.edit_prot_exts = QLineEdit()
        btn_save_ext = QPushButton("保存")
        btn_save_ext.setObjectName("PrimaryBtn")
        btn_save_ext.clicked.connect(self._save_protection_settings)
        ext_row.addWidget(self.edit_prot_exts, 1)
        ext_row.addWidget(btn_save_ext)
        l_col.addLayout(ext_row)

        lbl_s2 = QLabel("☁️ 2. Googleドライブ既定の移動先フォルダ設定")
        lbl_s2.setStyleSheet("font-weight: bold; color: #34d399;")
        l_col.addWidget(lbl_s2)
        gd_row = QHBoxLayout()
        self.edit_default_gdrive = QLineEdit()
        btn_browse_gd = QPushButton("参照...")
        btn_browse_gd.clicked.connect(self._browse_default_gdrive)
        btn_save_gd = QPushButton("移動先を保存")
        btn_save_gd.setObjectName("GDriveBtn")
        btn_save_gd.clicked.connect(self._save_protection_settings)
        gd_row.addWidget(self.edit_default_gdrive, 1)
        gd_row.addWidget(btn_browse_gd)
        gd_row.addWidget(btn_save_gd)
        l_col.addLayout(gd_row)

        lbl_s_upd = QLabel("🔄 3. 自動アップデート設定（GitHubリポジトリ連携）")
        lbl_s_upd.setStyleSheet("font-weight: bold; color: #60a5fa;")
        l_col.addWidget(lbl_s_upd)
        upd_row = QHBoxLayout()
        self.chk_auto_update = QCheckBox("アプリ起動時および常駐時に最新バージョンへ自動アップデートする")
        self.chk_auto_update.stateChanged.connect(self._save_protection_settings)
        btn_manual_upd = QPushButton("🔄 今すぐ更新チェック")
        btn_manual_upd.setObjectName("PrimaryBtn")
        btn_manual_upd.clicked.connect(lambda: self._start_update_check(silent_if_latest=False))
        upd_row.addWidget(self.chk_auto_update, 1)
        upd_row.addWidget(btn_manual_upd)
        l_col.addLayout(upd_row)
        l_col.addStretch()

        grid.addWidget(left_box, 1)

        # Right column: Custom Protected Paths (Whitelist) & Keywords
        right_box = QFrame()
        right_box.setObjectName("SubCard")
        r_col = QVBoxLayout(right_box)
        r_col.setContentsMargins(10, 8, 10, 8)
        r_col.setSpacing(5)

        lbl_s3 = QLabel("🔒 3. ユーザー指定の「削除禁止リスト（ホワイトリスト）」")
        lbl_s3.setStyleSheet("font-weight: bold; color: #fde68a;")
        r_col.addWidget(lbl_s3)

        add_path_row = QHBoxLayout()
        self.edit_add_prot_path = QLineEdit()
        self.edit_add_prot_path.setPlaceholderText("保護したいフォルダまたはファイルのパス")
        btn_browse_prot = QPushButton("参照...")
        btn_browse_prot.clicked.connect(self._browse_protect_path)
        btn_add_prot = QPushButton("＋ 追加")
        btn_add_prot.setObjectName("ShieldBtn")
        btn_add_prot.clicked.connect(self._add_custom_protected_path)
        btn_remove_prot = QPushButton("🔓 選択解除")
        btn_remove_prot.clicked.connect(self._remove_selected_protected_path)
        add_path_row.addWidget(self.edit_add_prot_path, 1)
        add_path_row.addWidget(btn_browse_prot)
        add_path_row.addWidget(btn_add_prot)
        add_path_row.addWidget(btn_remove_prot)
        r_col.addLayout(add_path_row)

        self.list_prot_paths = QListWidget()
        r_col.addWidget(self.list_prot_paths, 1)

        lbl_s4 = QLabel("🏷️ 4. 保護キーワード（パスに含まれていたら削除禁止）")
        lbl_s4.setStyleSheet("font-weight: bold; color: #fde68a;")
        r_col.addWidget(lbl_s4)

        kw_row = QHBoxLayout()
        self.edit_add_kw = QLineEdit()
        self.edit_add_kw.setPlaceholderText("例: 確定申告, 重要書類, バックアップ")
        btn_add_kw = QPushButton("＋ 追加")
        btn_add_kw.setObjectName("ShieldBtn")
        btn_add_kw.clicked.connect(self._add_protected_keyword)
        btn_remove_kw = QPushButton("選択削除")
        btn_remove_kw.clicked.connect(self._remove_selected_keyword)
        kw_row.addWidget(self.edit_add_kw, 1)
        kw_row.addWidget(btn_add_kw)
        kw_row.addWidget(btn_remove_kw)
        r_col.addLayout(kw_row)

        self.list_prot_kws = QListWidget()
        self.list_prot_kws.setMaximumHeight(75)
        r_col.addWidget(self.list_prot_kws)

        grid.addWidget(right_box, 1)
        layout.addLayout(grid, 1)

        self.tabs.addTab(tab, "🛡️ 削除禁止・保護ルール設定")

    def _create_items_table(self, table_key: str, third_col_title: str = "種類 / 項目数") -> QTableWidget:
        """全7列すべてをマウスドラッグで自由リサイズ可能にし、変更時に自動保存・永続化するテーブル"""
        table = QTableWidget(0, 7)
        table.setHorizontalHeaderLabels([
            "選択",
            "名前 / 場所 (ダブルクリックでフォルダ移動)",
            "サイズ",
            third_col_title,
            "最終更新 (放置)",
            "保護ステータス",
            "操作 (保護 / 移動 / 削除 / 開く)",
        ])
        header = table.horizontalHeader()
        header.setMinimumSectionSize(32)
        header.setStretchLastSection(False)
        header.setToolTip("列ヘッダーの境界線をマウスでドラッグして幅を変更できます（変更は自動保存されます）")

        for col_idx, default_w in enumerate(DEFAULT_ITEM_COL_WIDTHS):
            header.setSectionResizeMode(col_idx, QHeaderView.Interactive)
            table.setColumnWidth(col_idx, default_w)

        header.sectionResized.connect(
            lambda col, old_w, new_w, tk=table_key, tbl=table: self._on_table_column_resized(tk, tbl, col, new_w)
        )

        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setSelectionBehavior(QAbstractItemView.SelectRows)
        table.setAlternatingRowColors(True)
        table.setSortingEnabled(True)
        table.cellDoubleClicked.connect(lambda r, c, t=table: self._on_table_double_clicked(t, r, c))
        self.item_tables[table_key] = table
        return table

    def _on_table_column_resized(self, table_key: str, source_table: QTableWidget, col_idx: int, new_width: int):
        if self._restoring_ui_state:
            return
        self._restoring_ui_state = True
        try:
            # 他のタブの同一構成テーブルにもドラッグした列幅を同期して一貫性を保つ
            for tk, tbl in self.item_tables.items():
                if tk != table_key and col_idx < tbl.columnCount():
                    tbl.setColumnWidth(col_idx, new_width)
            ui_state = self.config.setdefault("ui_state", {})
            ui_state["shared_col_widths"] = [source_table.columnWidth(c) for c in range(source_table.columnCount())]
        finally:
            self._restoring_ui_state = False
        self._schedule_save_ui_state()

    # =====================================================================
    # Data Loading & Scanning
    # =====================================================================
    def _load_system_info(self):
        info = backend.get_system_drives_and_shortcuts()
        self.config = backend.load_config()
        self.gdrive_candidates = info.get("google_drive_candidates", [])

        while self.drives_layout.count():
            w = self.drives_layout.takeAt(0).widget()
            if w:
                w.deleteLater()

        for d in info.get("drives", []):
            btn = QPushButton(f"💽 {d['path'][:2]} {d['percent']}% (空{format_bytes(d['free'])})")
            btn.setObjectName("DriveBtn")
            btn.setToolTip(f"{d['label']} — 使用率 {d['percent']}% / 空き容量 {format_bytes(d['free'])}")
            if d["percent"] >= 85:
                btn.setStyleSheet("border: 1px solid #f59e0b; color: #fde68a;")
            btn.clicked.connect(lambda _=False, p=d["path"]: self._select_scan_target(p, auto_start=False))
            self.drives_layout.addWidget(btn)

        while self.shortcuts_layout.count():
            w = self.shortcuts_layout.takeAt(0).widget()
            if w:
                w.deleteLater()

        for s in info.get("shortcuts", []):
            short_name = s["name"].replace("PC (ユーザー)", "ユーザー")
            chip = QPushButton(f"{s['icon']}{short_name}")
            chip.setObjectName("ChipBtn")
            chip.setToolTip(f"{s['name']} ({s['path']}) をスキャン")
            chip.clicked.connect(lambda _=False, p=s["path"]: self._select_scan_target(p, auto_start=True))
            self.shortcuts_layout.addWidget(chip)

        if not self.scan_path_edit.text():
            shortcuts = info.get("shortcuts", [])
            dl = next((s for s in shortcuts if s["name"] == "ダウンロード"), shortcuts[0] if shortcuts else None)
            if dl:
                self.scan_path_edit.setText(dl["path"])

        self._sync_config_to_ui()

    def _sync_config_to_ui(self):
        gpath = self.config.get("google_drive_path", r"G:\マイドライブ")
        self.gdrive_badge_btn.setText(f"☁️ 移動先: {gpath}")
        self.edit_default_gdrive.setText(gpath)

        for chk, key in [
            (self.chk_prot_sys, "protect_system_folders"),
            (self.chk_prot_appdata, "protect_appdata"),
            (self.chk_prot_mail, "protect_mail_and_db"),
            (self.chk_prot_vm, "protect_virtual_disks"),
            (self.chk_prot_dev, "protect_dev_and_hidden"),
            (self.chk_prot_unknown, "protect_unknown_extensions"),
            (self.chk_auto_update, "auto_update_check"),
        ]:
            chk.blockSignals(True)
            chk.setChecked(self.config.get(key, True))
            chk.blockSignals(False)

        self.edit_prot_exts.setText(", ".join(self.config.get("protected_extensions", [])))

        self.list_prot_paths.clear()
        for p in self.config.get("custom_protected_paths", []):
            self.list_prot_paths.addItem(p)

        self.list_prot_kws.clear()
        for kw in self.config.get("custom_protected_keywords", []):
            self.list_prot_kws.addItem(kw)

        rule_count = (
            len(self.config.get("custom_protected_paths", []))
            + len(self.config.get("custom_protected_keywords", []))
            + (1 if self.config.get("protect_system_folders", True) else 0)
        )
        self.kpi_prot_lbl.setText(f"🛡️ 保護: {rule_count}件有効")

    def _select_scan_target(self, path_str: str, auto_start: bool = False):
        self.scan_path_edit.setText(path_str)
        if auto_start:
            self._start_scan()

    def _browse_scan_dir(self):
        d = QFileDialog.getExistingDirectory(self, "スキャン対象フォルダを選択", self.scan_path_edit.text())
        if d:
            self.scan_path_edit.setText(os.path.normpath(d))

    def _start_scan(self):
        target = self.scan_path_edit.text().strip()
        if not target or not os.path.exists(target):
            QMessageBox.warning(self, "入力エラー", f"有効なフォルダパスを指定してください:\n{target}")
            return

        abs_target = os.path.abspath(target)
        self._clear_selection()
        self.root_path = abs_target
        self.current_dir = abs_target
        self._scan_poll_tick = 0
        backend.SCAN_SESSION.start_scan(abs_target, min_large_file_mb=10)
        self.btn_start_scan.setEnabled(False)
        self.btn_cancel_scan.show()
        self.scan_status_lbl.setText("🔍 高速スキャン中（判明分から順次リアルタイム表示）...")
        self.scan_timer.start()

    def _cancel_scan(self):
        with backend.SCAN_SESSION.lock:
            backend.SCAN_SESSION.cancel_flag = True

    def _update_kpi_and_category_bar(self, t_size: int, s_files: int, s_dirs: int, cat_totals: dict):
        self.kpi_total_lbl.setText(f"合計: {format_bytes(t_size)}")
        self.kpi_counts_lbl.setText(f"📄{s_files:,} / 📁{s_dirs:,}")
        self.cat_bar.set_data(cat_totals, t_size)

        legend_parts = []
        for cat, info in sorted(cat_totals.items(), key=lambda x: x[1]["size"], reverse=True)[:3]:
            if info["size"] > 0 and t_size > 0:
                pct = info["size"] / t_size * 100
                short_cat = cat.split(" (")[0]
                legend_parts.append(f"■{short_cat}:{pct:.0f}%")
        self.cat_legend_lbl.setText("  ".join(legend_parts) if legend_parts else "集計中...")

    def _on_tab_changed(self, idx: int):
        if not self.root_path:
            return
        if idx == 0:
            self._load_directory_view(self.current_dir or self.root_path)
        elif idx == 1:
            self._load_large_items()
        elif idx == 2:
            with backend.SCAN_SESSION.lock:
                st = backend.SCAN_SESSION.status
            if st == "scanning":
                self._load_smart_recommendations_only()
            else:
                self._load_smart_and_duplicates()

    def _refresh_live_during_scan(self):
        if not self.root_path:
            return
        active_tab = self.tabs.currentIndex()
        # フォルダ階層ビュー（現在表示中のフォルダ）と巨大ファイルKPIをリアルタイム更新
        if active_tab == 0 or not self.explorer_items:
            self._load_directory_view(self.current_dir or self.root_path)
        self._load_large_items(render_table=(active_tab == 1))
        if active_tab == 2 or (getattr(self, "_scan_poll_tick", 0) % 9 == 0):
            self._load_smart_recommendations_only(render_tables=(active_tab == 2))

    def _poll_scan_status(self):
        with backend.SCAN_SESSION.lock:
            st = backend.SCAN_SESSION.status
            root_p = backend.SCAN_SESSION.root_path
            s_files = backend.SCAN_SESSION.scanned_files
            s_dirs = backend.SCAN_SESSION.scanned_dirs
            t_size = backend.SCAN_SESSION.total_size
            curr_p = backend.SCAN_SESSION.current_path
            elapsed = backend.SCAN_SESSION.elapsed_sec
            err = backend.SCAN_SESSION.error_msg
            cat_totals = {k: dict(v) for k, v in backend.SCAN_SESSION.category_Totals.items()}

        self.scan_stats_lbl.setText(
            f"📁{s_dirs:,} | 📄{s_files:,} | 💾{format_bytes(t_size)} | ⏱️{elapsed}s"
        )
        short_curr = curr_p if len(curr_p) < 48 else "..." + curr_p[-45:]
        self.scan_status_lbl.setText(f"🔍 {short_curr}")

        # スキャン途中でもKPI・カテゴリ比率バーを毎回リアルタイム更新
        self._update_kpi_and_category_bar(t_size, s_files, s_dirs, cat_totals)

        if st == "scanning":
            self._scan_poll_tick = getattr(self, "_scan_poll_tick", 0) + 1
            if self._scan_poll_tick == 1 or self._scan_poll_tick % 3 == 0:
                self._refresh_live_during_scan()

        elif st == "completed":
            self.scan_timer.stop()
            self.btn_start_scan.setEnabled(True)
            self.btn_cancel_scan.hide()
            self.scan_status_lbl.setText(f"✅ 完了: {root_p}")
            self.root_path = root_p
            if not self.current_dir:
                self.current_dir = root_p
            self._refresh_all_views()

        elif st in ("cancelled", "error"):
            self.scan_timer.stop()
            self.btn_start_scan.setEnabled(True)
            self.btn_cancel_scan.hide()
            if st == "cancelled":
                self.scan_status_lbl.setText(f"⚠️ スキャン中断（途中まで判明した {s_files:,} 件を表示中）")
                self._refresh_all_views()
            else:
                self.scan_status_lbl.setText(f"❌ エラー: {err}")

    def _refresh_all_views(self):
        if self.ui_save_timer.isActive():
            self.ui_save_timer.stop()
            self._save_ui_state_now()
        if not self.root_path:
            return
        self.config = backend.load_config()
        self._load_directory_view(self.current_dir or self.root_path)
        self._load_large_items()
        self._load_smart_and_duplicates()

    # =====================================================================
    # View Updaters
    # =====================================================================
    def _load_directory_view(self, dir_path: str):
        view = backend.SCAN_SESSION.get_directory_view(dir_path, self.config)
        if "error" in view:
            return
        self.current_dir = view["path"]
        self.explorer_items = view.get("items", [])

        while self.breadcrumbs_layout.count():
            w = self.breadcrumbs_layout.takeAt(0).widget()
            if w:
                w.deleteLater()

        crumbs = view.get("breadcrumbs", [])
        # On 1366x768, show root + last 4 breadcrumbs if very deep so toolbar never overflows
        display_crumbs = crumbs if len(crumbs) <= 6 else [crumbs[0], {"name": "...", "path": crumbs[-5]["path"]}] + crumbs[-4:]
        for idx, c in enumerate(display_crumbs):
            name_lbl = c["name"] if len(c["name"]) <= 18 else c["name"][:16] + "…"
            b = QPushButton(f"📂 {name_lbl}" if idx == 0 else name_lbl)
            b.setObjectName("ChipBtn")
            b.setToolTip(c["path"])
            b.clicked.connect(lambda _=False, p=c["path"]: self._load_directory_view(p))
            self.breadcrumbs_layout.addWidget(b)
        self.breadcrumbs_layout.addStretch()

        self._render_explorer_table()

    def _go_up_directory(self):
        if not self.current_dir or not self.root_path:
            return
        if backend.normalize_path(self.current_dir) == backend.normalize_path(self.root_path):
            return
        parent = os.path.dirname(self.current_dir)
        if parent and parent != self.current_dir:
            self._load_directory_view(parent)

    def _render_explorer_table(self):
        kw = self.exp_search_edit.text().strip().lower()
        hide_prot = self.chk_hide_prot_exp.isChecked()

        filtered = []
        for it in self.explorer_items:
            if kw and kw not in it["name"].lower():
                continue
            if hide_prot and it.get("protection", {}).get("is_protected"):
                continue
            filtered.append(it)

        self.treemap.set_items(filtered)
        self._populate_table(self.exp_table, filtered, show_full_path=False)

    def _load_large_items(self, render_table: bool = True):
        now_ts = time.time()
        with backend.SCAN_SESSION.lock:
            raw_large = list(backend.SCAN_SESSION.large_files)
            root_norm = backend.normalize_path(backend.SCAN_SESSION.root_path)
            dir_list = [
                dict(meta)
                for norm_p, meta in backend.SCAN_SESSION.dir_Read_meta.items()
                if norm_p != root_norm and meta.get("size", 0) >= 50 * 1024 * 1024
            ]
        dir_list.sort(key=lambda x: x["size"], reverse=True)

        self.large_files = []
        for f in raw_large:
            prot = backend.check_protection_status(f["path"], self.config)
            last_u = max(f["mtime"], f.get("atime", f["mtime"]))
            days = int(max(0, now_ts - last_u) // 86400) if last_u else 0
            item = dict(f)
            item["days_unused"] = days
            item["protection"] = prot
            self.large_files.append(item)

        self.large_dirs = []
        for d in dir_list[:200]:
            prot = backend.check_protection_status(d["path"], self.config)
            days = int(max(0, now_ts - d["mtime"]) // 86400) if d["mtime"] else 0
            self.large_dirs.append({
                "path": d["path"],
                "name": d["name"],
                "type": "dir",
                "size": d["size"],
                "mtime": d["mtime"],
                "days_unused": days,
                "category": "フォルダ",
                "item_count": d.get("file_count", 0) + d.get("dir_count", 0),
                "scanning": d.get("scanning", False),
                "protection": prot,
            })

        over100 = [f for f in self.large_files if f["size"] >= 100 * 1024 * 1024]
        self.kpi_large_lbl.setText(
            f"🐘 100MB+: {len(over100)}件 ({format_bytes(sum(x['size'] for x in over100))})"
        )
        if render_table:
            self._render_large_table()

    def _switch_large_mode(self, mode: str):
        self.large_mode = mode
        self.btn_mode_files.setObjectName("PrimaryBtn" if mode == "files" else "")
        self.btn_mode_dirs.setObjectName("PrimaryBtn" if mode == "dirs" else "")
        self.btn_mode_files.style().unpolish(self.btn_mode_files)
        self.btn_mode_files.style().polish(self.btn_mode_files)
        self.btn_mode_dirs.style().unpolish(self.btn_mode_dirs)
        self.btn_mode_dirs.style().polish(self.btn_mode_dirs)
        self.cmb_category.setEnabled(mode == "files")
        self._render_large_table()

    def _render_large_table(self):
        min_mb = self.cmb_min_size.currentData() or 10
        min_bytes = min_mb * 1024 * 1024
        cat_filter = self.cmb_category.currentData() or "ALL"
        min_days = self.cmb_unused.currentData() or 0
        hide_prot = self.chk_hide_prot_large.isChecked()

        source = self.large_files if self.large_mode == "files" else self.large_dirs
        filtered = []
        for it in source:
            if it["size"] < min_bytes:
                continue
            if self.large_mode == "files" and cat_filter != "ALL" and it.get("category") != cat_filter:
                continue
            if min_days > 0 and it.get("days_unused", 0) < min_days:
                continue
            if hide_prot and it.get("protection", {}).get("is_protected"):
                continue
            filtered.append(it)

        total_sz = sum(x["size"] for x in filtered)
        self.large_summary_lbl.setText(
            f"🎯 {len(filtered)} 件 （合計: {format_bytes(total_sz)}）"
        )
        self._populate_table(self.large_table, filtered, show_full_path=True)

    def _load_smart_recommendations_only(self, render_tables: bool = True):
        """スキャン途中に軽量・高速でスマート整理提案のみをリアルタイム更新する"""
        self.recommendations = backend.SCAN_SESSION.get_recommendations(self.config)
        gd_cands = self.recommendations.get("gdrive_candidates", [])
        del_cands = self.recommendations.get("delete_candidates", [])
        wasted = self.duplicate_data.get("total_wasted_size", 0)

        rec_total = sum(x["size"] for x in gd_cands) + sum(x["size"] for x in del_cands) + wasted
        self.kpi_smart_lbl.setText(f"💡 整理可能: {format_bytes(rec_total)}")

        self.lbl_rec_gdrive.setText(
            f"☁️ Googleドライブ移動おすすめ: {len(gd_cands)} 件 （合計 {format_bytes(sum(x['size'] for x in gd_cands))}）"
        )
        self.lbl_rec_del.setText(
            f"🧹 不要・一時ファイル削除おすすめ: {len(del_cands)} 件 （合計 {format_bytes(sum(x['size'] for x in del_cands))}）"
        )
        self.lbl_dup_summary.setText("👯 重複ファイル: スキャン完了時にSHA-256ハッシュ照合を実行します...")

        if render_tables:
            self._populate_table(self.rec_gdrive_table, gd_cands, show_full_path=True, third_col_key="reason")
            self._populate_table(self.rec_del_table, del_cands, show_full_path=True, third_col_key="reason")

    def _load_smart_and_duplicates(self):
        self.recommendations = backend.SCAN_SESSION.get_recommendations(self.config)
        self.duplicate_data = backend.SCAN_SESSION.get_duplicates(self.config, min_size_bytes=1024 * 1024)

        gd_cands = self.recommendations.get("gdrive_candidates", [])
        del_cands = self.recommendations.get("delete_candidates", [])
        dup_groups = self.duplicate_data.get("duplicate_groups", [])
        wasted = self.duplicate_data.get("total_wasted_size", 0)

        rec_total = sum(x["size"] for x in gd_cands) + sum(x["size"] for x in del_cands) + wasted
        self.kpi_smart_lbl.setText(f"💡 整理可能: {format_bytes(rec_total)}")

        self.lbl_rec_gdrive.setText(
            f"☁️ Googleドライブ移動おすすめ: {len(gd_cands)} 件 （合計 {format_bytes(sum(x['size'] for x in gd_cands))}）"
        )
        self.lbl_rec_del.setText(
            f"🧹 不要・一時ファイル削除おすすめ: {len(del_cands)} 件 （合計 {format_bytes(sum(x['size'] for x in del_cands))}）"
        )
        self.lbl_dup_summary.setText(
            f"👯 重複ファイル: {len(dup_groups)} グループ検出 （重複削減可能: {format_bytes(wasted)}）"
        )

        self._populate_table(self.rec_gdrive_table, gd_cands, show_full_path=True, third_col_key="reason")
        self._populate_table(self.rec_del_table, del_cands, show_full_path=True, third_col_key="reason")

        flat_dups = []
        for idx, grp in enumerate(dup_groups, start=1):
            files = sorted(grp.get("files", []), key=lambda x: x.get("mtime", 0), reverse=True)
            for f_idx, f in enumerate(files):
                entry = dict(f)
                entry["type"] = "file"
                entry["size"] = grp["size"]
                if f_idx == 0:
                    entry["dup_label"] = f"グループ#{idx} ★最新(残す推奨)"
                else:
                    entry["dup_label"] = f"グループ#{idx} 重複コピー(削除候補)"
                flat_dups.append(entry)

        self._populate_table(self.dup_table, flat_dups, show_full_path=True, third_col_key="dup_label")

    # =====================================================================
    # Shared Table Population & Row Actions (High-Density Single-Line for 1366x768)
    # =====================================================================
    def _populate_table(
        self,
        table: QTableWidget,
        items: list,
        show_full_path: bool = False,
        third_col_key: str = "category",
    ):
        v_scroll_bar = table.verticalScrollBar()
        saved_scroll = v_scroll_bar.value() if v_scroll_bar else 0

        table.setSortingEnabled(False)
        table.setRowCount(len(items))

        for row, item in enumerate(items):
            path_str = item["path"]
            is_prot = item.get("protection", {}).get("is_protected", False)
            prot_type = item.get("protection", {}).get("protection_type")
            prot_reason = item.get("protection", {}).get("reason", "")

            # Col 0: Checkbox
            chk_w = QWidget()
            chk_l = QHBoxLayout(chk_w)
            chk_l.setContentsMargins(0, 0, 0, 0)
            chk_l.setAlignment(Qt.AlignCenter)
            chk = QCheckBox()
            chk.setEnabled(not is_prot)
            chk.setChecked(path_str in self.selected_items)
            chk.stateChanged.connect(lambda state, it=item: self._on_item_checked(it, state == Qt.Checked.value))
            chk_l.addWidget(chk)
            table.setCellWidget(row, 0, chk_w)

            # Col 1: Single-line Name & Parent Path (maximizes visible rows on 768px height)
            icon = "📁 " if item.get("type") == "dir" else "📄 "
            display_name = f"{icon}{item['name']}"
            if show_full_path:
                parent_dir = os.path.dirname(path_str)
                display_name += f"   —  {parent_dir}"
            name_item = QTableWidgetItem(display_name)
            name_item.setToolTip(f"名前: {item['name']}\nフルパス: {path_str}")
            name_item.setData(Qt.UserRole, path_str)
            name_item.setData(Qt.UserRole + 1, item.get("type", "file"))
            if item.get("type") == "dir":
                name_item.setForeground(QColor("#93c5fd"))
            table.setItem(row, 1, name_item)

            # Col 2: Size (numeric sort)
            sz = item.get("size", 0)
            ratio_str = f" ({item['ratio']}%)" if "ratio" in item else ""
            sz_item = NumericTableWidgetItem(f"{format_bytes(sz)}{ratio_str}")
            sz_item.setData(Qt.UserRole, sz)
            if sz >= 500 * 1024 * 1024:
                sz_item.setForeground(QColor("#fbbf24"))
            table.setItem(row, 2, sz_item)

            # Col 3: Category or Reason or Dup Label
            col3_val = item.get(third_col_key) or item.get("category", "")
            if third_col_key == "category" and item.get("type") == "dir":
                cnt = item.get("item_count", 0)
                if item.get("scanning"):
                    col3_val = f"フォルダ (🔍集計中... {cnt}項目)" if cnt > 0 else "フォルダ (🔍集計中...)"
                elif "item_count" in item:
                    col3_val = f"フォルダ ({cnt}項目)"
            c3_item = QTableWidgetItem(str(col3_val))
            c3_item.setToolTip(str(col3_val))
            if item.get("scanning"):
                c3_item.setForeground(QColor("#60a5fa"))
            table.setItem(row, 3, c3_item)

            # Col 4: Date & Unused days
            days = item.get("days_unused", 0)
            date_str = f"{format_date(item.get('mtime', 0))} ({days}日前)"
            date_item = NumericTableWidgetItem(date_str)
            date_item.setData(Qt.UserRole, days)
            if days >= 90:
                date_item.setForeground(QColor("#fbbf24"))
            table.setItem(row, 4, date_item)

            # Col 5: Protection Status
            if is_prot:
                badge = f"🛑 {prot_reason}" if prot_type == "system" else f"🛡️ {prot_reason}"
                prot_item = QTableWidgetItem(badge)
                prot_item.setToolTip(badge)
                prot_item.setForeground(QColor("#fca5a5" if prot_type == "system" else "#fde68a"))
            else:
                prot_item = QTableWidgetItem("✓ 整理・移動可")
                prot_item.setForeground(QColor("#6ee7b7"))
            table.setItem(row, 5, prot_item)

            # Col 6: Compact Action Buttons tailored for 1366px width
            act_w = QWidget()
            act_l = QHBoxLayout(act_w)
            act_l.setContentsMargins(2, 1, 2, 1)
            act_l.setSpacing(3)

            can_unlock = item.get("protection", {}).get("can_unlock", True)
            if is_prot and not can_unlock:
                btn_p = QPushButton("🔒固定")
                btn_p.setToolTip("OS・Outlook・仮想ディスク等の重要データのため保護固定されています")
                btn_p.setEnabled(False)
            elif is_prot:
                btn_p = QPushButton("🔓解除")
                btn_p.setObjectName("ShieldBtn")
                btn_p.setToolTip("クリックしてこの項目の保護ロックを個別に解除します")
            else:
                btn_p = QPushButton("🛡️保護")
                btn_p.setObjectName("ShieldBtn")
                btn_p.setToolTip("クリックして削除・移動禁止にロックします")
            btn_p.setFixedWidth(54)
            btn_p.setStyleSheet("padding: 1px 4px; font-size: 11px;")
            btn_p.clicked.connect(lambda _=False, p=path_str: self._toggle_protection(p))
            act_l.addWidget(btn_p)

            btn_gd = QPushButton("☁️移動")
            btn_gd.setObjectName("GDriveBtn")
            btn_gd.setFixedWidth(54)
            btn_gd.setStyleSheet("padding: 1px 4px; font-size: 11px;")
            btn_gd.setEnabled(not is_prot)
            btn_gd.clicked.connect(lambda _=False, it=item: self._open_gdrive_dialog([it]))
            act_l.addWidget(btn_gd)

            btn_del = QPushButton("🗑️")
            btn_del.setObjectName("DangerBtn")
            btn_del.setFixedWidth(30)
            btn_del.setStyleSheet("padding: 1px 2px; font-size: 11px;")
            btn_del.setEnabled(not is_prot)
            btn_del.clicked.connect(lambda _=False, it=item: self._open_delete_dialog([it]))
            act_l.addWidget(btn_del)

            btn_exp = QPushButton("📂")
            btn_exp.setToolTip("エクスプローラーで場所を開く")
            btn_exp.setFixedWidth(30)
            btn_exp.setStyleSheet("padding: 1px 2px; font-size: 11px;")
            btn_exp.clicked.connect(lambda _=False, p=path_str: self._open_in_explorer(p))
            act_l.addWidget(btn_exp)

            table.setCellWidget(row, 6, act_w)
            table.setRowHeight(row, 29)

        table.setSortingEnabled(True)
        if v_scroll_bar and saved_scroll > 0:
            v_scroll_bar.setValue(saved_scroll)

    def _on_table_double_clicked(self, table: QTableWidget, row: int, _col: int):
        it = table.item(row, 1)
        if not it:
            return
        path_str = it.data(Qt.UserRole)
        item_type = it.data(Qt.UserRole + 1)
        if item_type == "dir" and path_str:
            self.tabs.setCurrentIndex(0)
            self._load_directory_view(path_str)

    def _on_item_checked(self, item: dict, checked: bool):
        p = item["path"]
        if checked:
            self.selected_items[p] = item
        else:
            self.selected_items.pop(p, None)
        self._update_bulk_bar()

    def _update_bulk_bar(self):
        count = len(self.selected_items)
        if count == 0:
            self.bulk_bar.hide()
            return
        total_sz = sum(x.get("size", 0) for x in self.selected_items.values())
        self.bulk_info_lbl.setText(f"✅ {count} 件選択中 （合計サイズ: {format_bytes(total_sz)}）")
        self.bulk_bar.show()

    def _clear_selection(self):
        self.selected_items.clear()
        self._update_bulk_bar()
        self._refresh_all_views()

    def _open_in_explorer(self, path_str: str):
        if os.path.exists(path_str):
            subprocess.Popen(["explorer", f"/select,{os.path.abspath(path_str)}"])

    # =====================================================================
    # Protection Management
    # =====================================================================
    def _toggle_protection(self, target_path: str):
        if self.ui_save_timer.isActive():
            self.ui_save_timer.stop()
            self._save_ui_state_now()
        action_taken, cfg, new_status = backend.toggle_path_protection(target_path)
        self.config = cfg
        if action_taken == "locked_system":
            QMessageBox.warning(
                self,
                "安全保護ロック",
                f"この項目はシステム・Outlookメール・仮想ディスク等の重要データのため保護固定されています:\n{new_status.get('reason', '')}",
            )
            return
        if action_taken == "protected":
            self.selected_items.pop(os.path.abspath(target_path), None)
        self._sync_config_to_ui()
        self._update_bulk_bar()
        self._refresh_all_views()

    def _apply_protection_preset(self, preset_key: str):
        kws = backend.PROTECTION_PRESETS.get(preset_key, [])
        existing = list(self.config.get("custom_protected_keywords", []))
        existing_lower = {k.lower() for k in existing}
        added = 0
        for kw in kws:
            if kw.lower() not in existing_lower:
                existing.append(kw)
                existing_lower.add(kw.lower())
                added += 1
        self.config["custom_protected_keywords"] = existing
        backend.save_config(self.config)
        self._sync_config_to_ui()
        self._refresh_all_views()
        QMessageBox.information(self, "保護プリセット適用", f"{added} 個の保護キーワードを追加しました。")

    def _save_protection_settings(self):
        exts = [s.strip() for s in self.edit_prot_exts.text().split(",") if s.strip()]
        self.config["protect_system_folders"] = self.chk_prot_sys.isChecked()
        self.config["protect_appdata"] = self.chk_prot_appdata.isChecked()
        self.config["protect_mail_and_db"] = self.chk_prot_mail.isChecked()
        self.config["protect_virtual_disks"] = self.chk_prot_vm.isChecked()
        self.config["protect_dev_and_hidden"] = self.chk_prot_dev.isChecked()
        self.config["protect_unknown_extensions"] = self.chk_prot_unknown.isChecked()
        self.config["auto_update_check"] = self.chk_auto_update.isChecked()
        self.config["protected_extensions"] = exts
        gpath = self.edit_default_gdrive.text().strip()
        if gpath:
            self.config["google_drive_path"] = gpath
        backend.save_config(self.config)
        self._sync_config_to_ui()
        self._refresh_all_views()

    def _browse_default_gdrive(self):
        d = QFileDialog.getExistingDirectory(self, "Googleドライブフォルダを選択", self.edit_default_gdrive.text())
        if d:
            self.edit_default_gdrive.setText(os.path.normpath(d))
            self._save_protection_settings()

    def _browse_protect_path(self):
        d = QFileDialog.getExistingDirectory(self, "削除禁止にするフォルダを選択")
        if d:
            self.edit_add_prot_path.setText(os.path.normpath(d))

    def _add_custom_protected_path(self):
        p = self.edit_add_prot_path.text().strip()
        if not p:
            return
        self._toggle_protection(p)
        self.edit_add_prot_path.clear()

    def _remove_selected_protected_path(self):
        cur = self.list_prot_paths.currentItem()
        if not cur:
            return
        self._toggle_protection(cur.text())

    def _add_protected_keyword(self):
        kw = self.edit_add_kw.text().strip()
        if not kw:
            return
        kws = list(self.config.get("custom_protected_keywords", []))
        if kw not in kws:
            kws.append(kw)
            self.config["custom_protected_keywords"] = kws
            backend.save_config(self.config)
            self._sync_config_to_ui()
            self._refresh_all_views()
        self.edit_add_kw.clear()

    def _remove_selected_keyword(self):
        cur = self.list_prot_kws.currentItem()
        if not cur:
            return
        kw = cur.text()
        kws = [k for k in self.config.get("custom_protected_keywords", []) if k != kw]
        self.config["custom_protected_keywords"] = kws
        backend.save_config(self.config)
        self._sync_config_to_ui()
        self._refresh_all_views()

    # =====================================================================
    # Bulk & Smart Actions (Google Drive Move / Delete / Duplicate Selection)
    # =====================================================================
    def _bulk_protect(self):
        custom_list = list(self.config.get("custom_protected_paths", []))
        norms = {backend.normalize_path(p) for p in custom_list}
        for p in list(self.selected_items.keys()):
            if backend.normalize_path(p) not in norms:
                custom_list.append(p)
                norms.add(backend.normalize_path(p))
        self.config["custom_protected_paths"] = custom_list
        backend.save_config(self.config)
        self._clear_selection()
        self._sync_config_to_ui()

    def _bulk_move_gdrive(self):
        self._open_gdrive_dialog(list(self.selected_items.values()))

    def _bulk_delete(self):
        self._open_delete_dialog(list(self.selected_items.values()))

    def _action_all_gdrive_recommendations(self):
        cands = [c for c in self.recommendations.get("gdrive_candidates", []) if not c.get("protection", {}).get("is_protected")]
        if not cands:
            QMessageBox.information(self, "おすすめ移動", "移動可能なGoogleドライブおすすめ候補がありません。")
            return
        self._open_gdrive_dialog(cands)

    def _action_all_delete_recommendations(self):
        cands = [c for c in self.recommendations.get("delete_candidates", []) if not c.get("protection", {}).get("is_protected")]
        if not cands:
            QMessageBox.information(self, "おすすめ削除", "削除可能な不要ファイル候補がありません。")
            return
        self._open_delete_dialog(cands)

    def _auto_select_older_duplicates(self):
        groups = self.duplicate_data.get("duplicate_groups", [])
        added = 0
        for grp in groups:
            files = sorted(grp.get("files", []), key=lambda x: x.get("mtime", 0), reverse=True)
            for older in files[1:]:
                if not older.get("protection", {}).get("is_protected"):
                    entry = dict(older)
                    entry["type"] = "file"
                    entry["size"] = grp["size"]
                    self.selected_items[entry["path"]] = entry
                    added += 1
        self._update_bulk_bar()
        self._load_smart_and_duplicates()
        QMessageBox.information(
            self,
            "重複ファイル一括選択",
            f"各重複グループの最新ファイル1つを残し、重複コピー {added} 件を選択しました。\n下部バーから「ゴミ箱へ削除」または「Googleドライブへ移動」を実行できます。",
        )

    def _open_gdrive_dialog(self, items: list):
        valid = [i for i in items if not i.get("protection", {}).get("is_protected")]
        if not valid:
            QMessageBox.warning(self, "保護ブロック", "選択された項目は保護ロックされているため移動できません。")
            return

        dlg = GDriveMoveDialog(self, valid, self.config, self.gdrive_candidates)
        if dlg.exec() != QDialog.Accepted:
            return

        params = dlg.get_params()
        gdrive_root = params["gdrive_path"]
        subfolder = params["subfolder"]
        preserve = params["preserve_structure"]
        copy_only = params["copy_only"]

        self.config["google_drive_path"] = gdrive_root
        self.config["google_drive_subfolder"] = subfolder
        backend.save_config(self.config)
        self._sync_config_to_ui()

        dest_base = Path(gdrive_root)
        if subfolder:
            dest_base = dest_base / subfolder
        try:
            dest_base.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            QMessageBox.critical(self, "移動先エラー", f"移動先フォルダを作成できません:\n{dest_base}\n{e}")
            return

        total_required = sum(i.get("size", 0) for i in valid)
        try:
            usage = shutil.disk_usage(str(dest_base))
            if total_required > usage.free:
                QMessageBox.warning(
                    self,
                    "容量不足エラー",
                    f"移動先Googleドライブの空き容量が不足しています。\n必要: {format_bytes(total_required)} / 空き: {format_bytes(usage.free)}",
                )
                return
        except Exception:
            pass

        moved_count = 0
        moved_bytes = 0
        errors = []

        for it in valid:
            abs_p = os.path.abspath(it["path"])
            if not os.path.exists(abs_p):
                continue
            prot = backend.check_protection_status(abs_p, self.config)
            if prot["is_protected"] and not copy_only:
                errors.append(f"{abs_p}: {prot['reason']}")
                continue

            if preserve:
                drive_part, tail_part = os.path.splitdrive(abs_p)
                drive_label = drive_part.replace(":", "") + "_Drive" if drive_part else "Local"
                target_dest = dest_base / drive_label / tail_part.lstrip("\\/")
            else:
                target_dest = dest_base / os.path.basename(abs_p)

            if target_dest.exists():
                ts_tag = datetime.now().strftime("_%Y%m%d_%H%M%S")
                target_dest = target_dest.with_name(f"{target_dest.stem}{ts_tag}{target_dest.suffix}")

            sz = it.get("size", 0)
            try:
                target_dest.parent.mkdir(parents=True, exist_ok=True)
                if copy_only:
                    if os.path.isdir(abs_p):
                        shutil.copytree(abs_p, str(target_dest))
                    else:
                        shutil.copy2(abs_p, str(target_dest))
                    act_label = "Googleドライブへコピー"
                else:
                    shutil.move(abs_p, str(target_dest))
                    act_label = "Googleドライブへ移動"

                moved_count += 1
                moved_bytes += sz
                self.selected_items.pop(it["path"], None)
                backend.append_operation_log({
                    "action": act_label,
                    "source": abs_p,
                    "destination": str(target_dest),
                    "size": sz,
                    "status": "成功",
                    "can_undo": True,
                })
            except Exception as e:
                errors.append(f"{abs_p}: {e}")

        self._update_bulk_bar()
        self._load_system_info()
        self._refresh_all_views()

        msg = f"{moved_count} 件 ({format_bytes(moved_bytes)}) をGoogleドライブへ{'コピー' if copy_only else '移動'}しました。"
        if errors:
            msg += f"\n\n⚠️ {len(errors)} 件でエラー:\n" + "\n".join(errors[:5])
        QMessageBox.information(self, "Googleドライブ整理完了", msg)

    def _open_delete_dialog(self, items: list):
        valid = [i for i in items if not i.get("protection", {}).get("is_protected")]
        if not valid:
            QMessageBox.warning(self, "保護ブロック", "選択された項目は保護規制により削除できません。")
            return

        dlg = DeleteConfirmDialog(self, valid)
        if dlg.exec() != QDialog.Accepted:
            return

        mode = dlg.get_mode()
        del_count = 0
        freed_bytes = 0
        errors = []

        for it in valid:
            abs_p = os.path.abspath(it["path"])
            if not os.path.exists(abs_p):
                continue
            prot = backend.check_protection_status(abs_p, self.config)
            if prot["is_protected"]:
                errors.append(f"{abs_p}: {prot['reason']}")
                continue

            sz = it.get("size", 0)
            if mode == "recycle":
                ok, err_msg = backend.send_to_recycle_bin(abs_p)
            else:
                try:
                    if os.path.isdir(abs_p):
                        shutil.rmtree(abs_p)
                    else:
                        os.remove(abs_p)
                    ok, err_msg = True, ""
                except Exception as e:
                    ok, err_msg = False, str(e)

            if ok:
                del_count += 1
                freed_bytes += sz
                self.selected_items.pop(it["path"], None)
                backend.append_operation_log({
                    "action": "ゴミ箱へ移動" if mode == "recycle" else "完全削除",
                    "source": abs_p,
                    "destination": "ゴミ箱" if mode == "recycle" else "-",
                    "size": sz,
                    "status": "成功",
                    "can_undo": False,
                })
            else:
                errors.append(f"{abs_p}: {err_msg}")

        self._update_bulk_bar()
        self._load_system_info()
        self._refresh_all_views()

        msg = f"{del_count} 件 ({format_bytes(freed_bytes)}) を{'ゴミ箱へ移動' if mode == 'recycle' else '完全削除'}しました。"
        if errors:
            msg += f"\n\n⚠️ {len(errors)} 件でエラー:\n" + "\n".join(errors[:5])
        QMessageBox.information(self, "削除完了", msg)

    def _open_logs_dialog(self):
        dlg = LogsUndoDialog(self, on_restored_callback=self._refresh_all_views)
        dlg.exec()

    # =====================================================================
    # Auto-Update System (GitHub Repository Update Package Integration)
    # =====================================================================
    def _start_update_check(self, silent_if_latest: bool = True):
        if self._is_checking_update:
            return
        self._is_checking_update = True
        if not silent_if_latest:
            self.btn_update_check.setEnabled(False)
            self.btn_update_check.setText("🔄 確認中...")
            self.scan_status_lbl.setText("🔄 GitHubリポジトリの最新アップデートを確認しています...")

        def _worker():
            res = backend.check_for_updates(timeout=8.0)
            self.updateCheckFinished.emit(res, silent_if_latest)

        threading.Thread(target=_worker, daemon=True).start()

    def _on_update_check_finished(self, res: dict, silent_if_latest: bool):
        self._is_checking_update = False
        self.btn_update_check.setEnabled(True)
        cur_ver = res.get("current_version", backend.APP_VERSION)
        latest_ver = res.get("latest_version", cur_ver)

        if not res.get("ok"):
            self.btn_update_check.setText("🔄 更新確認")
            if not silent_if_latest:
                QMessageBox.warning(
                    self,
                    "アップデート確認エラー",
                    f"リポジトリからアップデート情報を取得できませんでした:\n{res.get('error', '')}",
                )
            return

        if res.get("has_update"):
            self._latest_update_info = res
            self.btn_update_check.setText(f"🆙 v{latest_ver} 自動更新中...")
            self.btn_update_check.setObjectName("GDriveBtn")
            self.btn_update_check.style().unpolish(self.btn_update_check)
            self.btn_update_check.style().polish(self.btn_update_check)
            self.scan_status_lbl.setText(f"⬇️ 新バージョン v{latest_ver} を検出しました。自動アップデートを適用しています...")

            if silent_if_latest and self.config.get("auto_update_check", True):
                # 起動時・定期チェック時は確認ダイアログを出さずに自動でダウンロード＆適用して再起動する
                self._start_apply_update(res, auto_silent=True)
                return

            notes = res.get("notes", "機能改善および不具合修正")
            sz_str = format_bytes(res.get("size", 0)) if res.get("size") else "軽量パッチ"
            reply = QMessageBox.question(
                self,
                "🎉 最新アップデートのご案内",
                f"新しいバージョン (v{latest_ver}) がリポジトリに公開されています！\n\n"
                f"・現在のバージョン : v{cur_ver}\n"
                f"・最新バージョン   : v{latest_ver} ({sz_str})\n\n"
                f"【更新内容】\n{notes}\n\n"
                f"今すぐ自動アップデートを適用してアプリを再起動しますか？",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.Yes,
            )
            if reply == QMessageBox.Yes:
                self._start_apply_update(res, auto_silent=False)
        else:
            self.btn_update_check.setText("🔄 更新確認")
            if not silent_if_latest:
                self.scan_status_lbl.setText(f"✅ 最新バージョン (v{cur_ver}) を使用中です")
                QMessageBox.information(
                    self,
                    "アップデート確認",
                    f"お使いのバージョン (v{cur_ver}) は最新です。",
                )

    def _start_apply_update(self, update_info: dict, auto_silent: bool = False):
        self._auto_silent_update = auto_silent
        self.btn_update_check.setEnabled(False)
        self.btn_update_check.setText("⬇️ 更新適用中...")
        self.scan_status_lbl.setText("⬇️ アップデートパッケージを自動ダウンロード・検証・適用しています...")

        def _apply_worker():
            apply_res = backend.download_and_apply_update(update_info)
            self.updateApplyFinished.emit(apply_res)

        threading.Thread(target=_apply_worker, daemon=True).start()

    def _on_update_apply_finished(self, apply_res: dict):
        self.btn_update_check.setEnabled(True)
        auto_silent = getattr(self, "_auto_silent_update", False)
        if not apply_res.get("ok"):
            self.btn_update_check.setText("🆙 更新再試行")
            if not auto_silent:
                QMessageBox.critical(
                    self,
                    "アップデート失敗",
                    f"アップデートの適用中にエラーが発生しました:\n{apply_res.get('error', '')}",
                )
            else:
                self.scan_status_lbl.setText(f"⚠️ 自動アップデート失敗: {apply_res.get('error', '')}")
            return

        new_ver = apply_res.get("installed_version", "")
        os.environ["DISKGUARD_AUTO_UPDATED_TO"] = str(new_ver)
        if not auto_silent:
            QMessageBox.information(
                self,
                "✅ アップデート完了",
                f"最新バージョン (v{new_ver}) の適用が完了しました！\nアプリを自動的に再起動して新バージョンを反映します。",
            )
        self._restart_application()

    def _restart_application(self):
        self._save_ui_state_now()
        if self.local_server:
            self.local_server.close()
            QLocalServer.removeServer(SINGLE_INSTANCE_KEY)
        self.force_quit = True
        self.tray_icon.hide()
        try:
            env = os.environ.copy()
            env.pop("DISKGUARD_BOOTED_PATCH_VER", None)
            subprocess.Popen([sys.executable] + sys.argv[1:], cwd=str(backend.BASE_DIR), env=env)
        except Exception:
            pass
        QApplication.quit()


def _preboot_auto_update() -> None:
    """
    アプリ起動時（ウィンドウ生成前）にGitHubリポジトリの最新バージョンを確認し、
    新バージョンがあれば即座に自動ダウンロード＆適用してから最新コードで起動させる。
    """
    if os.environ.get("DISKGUARD_PREBOOT_CHECKED") == "1":
        return
    os.environ["DISKGUARD_PREBOOT_CHECKED"] = "1"
    try:
        cfg = backend.load_config()
        if not cfg.get("auto_update_check", True):
            return
        res = backend.check_for_updates(timeout=3.5)
        if res.get("ok") and res.get("has_update"):
            apply_res = backend.download_and_apply_update(res, timeout=15.0)
            if apply_res.get("ok"):
                os.environ["DISKGUARD_AUTO_UPDATED_TO"] = str(apply_res.get("installed_version", ""))
    except Exception as e:
        print(f"[Preboot AutoUpdate] {e}")


def _try_boot_from_applied_update() -> bool:
    """
    app_update/ フォルダに内蔵バージョンより新しいアップデートが存在する場合、
    動的に app_update/app.py と app_update/desktop_gui.py をロードして起動する。
    """
    try:
        patch_dir = backend.APP_UPDATE_DIR
        ver_file = patch_dir / "version.json"
        patched_app_py = patch_dir / "app.py"
        patched_gui_py = patch_dir / "desktop_gui.py"
        if not (ver_file.exists() and patched_app_py.exists() and patched_gui_py.exists()):
            return False

        with open(ver_file, "r", encoding="utf-8") as f:
            ver_data = json.load(f)
        patch_ver = str(ver_data.get("version", "")).strip()
        if not patch_ver:
            return False

        # 既にこのパッチバージョンでブート済みなら無限再帰を防ぐ
        if os.environ.get("DISKGUARD_BOOTED_PATCH_VER") == patch_ver:
            return False

        if backend.parse_version_tuple(patch_ver) <= backend.parse_version_tuple(backend.APP_VERSION):
            return False

        os.environ["DISKGUARD_BOOTED_PATCH_VER"] = patch_ver
        if str(patch_dir) not in sys.path:
            sys.path.insert(0, str(patch_dir))

        spec_app = importlib.util.spec_from_file_location("app", str(patched_app_py))
        if spec_app and spec_app.loader:
            mod_app = importlib.util.module_from_spec(spec_app)
            sys.modules["app"] = mod_app
            spec_app.loader.exec_module(mod_app)

        spec_gui = importlib.util.spec_from_file_location("desktop_gui_patched", str(patched_gui_py))
        if spec_gui and spec_gui.loader:
            mod_gui = importlib.util.module_from_spec(spec_gui)
            sys.modules["desktop_gui_patched"] = mod_gui
            spec_gui.loader.exec_module(mod_gui)
            if hasattr(mod_gui, "run_standalone_gui"):
                mod_gui.run_standalone_gui()
                return True
    except Exception as e:
        print(f"[AutoUpdate Boot Fallback] {e}")
    return False


def run_standalone_gui():
    """Launch the standalone PySide6 desktop application with single-instance, system tray, and startup auto-update."""
    _preboot_auto_update()
    if _try_boot_from_applied_update():
        return

    app = QApplication.instance() or QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    app.setStyleSheet(DARK_STYLESHEET)

    socket = QLocalSocket()
    socket.connectToServer(SINGLE_INSTANCE_KEY)
    if socket.waitForConnected(400):
        socket.write(b"SHOW")
        socket.flush()
        socket.waitForBytesWritten(400)
        socket.disconnectFromServer()
        return

    QLocalServer.removeServer(SINGLE_INSTANCE_KEY)
    local_server = QLocalServer()
    local_server.listen(SINGLE_INSTANCE_KEY)

    win = DiskGuardMainWindow(local_server=local_server)
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    run_standalone_gui()
